﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Media;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using Microsoft.Win32;
//using FuzzyString;

namespace LORUtils
{
	public class utils
	{
		public const int UNDEFINED = -1;
		public const string ICONtrack = "Track";
		public const string ICONchannelGroup = "ChannelGroup";
		public const string ICONcosmicDevice = "CosmicDevice";
		//public const string ICONchannel = "channel";
		public const string ICONrgbChannel = "RGBchannel";
		//public const string ICONredChannel = "redChannel";
		//public const string ICONgrnChannel = "grnChannel";
		//public const string ICONbluChannel = "bluChannel";
		public const string ICONredChannel = "FF0000";
		public const string ICONgrnChannel = "00FF00";
		public const string ICONbluChannel = "0000FF";
		// Note: LOR colors not in the same order as .Net or Web colors, Red and Blue are reversed
		public const Int32 LORCOLOR_RED = 255;			// 0x0000FF
		public const Int32 LORCOLOR_GRN = 65280;		// 0x00FF00
		public const Int32 LORCOLOR_BLU = 16711680;	// 0xFF0000
		public const Int32 LORCOLOR_BLK = 0;
		public const Int32 LORCOLOR_WHT = 0xFFFFFF;

		public const int ADDshimmer = 0x200;
		public const int ADDtwinkle = 0x400;



		public const string LOG_Error = "Error";
		public const string LOG_Info = "Info";
		public const string LOG_Debug = "Debug";
		private const string FORMAT_DATETIME = "MM/dd/yyyy hh:mm:ss tt";
		private const string FORMAT_FILESIZE = "###,###,###,###,##0";

		public static int nodeIndex = UNDEFINED;

		public const string TABLEchannel = "channel";
		public const string FIELDname = " name";
		public const string FIELDtype = " type";
		public const string FIELDsavedIndex = " savedIndex";
		public const string FIELDcentisecond = " centisecond";
		public const string FIELDcentiseconds = FIELDcentisecond + PLURAL;
		public const string FIELDtotalCentiseconds = " totalCentiseconds";
		public const string FIELDstartCentisecond = " startCentisecond";
		public const string FIELDendCentisecond = " endCentisecond";

		public const string FILE_SEQ = "All Sequences *.las, *.lms|*.las;*.lms";
		public const string FILE_CFG = "All Sequences *.las, *.lms, *.lcc|*.las;*.lms;*.lcc";
		public const string FILE_LMS = "Musical Sequence *.lms|*.lms";
		public const string FILE_LAS = "Animated Sequence *.las|*.las";
		public const string FILE_LCC = "Channel Configuration *.lcc|*.lcc";
		public const string FILE_LEE = "Visualization *.lee|*.lee";
		public const string FILE_CHMAP = "Channel Map *.ChMap|*.ChMap";
		public const string FILE_ALL = "All Files *.*|*.*";
		public const string FILT_OPEN_ANY = FILE_SEQ + "|" + FILE_LMS + "|" + FILE_LAS;
		public const string FILT_OPEN_CFG = FILE_CFG + "|" + FILE_LMS + "|" + FILE_LAS + "|" + FILE_LCC;
		public const string FILT_SAVE_EITHER = FILE_LMS + "|" + FILE_LAS;
		public const string EXT_CHMAP = "ChMap";
		public const string EXT_LAS = "las";
		public const string EXT_LMS = "lms";
		public const string EXT_LEE = "lee";
		public const string EXT_LCC = "lcc";


		public const string SPC = " ";
		public const string LEVEL0 = "";
		//public const string LEVEL1 = "  ";
		//public const string LEVEL2 = "    ";
		//public const string LEVEL3 = "      ";
		//public const string LEVEL4 = "        ";
		//public const string LEVEL5 = "          ";
		public const string LEVEL1 = "\t";
		public const string LEVEL2 = "\t\t";
		public const string LEVEL3 = "\t\t\t";
		public const string LEVEL4 = "\t\t\t\t";
		public const string LEVEL5 = "\t\t\t\t\t";
		public const string CRLF = "\r\n";
		// Or, if you prefer tabs instead of spaces...
		//public const string LEVEL1 = "\t";
		//public const string LEVEL2 = "\t\t";
		//public const string LEVEL3 = "\t\t\t";
		//public const string LEVEL4 = "\t\t\t\t";
		public const string PLURAL = "s";
		public const string FIELDEQ = "=\"";
		public const string ENDQT = "\"";
		public const string STFLD = "<";
		public const string ENDFLD = "/>";
		public const string FINFLD = ">";
		public const string STTBL = "<";
		public const string FINTBL = "</";
		public const string ENDTBL = ">";

		public const string COMMA = ",";
		public const string SLASH = "/";
		public const char DELIM1 = '⬖';
		public const char DELIM2 = '⬘';
		public const char DELIM3 = '⬗';
		public const char DELIM4 = '⬙';
		private const char DELIM_Map = (char)164;  // ¤
		private const char DELIM_SID = (char)177;  // ±
		private const char DELIM_Name = (char)167;  // §
		private const char DELIM_X = (char)182;  // ¶
		private const string ROOT = "C:\\";
		private const string LOR_REGKEY = "HKEY_CURRENT_USER\\SOFTWARE\\Light-O-Rama\\Shared";
		private const string LOR_DIR = "Light-O-Rama\\";


		public static void FillChannels(TreeView tree, Sequence4 seq, List<TreeNode>[] siNodes, bool selectedOnly, bool includeRGBchildren)
		{
			int t = SeqEnums.MEMBER_Channel | SeqEnums.MEMBER_RGBchannel | SeqEnums.MEMBER_ChannelGroup | SeqEnums.MEMBER_Track;
			FillChannels(tree, seq, siNodes, selectedOnly, includeRGBchildren, t);
		}

		public static void FillChannels(TreeView tree, Sequence4 seq, List<TreeNode>[] siNodes, bool selectedOnly, bool includeRGBchildren, int memberTypes)
		{
			//TODO: 'Selected' not implemented yet

			tree.Nodes.Clear();
			nodeIndex = 1;
			int listSize = seq.Members.HighestSavedIndex + seq.Tracks.Count + seq.TimingGrids.Count + 1;
			//Array.Resize(ref siNodes, listSize);

			//const string ERRproc = " in FillChannels(";
			//const string ERRtrk = "), in Track #";
			//const string ERRitem = ", Items #";
			//const string ERRline = ", Line #";



			for (int n = 0; n < siNodes.Length; n++)
			{
				//siNodes[n] = null;
				//siNodes[n] = new List<TreeNode>();
				//siNodes.Add(new List<TreeNode>());
				siNodes[n] = new List<TreeNode>();
			}

			for (int t = 0; t < seq.Tracks.Count; t++)
			{
				TreeNode trackNode = AddTrack(seq, tree.Nodes, t, siNodes, selectedOnly, includeRGBchildren, memberTypes);
			}
		}

		private static TreeNode AddTrack(Sequence4 seq, TreeNodeCollection baseNodes, int trackNumber, List<TreeNode>[] siNodes, bool selectedOnly,
			bool includeRGBchildren, int memberTypes)
		{

			string nodeText = "";
			bool inclChan = false;
			if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
			bool inclRGB = false;
			if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;

			// TEMPORARY, FOR DEBUGGING
			// int tcount = 0;
			int gcount = 0;
			int rcount = 0;
			int ccount = 0;
			int dcount = 0;

			//try
			//{
			Track theTrack = seq.Tracks[trackNumber];
			nodeText = theTrack.Name;
			TreeNode trackNode = baseNodes.Add(nodeText);
			List<TreeNode> qlist;

			//int inclCount = theTrack.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
			//if (inclCount > 0)
			//{
			// Tracks don't normally have savedIndexes
			// But we will assign one for tracking and matching purposes
			//theTrack.SavedIndex = seq.Members.HighestSavedIndex + t + 1;

			//if ((memberTypes & SeqEnums.MEMBER_Track) > 0)
			//{
			baseNodes = trackNode.Nodes;
			nodeIndex++;
			trackNode.Tag = theTrack;

			trackNode.ImageKey = ICONtrack;
			trackNode.SelectedImageKey = ICONtrack;
			trackNode.Checked = theTrack.Selected;
			//}

			for (int ti = 0; ti < theTrack.Members.Count; ti++)
			{
				//try
				//{
				IMember member = theTrack.Members.Items[ti];
				int si = member.SavedIndex;
				if (member != null)
				{
					if (member.MemberType == MemberType.ChannelGroup)
					{
						ChannelGroup memGrp = (ChannelGroup)member;
						int inclCount = memGrp.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
						if (inclCount > 0)
						{
							TreeNode groupNode = AddGroup(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren, memberTypes);
							//AddNode(siNodes[si], groupNode);
							qlist = siNodes[si];
							if (qlist == null) qlist = new List<TreeNode>();
							qlist.Add(groupNode);
							gcount++;
							//siNodes[si].Add(groupNode);
						}
					}
					if (member.MemberType == MemberType.CosmicDevice)
					{
						CosmicDevice memDev = (CosmicDevice)member;
						int inclCount = memDev.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
						if (inclCount > 0)
						{
							TreeNode cosmicNode = AddGroup(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren, memberTypes);
							//AddNode(siNodes[si], groupNode);
							qlist = siNodes[si];
							if (qlist == null) qlist = new List<TreeNode>();
							qlist.Add(cosmicNode);
							dcount++;
								//siNodes[si].Add(groupNode);
						}
					}
					if (member.MemberType == MemberType.RGBchannel)
					{
						TreeNode rgbNode = AddRGBchannel(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren);
						//AddNode(siNodes[si], rgbNode);
						//siNodes[si].Add(rgbNode);
						qlist = siNodes[si];
						if (qlist == null) qlist = new List<TreeNode>();
						qlist.Add(rgbNode);
						rcount++;
					}
					if (member.MemberType == MemberType.Channel)
					{
						TreeNode channelNode = AddChannel(seq, baseNodes, member.SavedIndex, selectedOnly);
						//AddNode(siNodes[si], channelNode);
						//siNodes[si].Add(channelNode);
						qlist = siNodes[si];
						if (qlist == null) qlist = new List<TreeNode>();
						qlist.Add(channelNode);
						ccount++;
					}
				} // end not null
					//} // end try
				#region catch1
				/*	
				catch (System.NullReferenceException ex)
					{
						StackTrace st = new StackTrace(ex, true);
						StackFrame sf = st.GetFrame(st.FrameCount - 1);
						string emsg = ex.ToString();
						emsg += ERRproc + seq.filename + ERRtrk + t.ToString() + ERRitem + ti.ToString();
						emsg += ERRline + sf.GetFileLineNumber();
						#if DEBUG
							System.Diagnostics.Debugger.Break();
						#endif
						utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
					}
					catch (System.InvalidCastException ex)
					{
						StackTrace st = new StackTrace(ex, true);
						StackFrame sf = st.GetFrame(st.FrameCount - 1);
						string emsg = ex.ToString();
						emsg += ERRproc + seq.filename + ERRtrk + t.ToString() + ERRitem + ti.ToString();
						emsg += ERRline + sf.GetFileLineNumber();
						#if DEBUG
							System.Diagnostics.Debugger.Break();
						#endif
						utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
					}
					catch (Exception ex)
					{
						StackTrace st = new StackTrace(ex, true);
						StackFrame sf = st.GetFrame(st.FrameCount - 1);
						string emsg = ex.ToString();
						emsg += ERRproc + seq.filename + ERRtrk + t.ToString() + ERRitem + ti.ToString();
						emsg += ERRline + sf.GetFileLineNumber();
						#if DEBUG
							System.Diagnostics.Debugger.Break();
						#endif
						utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
					}
					*/
				#endregion

			} // end loop thru track items
			#region catch2 
			/*
				} // end try
				catch (System.NullReferenceException ex)
				{
					StackTrace st = new StackTrace(ex, true);
					StackFrame sf = st.GetFrame(st.FrameCount - 1);
					string emsg = ex.ToString();
					emsg += ERRproc + seq.filename + ERRtrk + t.ToString();
					emsg += ERRline + sf.GetFileLineNumber();
					#if DEBUG
						System.Diagnostics.Debugger.Break();
					#endif
					utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
				}
				catch (System.InvalidCastException ex)
				{
					StackTrace st = new StackTrace(ex, true);
					StackFrame sf = st.GetFrame(st.FrameCount - 1);
					string emsg = ex.ToString();
					emsg += ERRproc + seq.filename + ERRtrk + t.ToString();
					emsg += ERRline + sf.GetFileLineNumber();
					#if DEBUG
						System.Diagnostics.Debugger.Break();
					#endif
					utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
				}
				catch (Exception ex)
				{
					StackTrace st = new StackTrace(ex, true);
					StackFrame sf = st.GetFrame(st.FrameCount - 1);
					string emsg = ex.ToString();
					emsg += ERRproc + seq.filename + ERRtrk + t.ToString();
					emsg += ERRline + sf.GetFileLineNumber();
					#if DEBUG
						System.Diagnostics.Debugger.Break();
					#endif
					utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
				}
				*/
			#endregion

		

			//	int x = 1; // Check ccount, rcount, gcount

			return trackNode;
		} // end fillOldChannels

		private static TreeNode Original_AddGroup(Sequence4 seq, TreeNodeCollection baseNodes, int groupIndex, List<List<TreeNode>> siNodes, bool selectedOnly, bool includeRGBchildren, int memberTypes)
		{
			//ChanInfo nodeTag = new ChanInfo();
			//nodeTag.MemberType = MemberType.ChannelGroup;
			//nodeTag.objIndex = groupIndex;
			//nodeTag.SavedIndex = theGroup.SavedIndex;
			//nodeTag.nodeIndex = nodeIndex;

			ChannelGroup theGroup = seq.ChannelGroups[groupIndex];

			//IMember groupID = theGroup;
			string nodeText = theGroup.Name;
			TreeNode groupNode = null;

			if ((memberTypes & SeqEnums.MEMBER_ChannelGroup) > 0)
			{
				groupNode = baseNodes.Add(nodeText);

				nodeIndex++;
				groupNode.Tag = theGroup;
				groupNode.ImageKey = ICONchannelGroup;
				groupNode.SelectedImageKey = ICONchannelGroup;
				groupNode.Checked = theGroup.Selected;
				baseNodes = groupNode.Nodes;
			}
			List<TreeNode> qlist;

						for (int gi = 0; gi < theGroup.Members.Count; gi++)
			{
				//try
				//{
				IMember member = theGroup.Members.Items[gi];
				int si = member.SavedIndex;
				if (member.MemberType == MemberType.ChannelGroup)
				{
					ChannelGroup memGrp = (ChannelGroup)member;
					bool inclChan = false;
					if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
					bool inclRGB = false;
					if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
					int inclCount = memGrp.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					if (inclCount > 0)
					{
						TreeNode subGroupNode = Original_AddGroup(seq, baseNodes, member.Index, siNodes, selectedOnly, includeRGBchildren, memberTypes);
						qlist = siNodes[si];
						qlist.Add(subGroupNode);
					}
				}
				if (member.MemberType == MemberType.CosmicDevice)
				{
					CosmicDevice memDev = (CosmicDevice)member;
					bool inclChan = false;
					if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
					bool inclRGB = false;
					if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
					int inclCount = memDev.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					if (inclCount > 0)
					{
						TreeNode subGroupNode = Original_AddGroup(seq, baseNodes, member.Index, siNodes, selectedOnly, includeRGBchildren, memberTypes);
						qlist = siNodes[si];
						qlist.Add(subGroupNode);
					}
				}
				if (member.MemberType == MemberType.Channel)
				{
				if ((memberTypes & SeqEnums.MEMBER_Channel) > 0)
					{
						TreeNode channelNode = AddChannel(seq, baseNodes, member.Index, selectedOnly);
						qlist = siNodes[si];
						qlist.Add(channelNode);
					}
				}
				if (member.MemberType == MemberType.RGBchannel)
				{
					if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0)
					{
						TreeNode rgbChannelNode = Original_AddRGBchannel(seq, baseNodes, member.Index, siNodes, selectedOnly, includeRGBchildren);
						qlist = siNodes[si];
						qlist.Add(rgbChannelNode);
					}
				}
				#region catch
				/*
	} // end try
		catch (Exception ex)
		{
			StackTrace st = new StackTrace(ex, true);
			StackFrame sf = st.GetFrame(st.FrameCount - 1);
			string emsg = ex.ToString();
			emsg += ERRproc + seq.filename + ERRgrp + groupIndex.ToString() + ERRitem + gi.ToString();
			emsg += ERRline + sf.GetFileLineNumber();
			#if DEBUG
				Debugger.Break();
			#endif
			utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
		} // end catch
		*/
				#endregion

			} // End loop thru items
			return groupNode;
		} // end AddGroup

		private static TreeNode Original_AddCosmic(Sequence4 seq, TreeNodeCollection baseNodes, int deviceIndex, List<List<TreeNode>> siNodes, bool selectedOnly, bool includeRGBchildren, int memberTypes)
		{
			//ChanInfo nodeTag = new ChanInfo();
			//nodeTag.MemberType = MemberType.ChannelGroup;
			//nodeTag.objIndex = groupIndex;
			//nodeTag.SavedIndex = theGroup.SavedIndex;
			//nodeTag.nodeIndex = nodeIndex;

			CosmicDevice theDevice = seq.CosmicDevices[deviceIndex];

			//IMember groupID = theGroup;
			string nodeText = theDevice.Name;
			TreeNode deviceNode = null;

			if ((memberTypes & SeqEnums.MEMBER_CosmicDevice) > 0)
			{
				deviceNode = baseNodes.Add(nodeText);

				nodeIndex++;
				deviceNode.Tag = theDevice;
				deviceNode.ImageKey = ICONcosmicDevice;
				deviceNode.SelectedImageKey = ICONcosmicDevice;
				deviceNode.Checked = theDevice.Selected;
				baseNodes = deviceNode.Nodes;
			}
			List<TreeNode> qlist;

			// const string ERRproc = " in FillChannels-AddGroup(";
			// const string ERRgrp = "), in Device #";
			// const string ERRitem = ", Items #";
			// const string ERRline = ", Line #";

			for (int gi = 0; gi < theDevice.Members.Count; gi++)
			{
				//try
				//{
				IMember member = theDevice.Members.Items[gi];
				int si = member.SavedIndex;
				if (member.MemberType == MemberType.ChannelGroup)
				{
					ChannelGroup memGrp = (ChannelGroup)member;
					bool inclChan = false;
					if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
					bool inclRGB = false;
					if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
					int inclCount = memGrp.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					if (inclCount > 0)
					{
						TreeNode subGroupNode = Original_AddGroup(seq, baseNodes, member.Index, siNodes, selectedOnly, includeRGBchildren, memberTypes);
						qlist = siNodes[si];
						qlist.Add(subGroupNode);
					}
				}
				if (member.MemberType == MemberType.CosmicDevice)
				{
					CosmicDevice memDev = (CosmicDevice)member;
					bool inclChan = false;
					if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
					bool inclRGB = false;
					if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
					int inclCount = memDev.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					if (inclCount > 0)
					{
						TreeNode subGroupNode = Original_AddGroup(seq, baseNodes, member.Index, siNodes, selectedOnly, includeRGBchildren, memberTypes);
						qlist = siNodes[si];
						qlist.Add(subGroupNode);
					}
				}
				if (member.MemberType == MemberType.Channel)
				{
					if ((memberTypes & SeqEnums.MEMBER_Channel) > 0)
					{
						TreeNode channelNode = AddChannel(seq, baseNodes, member.Index, selectedOnly);
						qlist = siNodes[si];
						qlist.Add(channelNode);
					}
				}
				if (member.MemberType == MemberType.RGBchannel)
				{
					if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0)
					{
						TreeNode rgbChannelNode = Original_AddRGBchannel(seq, baseNodes, member.Index, siNodes, selectedOnly, includeRGBchildren);
						qlist = siNodes[si];
						qlist.Add(rgbChannelNode);
					}
				}
				#region catch
				/*
	} // end try
		catch (Exception ex)
		{
			StackTrace st = new StackTrace(ex, true);
			StackFrame sf = st.GetFrame(st.FrameCount - 1);
			string emsg = ex.ToString();
			emsg += ERRproc + seq.filename + ERRgrp + groupIndex.ToString() + ERRitem + gi.ToString();
			emsg += ERRline + sf.GetFileLineNumber();
			#if DEBUG
				Debugger.Break();
			#endif
			utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
		} // end catch
		*/
				#endregion

			} // End loop thru items
			return deviceNode;
		} // end AddGroup

		private static TreeNode AddGroup(Sequence4 seq, TreeNodeCollection baseNodes, int groupSI, List<TreeNode>[] siNodes, bool selectedOnly,
			bool includeRGBchildren, int memberTypes)
		{
			TreeNode groupNode = null;
			if (siNodes[groupSI] != null)
			{
				//ChanInfo nodeTag = new ChanInfo();
				//nodeTag.MemberType = MemberType.ChannelGroup;
				//nodeTag.objIndex = groupIndex;
				//nodeTag.SavedIndex = theGroup.SavedIndex;
				//nodeTag.nodeIndex = nodeIndex;

				//ChannelGroup theGroup = seq.ChannelGroups[groupIndex];
				ChannelGroup theGroup = (ChannelGroup)seq.Members.bySavedIndex[groupSI];

				//IMember groupID = theGroup;

				// Include groups in the TreeView?
				if ((memberTypes & SeqEnums.MEMBER_ChannelGroup) > 0)
				{
					string nodeText = theGroup.Name;
					groupNode = baseNodes.Add(nodeText);

					nodeIndex++;
					groupNode.Tag = theGroup;
					groupNode.ImageKey = ICONchannelGroup;
					groupNode.SelectedImageKey = ICONchannelGroup;
					groupNode.Checked = theGroup.Selected;
					baseNodes = groupNode.Nodes;
					siNodes[groupSI].Add(groupNode);
				}
				//List<TreeNode> qlist;

				// const string ERRproc = " in FillChannels-AddGroup(";
				// const string ERRgrp = "), in Group #";
				// const string ERRitem = ", Items #";
				// const string ERRline = ", Line #";

				for (int gi = 0; gi < theGroup.Members.Count; gi++)
				{
					//try
					//{
					IMember member = theGroup.Members.Items[gi];
					int si = member.SavedIndex;
					if (member.MemberType == MemberType.ChannelGroup)
					{
						ChannelGroup memGrp = (ChannelGroup)member;
						bool inclChan = false;
						if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
						bool inclRGB = false;
						if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
						int inclCount = memGrp.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
						if (inclCount > 0)
						{
							TreeNode subGroupNode = AddGroup(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren, memberTypes);
							//qlist = siNodes[si];
							//qlist.Add(subGroupNode);
						}
						int cosCount = memGrp.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					}
					if (member.MemberType == MemberType.CosmicDevice)
					{
						CosmicDevice memDev = (CosmicDevice)member;
						bool inclChan = false;
						if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
						bool inclRGB = false;
						if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
						int inclCount = memDev.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
						if (inclCount > 0)
						{
							TreeNode subGroupNode = AddGroup(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren, memberTypes);
							//qlist = siNodes[si];
							//qlist.Add(subGroupNode);
						}
						int cosCount = memDev.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					}
					if (member.MemberType == MemberType.Channel)
					{
						if ((memberTypes & SeqEnums.MEMBER_Channel) > 0)
						{
								TreeNode channelNode = AddChannel(seq, baseNodes, member.SavedIndex, selectedOnly);
								siNodes[si].Add(channelNode);
						}
					}
					if (member.MemberType == MemberType.RGBchannel)
					{
						if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0)
						{
								TreeNode rgbChannelNode = AddRGBchannel(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren);
								siNodes[si].Add(rgbChannelNode);
						}
					}
					#region catch
					/*
		} // end try
			catch (Exception ex)
			{
				StackTrace st = new StackTrace(ex, true);
				StackFrame sf = st.GetFrame(st.FrameCount - 1);
				string emsg = ex.ToString();
				emsg += ERRproc + seq.filename + ERRgrp + groupIndex.ToString() + ERRitem + gi.ToString();
				emsg += ERRline + sf.GetFileLineNumber();
				#if DEBUG
					Debugger.Break();
				#endif
				utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
			} // end catch
			*/
					#endregion

				} // End loop thru items
			}
			return groupNode;
		} // end AddGroup

		private static TreeNode AddDevice(Sequence4 seq, TreeNodeCollection baseNodes, int deviceSI, List<TreeNode>[] siNodes, bool selectedOnly,
			bool includeRGBchildren, int memberTypes)
		{
			TreeNode deviceNode = null;
			if (siNodes[deviceSI] != null)
			{
				//ChanInfo nodeTag = new ChanInfo();
				//nodeTag.MemberType = MemberType.ChannelGroup;
				//nodeTag.objIndex = groupIndex;
				//nodeTag.SavedIndex = theGroup.SavedIndex;
				//nodeTag.nodeIndex = nodeIndex;

				//ChannelGroup theGroup = seq.ChannelGroups[groupIndex];
				CosmicDevice theDevice = (CosmicDevice)seq.Members.bySavedIndex[deviceSI];

				//IMember groupID = theGroup;

				// Include groups in the TreeView?
				if ((memberTypes & SeqEnums.MEMBER_CosmicDevice) > 0)
				{
					string nodeText = theDevice.Name;
					deviceNode = baseNodes.Add(nodeText);

					nodeIndex++;
					deviceNode.Tag = theDevice;
					deviceNode.ImageKey = ICONcosmicDevice;
					deviceNode.SelectedImageKey = ICONcosmicDevice;
					deviceNode.Checked = theDevice.Selected;
					baseNodes = deviceNode.Nodes;
					siNodes[deviceSI].Add(deviceNode);
				}
				//List<TreeNode> qlist;

				// const string ERRproc = " in FillChannels-AddGroup(";
				// const string ERRgrp = "), in Group #";
				// const string ERRitem = ", Items #";
				// const string ERRline = ", Line #";

				for (int gi = 0; gi < theDevice.Members.Count; gi++)
				{
					//try
					//{
					IMember member = theDevice.Members.Items[gi];
					int si = member.SavedIndex;
					if (member.MemberType == MemberType.ChannelGroup)
					{
						ChannelGroup memGrp = (ChannelGroup)member;
						bool inclChan = false;
						if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
						bool inclRGB = false;
						if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
						int inclCount = memGrp.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
						if (inclCount > 0)
						{
							TreeNode subGroupNode = AddGroup(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren, memberTypes);
							//qlist = siNodes[si];
							//qlist.Add(subGroupNode);
						}
						int cosCount = memGrp.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					}
					if (member.MemberType == MemberType.CosmicDevice)
					{
						CosmicDevice memDev = (CosmicDevice)member;
						bool inclChan = false;
						if ((memberTypes & SeqEnums.MEMBER_Channel) > 0) inclChan = true;
						bool inclRGB = false;
						if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0) inclRGB = true;
						int inclCount = memDev.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
						if (inclCount > 0)
						{
							TreeNode subGroupNode = AddGroup(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren, memberTypes);
							//qlist = siNodes[si];
							//qlist.Add(subGroupNode);
						}
						int cosCount = memDev.Members.DescendantCount(selectedOnly, inclChan, inclRGB, includeRGBchildren);
					}
					if (member.MemberType == MemberType.Channel)
					{
						if ((memberTypes & SeqEnums.MEMBER_Channel) > 0)
						{
								TreeNode channelNode = AddChannel(seq, baseNodes, member.SavedIndex, selectedOnly);
								siNodes[si].Add(channelNode);
						}
					}
					if (member.MemberType == MemberType.RGBchannel)
					{
						if ((memberTypes & SeqEnums.MEMBER_RGBchannel) > 0)
						{
								TreeNode rgbChannelNode = AddRGBchannel(seq, baseNodes, member.SavedIndex, siNodes, selectedOnly, includeRGBchildren);
								siNodes[si].Add(rgbChannelNode);
						}
					}
					#region catch
					/*
		} // end try
			catch (Exception ex)
			{
				StackTrace st = new StackTrace(ex, true);
				StackFrame sf = st.GetFrame(st.FrameCount - 1);
				string emsg = ex.ToString();
				emsg += ERRproc + seq.filename + ERRgrp + groupIndex.ToString() + ERRitem + gi.ToString();
				emsg += ERRline + sf.GetFileLineNumber();
				#if DEBUG
					Debugger.Break();
				#endif
				utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
			} // end catch
			*/
					#endregion

				} // End loop thru items
			}
			return deviceNode;
		} // end AddGroup

		private static void AddNode(List<TreeNode> nodeList, TreeNode nOde)
		{
			nodeList.Add(nOde);
			/*
			if (nodeList == null)
			{
				//Array.Resize(ref nodeList, 1);
				nodeList[0].
 			}
			else
			{
				Array.Resize(ref nodeList, nodeList.Length + 1);
				nodeList[nodeList.Length - 1] = nOde;
			}
			*/
		}

		private static TreeNode Original_AddChannel(Sequence4 seq, TreeNodeCollection baseNodes, int channelIndex, bool selectedOnly)
		{
			string nodeText = seq.Channels[channelIndex].Name;
			TreeNode channelNode = baseNodes.Add(nodeText);
			Channel theChannel = seq.Channels[channelIndex];
			//IMember nodeTag = theChannel;
			nodeIndex++;
			channelNode.Tag = theChannel;
			//channelNode.ImageIndex = imlTreeIcons.Images.IndexOfKey("Channel");
			//channelNode.SelectedImageIndex = imlTreeIcons.Images.IndexOfKey("Channel");
			//channelNode.ImageKey = ICONchannel;
			//channelNode.SelectedImageKey = ICONchannel;


			ImageList icons = baseNodes[0].TreeView.ImageList;
			int iconIndex = ColorIcon(icons, seq.Channels[channelIndex].color);
			channelNode.ImageIndex = iconIndex;
			channelNode.SelectedImageIndex = iconIndex;
			channelNode.Checked = theChannel.Selected;


			return channelNode;
		}

		private static TreeNode Original_AddRGBchannel(Sequence4 seq, TreeNodeCollection baseNodes, int RGBIndex, List<List<TreeNode>> siNodes, bool selectedOnly, bool includeRGBchildren)
		{
			List<TreeNode> qlist;

			string nodeText = seq.RGBchannels[RGBIndex].Name;
			TreeNode channelNode = baseNodes.Add(nodeText);
			RGBchannel theRGB = seq.RGBchannels[RGBIndex];
			//IMember nodeTag = theRGB;
			nodeIndex++;
			channelNode.Tag = theRGB;
			channelNode.ImageKey = ICONrgbChannel;
			channelNode.SelectedImageKey = ICONrgbChannel;
			channelNode.Checked = theRGB.Selected;

			if (includeRGBchildren)
			{
				// * * R E D   S U B  C H A N N E L * *
				int ci = seq.RGBchannels[RGBIndex].redChannel.Index;
				nodeText = seq.Channels[ci].Name;
				TreeNode colorNode = channelNode.Nodes.Add(nodeText);
				//nodeTag = seq.Channels[ci];
				nodeIndex++;
				colorNode.Tag = seq.Channels[ci];
				colorNode.ImageKey = ICONredChannel;
				colorNode.SelectedImageKey = ICONredChannel;
				colorNode.Checked = seq.Channels[ci].Selected;
				qlist = siNodes[seq.Channels[ci].SavedIndex];
				qlist.Add(colorNode);

				// * * G R E E N   S U B  C H A N N E L * *
				ci = seq.RGBchannels[RGBIndex].grnChannel.Index;
				nodeText = seq.Channels[ci].Name;
				colorNode = channelNode.Nodes.Add(nodeText);
				//nodeTag = seq.Channels[ci];
				nodeIndex++;
				colorNode.Tag = seq.Channels[ci];
				colorNode.ImageKey = ICONgrnChannel;
				colorNode.SelectedImageKey = ICONgrnChannel;
				colorNode.Checked = seq.Channels[ci].Selected;
				qlist = siNodes[seq.Channels[ci].SavedIndex];
				qlist.Add(colorNode);

				// * * B L U E   S U B  C H A N N E L * *
				ci = seq.RGBchannels[RGBIndex].bluChannel.Index;
				nodeText = seq.Channels[ci].Name;
				colorNode = channelNode.Nodes.Add(nodeText);
				//nodeTag = seq.Channels[ci];
				nodeIndex++;
				colorNode.Tag = seq.Channels[ci];
				colorNode.ImageKey = ICONbluChannel;
				colorNode.SelectedImageKey = ICONbluChannel;
				colorNode.Checked = seq.Channels[ci].Selected;
				qlist = siNodes[seq.Channels[ci].SavedIndex];
				qlist.Add(colorNode);
			} // end includeRGBchildren

			return channelNode;
		}

		private static TreeNode AddChannel(Sequence4 seq, TreeNodeCollection baseNodes, int channelSI, bool selectedOnly)
		{
			Channel theChannel = (Channel) seq.Members.bySavedIndex[channelSI];
			string nodeText = theChannel.Name;
			TreeNode channelNode = baseNodes.Add(nodeText);
			//IMember nodeTag = theChannel;
			nodeIndex++;
			channelNode.Tag = theChannel;
			//channelNode.ImageIndex = imlTreeIcons.Images.IndexOfKey("Channel");
			//channelNode.SelectedImageIndex = imlTreeIcons.Images.IndexOfKey("Channel");
			//channelNode.ImageKey = ICONchannel;
			//channelNode.SelectedImageKey = ICONchannel;


			ImageList icons = baseNodes[0].TreeView.ImageList;
			int iconIndex = ColorIcon(icons, theChannel.color);
			channelNode.ImageIndex = iconIndex;
			channelNode.SelectedImageIndex = iconIndex;
			channelNode.Checked = theChannel.Selected;


			return channelNode;
		}

		private static TreeNode AddRGBchannel(Sequence4 seq, TreeNodeCollection baseNodes, int RGBsi, List<TreeNode>[] siNodes, bool selectedOnly, bool includeRGBchildren)
		{
			TreeNode channelNode = null;

			if (siNodes[RGBsi] != null)
			{ 
				RGBchannel theRGB = (RGBchannel)seq.Members.bySavedIndex[RGBsi];
				string nodeText = theRGB.Name;
				channelNode = baseNodes.Add(nodeText);
				//IMember nodeTag = theRGB;
				nodeIndex++;
				channelNode.Tag = theRGB;
				channelNode.ImageKey = ICONrgbChannel;
				channelNode.SelectedImageKey = ICONrgbChannel;
				channelNode.Checked = theRGB.Selected;

				if (includeRGBchildren)
				{
					// * * R E D   S U B  C H A N N E L * *
					TreeNode colorNode = null;
					int ci = theRGB.redChannel.SavedIndex;
						nodeText = theRGB.redChannel.Name;
						colorNode = channelNode.Nodes.Add(nodeText);
						//nodeTag = seq.Channels[ci];
						nodeIndex++;
						colorNode.Tag = theRGB.redChannel;
						colorNode.ImageKey = ICONredChannel;
						colorNode.SelectedImageKey = ICONredChannel;
						colorNode.Checked = theRGB.redChannel.Selected;
						siNodes[ci].Add(colorNode);
						channelNode.Nodes.Add(colorNode);

					// * * G R E E N   S U B  C H A N N E L * *
					ci = theRGB.grnChannel.SavedIndex;
						nodeText = theRGB.grnChannel.Name;
						colorNode = channelNode.Nodes.Add(nodeText);
						//nodeTag = seq.Channels[ci];
						nodeIndex++;
						colorNode.Tag = theRGB.grnChannel;
						colorNode.ImageKey = ICONgrnChannel;
						colorNode.SelectedImageKey = ICONgrnChannel;
						colorNode.Checked = theRGB.grnChannel.Selected;
						siNodes[ci].Add(colorNode);
						channelNode.Nodes.Add(colorNode);
					
					// * * B L U E   S U B  C H A N N E L * *
					ci = theRGB.bluChannel.SavedIndex;
					if (siNodes[ci] != null)
						nodeText = theRGB.bluChannel.Name;
						colorNode = channelNode.Nodes.Add(nodeText);
						//nodeTag = seq.Channels[ci];
						nodeIndex++;
						colorNode.Tag = seq.Channels[ci];
						colorNode.ImageKey = ICONbluChannel;
						colorNode.SelectedImageKey = ICONbluChannel;
						colorNode.Checked = theRGB.bluChannel.Selected;
						siNodes[ci].Add(colorNode);
						channelNode.Nodes.Add(colorNode);
				} // end includeRGBchildren
			}
			return channelNode;
		}

		public static int ColorIcon(ImageList icons, Int32 colorVal)
		{
			int ret = -1;
			string tempID = colorVal.ToString("X6");
			// LOR's Color Format is in BGR format, so have to reverse the Red and the Blue
			string colorID = tempID.Substring(4, 2) + tempID.Substring(2, 2) + tempID.Substring(0, 2);
			ret = icons.Images.IndexOfKey (colorID);
			if (ret < 0)
			{
				// Convert rearranged hex value a real color
				Color theColor = System.Drawing.ColorTranslator.FromHtml("#" + colorID);
				// Create a temporary working bitmap
				Bitmap bmp = new Bitmap(16,16);
				// get the graphics handle from it
				Graphics gr = Graphics.FromImage(bmp);
				// A colored solid brush to fill the middle
				SolidBrush b = new SolidBrush(theColor);
				// define a rectangle for the middle
				Rectangle r = new Rectangle(2, 2, 12, 12);
				// Fill the middle rectangle with color
				gr.FillRectangle(b, r);
				// Draw a 3D button around it
				Pen p = new Pen(Color.Black);
				gr.DrawLine(p, 1, 15, 15, 15);
				gr.DrawLine(p, 15, 1, 15, 14);
				p = new Pen(Color.DarkGray);
				gr.DrawLine(p, 2, 14, 14, 14);
				gr.DrawLine(p, 14, 2, 14, 13);
				p = new Pen(Color.White);
				gr.DrawLine(p, 0, 0, 15, 0);
				gr.DrawLine(p, 0, 1, 0, 15);
				p = new Pen(Color.LightGray);
				gr.DrawLine(p, 1, 1, 14, 1);
				gr.DrawLine(p, 1, 2, 1, 14);

				// Add it to the image list, using it's hex color code as the key
				icons.Images.Add(colorID, bmp);
				// get it's numeric index
				ret = icons.Images.Count - 1;
			}
			// Return the numeric index of the new image
			return ret;
		}

		public static string ShortenLongPath(string longPath, int maxLen)
		{
			//TODO I'm not too pleased with the current results of this function
			//TODO Try to make something better

			string shortPath = longPath;
			// Can't realistically shorten a path and filename to much less than 18 characters, reliably
			if (maxLen > 18)
			{
				// Do even need to shorten it all?
				if (longPath.Length > maxLen)
				{
					// Split it into pieces, get count
					string[] splits = longPath.Split('\\');
					int parts = splits.Length;
					int h = maxLen / 2;
					// loop thru, look for excessively long single pieces
					for (int i = 0; i < parts; i++)
					{
						if (splits[i].Length > h)
						{
							// Is it the filename itself that's too long?
							if (i == (parts - 1))
							{
								// if filename is too long, shorten it, but not as aggressively as a folder
								if (splits[i].Length > (maxLen * .7))
								{
									// shorten filename to "xxxxx…xxxx" (10 characters)
									// which should include .ext assuming a 3 char extension
									splits[i] = splits[i].Substring(0, 5) + "…" + splits[i].Substring(splits[i].Length - 4, 4);
								}
							}
							else
							{
								// shorten folder to "xxx…xxx" (7 characters)
								splits[i] = splits[i].Substring(0, 3) + "…" + splits[i].Substring(splits[i].Length - 3, 3);
							}
						}
					}

					// at minimum, we want the filename, lets start with that
					shortPath = splits[parts - 1];
					// figure out what drive it is on
					string drive = "";
					//byte b = 0;
					if (splits[0].Length == 2)
					{
						// Regular drive letter like C:
						drive = splits[0] + "\\";
						//b = 1;
					}
					if (splits[0].Length + splits[1].Length == 0)
					{
						// UNC path like //server/share
						drive = "\\\\" + splits[0] + "\\" + splits[1] + "\\";
						//b = 2;
					}
					// if drive + filename is still short enough, change to that
					if ((shortPath.Length + drive.Length + 2) <= maxLen)
					{
						shortPath = drive + "…\\" + shortPath;
					}
					// if drive + last folder + filename is still short enough, change to that
					if ((shortPath.Length + splits[parts - 2].Length + 1) <= maxLen)
					{
						shortPath = drive + "…\\" + splits[parts - 2] + "\\" + splits[parts - 1];
					}
					// if drive + first folder + last folder + filename is still short enough, change to that
					if ((shortPath.Length + splits[1].Length + 1) <= maxLen)
					{
						shortPath = drive + splits[1] + "\\…\\" + splits[parts - 2] + "\\" + splits[parts - 1];
					}
				} // end if (longPath.Length > maxLen)
			} // end if (maxLen > 18)
				// whatever we ended up with, return it
			return shortPath;
		} // end ShortenLongPath(string longPath, int maxLen)

		/*
		public static int FindName(string[] names, string Name)
		{
			return Array.BinarySearch(names, Name);
		} // end FindName

		public static int FuzzyFindName(string[] names, string Name)
		{
			return FuzzyFindName(names, Name, .8, .95);
		}

		public static int FuzzyFindName(string[] names, string Name, double preMatchMin, double finalMatchMin)
		{
			// names[] do not have to be sorted (although they can be)

			int ret = UNDEFINED;  // default value, no match
			int[] preIdx = null;
			double[] finalMatchVals = null;
			int preMatchCount = 0;
			double matchVal = 0;

			// Loop thu ALL names
			for (int n=0; n< names.Length; n++)
			{
				// calculate a quick prematch value
				matchVal = names[n].LevenshteinDistance(Name);
				// if above the minimum
				if (matchVal > preMatchMin)
				{
					// add to array of prematches
					Array.Resize(ref preIdx, preMatchCount + 1);
					preIdx[preMatchCount] = n;
					preMatchCount++;
				}
			}
			// any prematches found?
			if (preMatchCount > 0)
			{
				// size array to hold final match values
				Array.Resize(ref finalMatchVals, preMatchCount);
				// loop thru the prematches
				for (int nn = 0; nn < preMatchCount; nn++)
				{
					// calculate and remember the final match value
					finalMatchVals[nn] = names[preIdx[nn]].RankEquality(Name);
				}
				// sort the prematches by their final match value
				Array.Sort(finalMatchVals, preIdx);
				// Is the last one (which will have the highest final match value once sorted)
				// above the final minimum?
				if (finalMatchVals[preMatchCount - 1] > finalMatchMin)
				{
					// set return value to it's index
					ret = preIdx[preMatchCount - 1];
				}
			}
			// return index of best match if found,
			// default of undefined if not
			return ret;
		} // end FuzzyFindName
		*/

		public static int InvalidCharacterCount(string testName)
		{
			int ret = 0;
			int pos1 = 0;
			int pos2 = UNDEFINED;

			// These are not valid anywhere
			char[] badChars = { '<', '>', '\"', '/', '|', '?', '*' };
			for (int c = 0; c < badChars.Length; c++)
			{
				pos1 = 0;
				pos2 = testName.IndexOf(badChars[c], pos1);
				while (pos2 > UNDEFINED)
				{
					ret++;
					pos1 = pos2 + 1;
					pos2 = testName.IndexOf(badChars[c], pos1);
				}
			}

			// and the colon is not valid past position 2
			pos1 = 2;
			pos2 = testName.IndexOf(':', pos1);
			while (pos2 > UNDEFINED)
			{
				ret++;
				pos1 = pos2 + 1;
				pos2 = testName.IndexOf(':', pos1);
			}

			return ret;
		}

		private static string NotifyGenericSound
		{
			get
			{
				const string keyName = "HKEY_CURRENT_USER\\AppEvents\\Schemes\\Apps\\.Default\\Notification.Default";
				string sound = (string)Registry.GetValue(keyName, null, "");
				return sound;
			} // End get the Notify.Generic Sound filename
		}

		public static void PlayNotifyGenericSound()
		{
			string sound = NotifyGenericSound;
			if (sound.Length > 6)
			{
				if (File.Exists(sound))
				{
					SoundPlayer player = new SoundPlayer(sound);
					player.Play();
				}
			}
		}

		private static string MenuClickSound
		{
			get
			{
				const string keyName = "HKEY_CURRENT_USER\\AppEvents\\Schemes\\Apps\\.Default\\MenuCommand";
				string sound = (string)Registry.GetValue(keyName, null, "");
				return sound;
			} // End get the Notify.Generic Sound filename
		}

		public static void PlayMenuClickSound()
		{
			string sound = MenuClickSound;
			if (sound.Length > 6)
			{
				if (File.Exists(sound))
				{
					SoundPlayer player = new SoundPlayer(sound);
					player.Play();
				}
			}
		}

		public static void WriteLogEntry(string message, string logType, string applicationName)
		{
			string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			string mySubDir = "\\UtilORama\\";
			if (applicationName.Length > 2)
			{
				applicationName.Replace("-", "");
				mySubDir += applicationName + "\\";
			}
			string file = appDataDir + mySubDir;
			if (!Directory.Exists(file)) Directory.CreateDirectory(file);
			file += logType + ".log";
			//string dt = DateTime.Now.ToString("yyyy-MM-dd ")
			string dt = DateTime.Now.ToString("s") + "=";
			string msgLine = dt + message;
			try
			{
				StreamWriter writer = new StreamWriter(file, append: true);
				writer.WriteLine(msgLine);
				writer.Flush();
				writer.Close();
			}
			catch (System.IO.IOException ex)
			{
				string errMsg = "An error has occurred in this application!\r\n";
				errMsg += "Another error has occurred while trying to write the details of the first error to a log file!\r\n\r\n";
				errMsg += "The first error was: " + message + "\r\n";
				errMsg += "The second error was: " + ex.ToString();
				errMsg += "The log file is: " + file;
				DialogResult dr = MessageBox.Show(errMsg, "Errors!", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error);
			}
			finally
			{
			}

		} // end write log entry


		public static string DefaultUserDataPath
		{
			get
			{
				string fldr = "";
				string root = ROOT;
				string userDocs = DefaultDocumentsPath;
				try
				{
					fldr = (string)Registry.GetValue(LOR_REGKEY, "UserDataPath", root);
					if (fldr.Length < 6)
					{
						fldr = userDocs + LOR_DIR;
					}
					bool valid = IsValidPath(fldr);
					if (!valid)
					{
						fldr = userDocs + LOR_DIR;
					}
					if (!Directory.Exists(fldr))
					{
						Directory.CreateDirectory(fldr);
					}
				}
				catch
				{
					fldr = userDocs;
				}
				return fldr;
			} // End get UserDataPath
		}

		public static string DefaultNonAudioPath
		{
			// AKA Sequences Folder
			get
			{
				string fldr = "";
				string root = ROOT;
				string userDocs = DefaultDocumentsPath;
				try
				{
					fldr = (string)Registry.GetValue(LOR_REGKEY, "NonAudioPath", root);
					if (fldr.Length < 6)
					{
						fldr = DefaultUserDataPath + "Sequences\\";
					}
					bool valid = IsValidPath(fldr);
					if (!valid)
					{
						fldr = DefaultUserDataPath + "Sequences\\";
					}
					if (!Directory.Exists(fldr))
					{
						Directory.CreateDirectory(fldr);
					}
				}
				catch
				{
					fldr = userDocs;
				}
				return fldr;
			} // End get NonAudioPath (Sequences)
		}

		public static string DefaultAuthor
		{
			get
			{
				string author = "";
				string root = "";
				string userDocs = DefaultDocumentsPath;
				try
				{
					string ky = "HKEY_CURRENT_USER\\Software\\Light-O-Rama\\Editor\\New Sequence";
					author = (string)Registry.GetValue(ky, "Author", root);
					if (author.Length < 1)
					{
						author = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
					}
				}
				catch
				{
					author = "ERROR!";
				}
				return author;
			}
		}


		public static string DefaultVisualizationsPath
		{
			get
			{
				string fldr = "";
				string root = ROOT;
				string userDocs = DefaultDocumentsPath;
				try
				{
					fldr = (string)Registry.GetValue(LOR_REGKEY, "VisualizationsPath", root);
					if (fldr.Length < 6)
					{
						fldr = DefaultUserDataPath + "Visualizations\\";
					}
					bool valid = IsValidPath(fldr);
					if (!valid)
					{
						fldr = DefaultUserDataPath + "Visualizations\\";
					}
					if (!Directory.Exists(fldr))
					{
						Directory.CreateDirectory(fldr);
					}
				}
				catch
				{
					fldr = userDocs;
				}
				return fldr;
			} // End get Visualizations Path
		}

		public static string DefaultSequencesPath
		{
			get
			{
				return DefaultNonAudioPath;
			}
		}


		public static string DefaultAudioPath
		{
			get
			{
				string fldr = "";
				string root = ROOT;
				string userDocs = DefaultDocumentsPath;
				string userMusic = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
				try
				{
					fldr = (string)Registry.GetValue(LOR_REGKEY, "AudioPath", root);
					if (fldr.Length < 6)
					{
						fldr = DefaultUserDataPath + "Audio\\";
					}
					bool valid = IsValidPath(fldr);
					if (!valid)
					{
						fldr = DefaultUserDataPath + "Audio\\";
					}
					if (!Directory.Exists(fldr))
					{
						Directory.CreateDirectory(fldr);
					}
				}
				catch
				{
					fldr = userMusic;
				}
				return fldr;
			} // End get AudioPath
		}

		public static string DefaultClipboardsPath
		{
			get
			{
				string fldr = "";
				string root = ROOT;
				string userDocs = DefaultDocumentsPath;
				try
				{
					fldr = (string)Registry.GetValue(LOR_REGKEY, "ClipboardsPath", root);
					if (fldr.Length < 6)
					{
						fldr = DefaultUserDataPath + "Clipboards\\";
					}
					bool valid = IsValidPath(fldr);
					if (!valid)
					{
						fldr = DefaultUserDataPath + "Clipboards\\";
					}
					if (!Directory.Exists(fldr))
					{
						Directory.CreateDirectory(fldr);
					}
				}
				catch
				{
					fldr = userDocs;
				}
				return fldr;
			} // End get ClipboardsPath
		}

		public static string DefaultChannelConfigsPath
		{
			get
			{
				string fldr = "";
				// string root = ROOT;
				string userDocs = DefaultDocumentsPath;
				try
				{
					fldr = (string)Registry.GetValue(LOR_REGKEY, "ChannelConfigsPath", "");
					if (fldr.Length < 6)
					{
						fldr = DefaultUserDataPath + "Sequences\\ChannelConfigs\\";
						Registry.SetValue(LOR_REGKEY, "ChannelConfigsPath", fldr, RegistryValueKind.String);
					}
					bool valid = IsValidPath(fldr);
					if (!valid)
					{
						fldr = DefaultUserDataPath + "Sequences\\ChannelConfigs\\";
						Registry.SetValue(LOR_REGKEY, "ChannelConfigsPath", fldr, RegistryValueKind.String);
					}
					if (!Directory.Exists(fldr))
					{
						Directory.CreateDirectory(fldr);
					}
				}
				catch
				{
					fldr = userDocs;
				}
				return fldr;
			} // End get ChannelConfigsPath
		}

		public static string DefaultDocumentsPath
		{
			get
			{
				string myDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
				if (myDocs.Substring(myDocs.Length - 1, 1).CompareTo("\\") != 0) myDocs += "\\";
				return myDocs;
			}
		}

		public static bool IsValidPath(string pathToCheck)
		{
			// Checks to see if path looks valid, does NOT check if it exists
			bool ret = false;
			try
			{
				string x = Path.GetFullPath(pathToCheck);
				ret = true;
				ret = Path.IsPathRooted(pathToCheck);
			}
			catch
			{
				ret = false;
			}
			return ret;
		}

		public static bool IsValidPath(string pathToCheck, bool andExists)
		{
			// Checks to see if path looks valid AND if it exists
			bool ret = IsValidPath(pathToCheck);
			if (ret)
			{
				try
				{
					string p = Path.GetDirectoryName(pathToCheck);
					ret = Directory.Exists(p);
				}
				catch
				{
					ret = false;
				}
			}
			return ret;
		}

		public static bool IsValidPath(string pathToCheck, bool andExists, bool tryToCreate)
		{
			// Checks to see if path looks valid AND if it exists
			// Tries to create it seemingly valid but not existent
			// Returns true only if successfully created/exists
			// Note: andExists parameter ignored, not used
			bool ret = IsValidPath(pathToCheck);
			if (ret)
			{
				try
				{
					ret = Directory.Exists(pathToCheck);
					if (!ret)
					{
						Directory.CreateDirectory(pathToCheck);
						ret = Directory.Exists(pathToCheck);
					}
				}
				catch
				{
					ret = false;
				}
			}
			return ret;
		}

		public static string WindowfyFilename(string proposedName, bool justName)
		{
			string finalName = proposedName;
			finalName = finalName.Replace('?', 'Ɂ');
			finalName = finalName.Replace('%', '‰');
			finalName = finalName.Replace('*', '＊');
			finalName = finalName.Replace('|', '∣');
			finalName = finalName.Replace("\"", "ʺ");
			finalName = finalName.Replace("&quot;", "ʺ");
			finalName = finalName.Replace('<', '˂');
			finalName = finalName.Replace('>', '˃');
			finalName = finalName.Replace('$', '﹩');
			if (justName)
			{
				// These are valid in a path as separators, but not in a file name
				finalName = finalName.Replace('/', '∕');
				finalName = finalName.Replace("\\", "╲");
				finalName = finalName.Replace(':', '：');
			}
			else
			{
				// Not valid in a WINDOWS path
				finalName = finalName.Replace('/', '\\');
			}


			return finalName;
		}


		public static bool IsWizard
		{
			get
			{
				bool ret = false;
				string usr = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
				usr = usr.ToLower();
				int i = usr.IndexOf("wizard");
				if (i >= 0) ret = true;
				return ret;
			}
		}

		public static string FileCreatedAt(string filename)
		{
			string ret = "";
			if (File.Exists(filename))
			{
				DateTime dt = File.GetCreationTime(filename);
				ret = dt.ToString(FORMAT_DATETIME);
			}
			return ret;
		}

		public static DateTime FileCreatedDateTime(string filename)
		{
			DateTime ret = new DateTime();
			if (File.Exists(filename))
			{
				ret = File.GetCreationTime(filename);
			}
			return ret;
		}

		public static string FileModiedAt(string filename)
		{
			string ret = "";
			if (File.Exists(filename))
			{
				DateTime dt = File.GetLastWriteTime(filename);
				ret = dt.ToString(FORMAT_DATETIME);
			}
			return ret;
		}

		public static string FormatDateTime(DateTime dt)
		{
			string ret = dt.ToString(FORMAT_DATETIME);
			return ret;
		}

		public static DateTime fileModiedDateTime(string filename)
		{
			DateTime ret = new DateTime();
			if (File.Exists(filename))
			{
				ret = File.GetLastWriteTime(filename);
			}
			return ret;
		}

		public static string FileSizeFormated(string filename)
		{
			long sz = GetFileSize(filename);
			return FileSizeFormated(sz, "");
		}

		public static string FileSizeFormated(string filename, string thousands)
		{
			long sz = GetFileSize(filename);
			return FileSizeFormated(sz, thousands);
		}

		public static string FileSizeFormated(long filesize)
		{
			return FileSizeFormated(filesize, "");
		}

		public static string FileSizeFormated(long filesize, string thousands)
		{
			string thou = thousands.ToUpper();
			string ret = "0";
			if (thou == "B") // Force value in Bytes
			{
				ret = Bytes(filesize);
			}
			else
			{
				if (thou == "K") // Force value in KiloBytes
				{
					ret = KiloBytes(filesize);
				}
				else
				{
					if (thou == "M") // Force value in MegaBytes
					{
						ret = MegaBytes(filesize);
					}
					else
					{
						if (thou == "G") // Force value in GigaBytes
						{
							ret = GigaBytes(filesize);
						}
						else
						{
							thou = ""; // Return value in nearest size group
							if (filesize < 100000)
							{
								ret = Bytes(filesize);
							}
							else
							{
								if (filesize < 100000000)
								{
									ret = KiloBytes(filesize);
								}
								else
								{
									if (filesize < 100000000000)
									{
										ret = MegaBytes(filesize);
									}
									else
									{
										//if (filesize < 1099511627776)
										//{
										ret = GigaBytes(filesize);
										//}
									}
								}
							}
						}
					}
				}
			}
			return ret;
		}

		private static string Bytes(long size)
		{
			return size.ToString(FORMAT_FILESIZE) + " Bytes";
		}

		private static string KiloBytes(long size)
		{
			long k = size >> 10;
			string ret = k.ToString(FORMAT_FILESIZE);
			if (k < 100)
			{
				double r = (int)(size % 0x400);
				int d = 0;
				double f = 0;
				if (k < 10) f = (r / 10D); else f = (r / 100D);
				d = (int)Math.Round(f);
				ret += "." + d.ToString();
			}
			else
			{
				double ds = (double)size;
				double dk = Math.Round(ds / 1024D);
				k = (int)dk;
				ret = k.ToString(FORMAT_FILESIZE);
			}
			ret += " KB";
			return ret;
		}

		private static string MegaBytes(long size)
		{
			long m = size >> 20;
			string ret = m.ToString(FORMAT_FILESIZE);
			if (m < 100)
			{
				double r = (int)(size % 0x10000);
				int d = 0;
				double f = 0;
				if (m < 10) f = (r / 10000D); else f = (r / 100000D);
				d = (int)Math.Round(f);
				ret += "." + d.ToString();
			}
			else
			{
				double ds = (double)size;
				double dm = Math.Round(ds / 1048576D);
				m = (int)dm;
				ret = m.ToString(FORMAT_FILESIZE);
			}
			ret += " MB";
			return ret;
		}

		private static string GigaBytes(long size)
		{
			long g = size >> 30;
			string ret = g.ToString(FORMAT_FILESIZE);
			if (g < 100)
			{
				double r = (int)(size % 0x40000000);
				int d = 0;
				double f = 0;
				if (g < 10) f = (r / 10000000D); else f = (r / 100000000D);
				d = (int)Math.Round(f);
				ret += "." + d.ToString();
			}
			else
			{
				double ds = (double)size;
				double dg = Math.Round(ds / 1073741824D);
				g = (int)dg;
				ret = g.ToString(FORMAT_FILESIZE);
			}
			ret += " GB";
			return ret;
		}


		public static long GetFileSize(string filename)
		{
				long ret = 0;
				if (File.Exists(filename))
				{
					FileInfo fi = new FileInfo(filename);
					ret = fi.Length;
				}
				return ret;
		}

		public static string HumanizeName(string XMLizedName)
		{
			// Takes a name from XML and converts symbols back to the real thing
			string ret = XMLizedName;
			ret = ret.Replace("&quot", "\"");
			return ret;
		}

		public static string XMLifyName(string HumanizedName)
		{
			// Takes a human friendly name, possibly with illegal symbols in it
			// And replaces the illegal symbols with codes to make it XML friendly
			string ret = HumanizedName;
			ret = ret.Replace("\"", "&quot");
			return ret;
		}

		public static int ContainsKey(string lineIn, string keyWord)
		{
			string lowerLine = lineIn.ToLower();
			string lowerWord = keyWord.ToLower();
			int pos1 = UNDEFINED;
			// int pos2 = UNDEFINED;
			// string fooo = "";

			//pos1 = lowerLine.IndexOf(lowerWord + "=");
			pos1 = FastIndexOf(lowerLine, lowerWord);
			return pos1;
		}

		public static Int32 getKeyValue(string lineIn, string keyWord)
		{
			int p = ContainsKey(lineIn, keyWord + "=\"");
			if (p >= 0)
			{
				return getKeyValue(p, lineIn, keyWord);
			}
			else
			{
				return utils.UNDEFINED;
			}
		}

		public static Int32 getKeyValue(int pos1, string lineIn, string keyWord)
		{
			Int32 valueOut = UNDEFINED;
			int pos2 = UNDEFINED;
			string fooo = "";

			fooo = lineIn.Substring(pos1 + keyWord.Length + 2);
			pos2 = fooo.IndexOf("\"");
			fooo = fooo.Substring(0, pos2);
			valueOut = Convert.ToInt32(fooo);
			return valueOut;
		}

		public static string getKeyWord(string lineIn, string keyWord)
		{
			int p = ContainsKey(lineIn, keyWord + "=\"");
			if (p >= 0)
			{
				return getKeyWord(p, lineIn, keyWord);
			}
			else
			{
				return "";
			}

		}

		public static string getKeyWord(int pos1, string lineIn, string keyWord)
		{
			string valueOut = "";
			int pos2 = UNDEFINED;
			string fooo = "";

			fooo = lineIn.Substring(pos1 + keyWord.Length + 2);
			pos2 = fooo.IndexOf("\"");
			fooo = fooo.Substring(0, pos2);
			valueOut = fooo;

			return valueOut;
		}

		public static bool getKeyState(string lineIn, string keyWord)
		{
			int p = ContainsKey(lineIn, keyWord + "=\"");
			if (p >= 0)
			{
				return getKeyState(p, lineIn, keyWord);
			}
			else
			{
				return false;
			}
		}

		public static bool getKeyState(int pos1, string lineIn, string keyWord)
		{
			bool stateOut = false;
			int pos2 = UNDEFINED;
			string fooo = "";

			fooo = lineIn.Substring(pos1 + keyWord.Length + 2);
			pos2 = fooo.IndexOf("\"");
			fooo = fooo.Substring(0, pos2).ToLower();
			if (fooo.CompareTo("true") == 0) stateOut = true;
			if (fooo.CompareTo("yes") == 0) stateOut = true;
			if (fooo.CompareTo("1") == 0) stateOut = true;
			return stateOut;
		}

		public static string SetKey(string fieldName, string value)
		{
			StringBuilder ret = new StringBuilder();

			ret.Append(fieldName);
			ret.Append(FIELDEQ);
			ret.Append(value);
			ret.Append(ENDQT);

			return ret.ToString();
		}

		public static string SetKey(string fieldName, int value)
		{
			StringBuilder ret = new StringBuilder();

			ret.Append(fieldName);
			ret.Append(FIELDEQ);
			ret.Append(value);
			ret.Append(ENDQT);

			return ret.ToString();
		}

		public static string StartTable(string tableName, int level)
		{
			StringBuilder ret = new StringBuilder();

			for (int l=0; l<level; l++)
			{
				ret.Append(LEVEL1);
			}
			ret.Append(STFLD);
			ret.Append(tableName);
			return ret.ToString();
		}

		public static string EndTable(string tableName, int level)
		{
			StringBuilder ret = new StringBuilder();

			for (int l = 0; l < level; l++)
			{
				ret.Append(LEVEL1);
			}
			ret.Append(utils.FINTBL);
			ret.Append(tableName);
			ret.Append(utils.ENDTBL);
			return ret.ToString();
		}


		public static int BuildDisplayOrder(Sequence4 seq, ref int[] savedIndexes, ref int[] levels, bool selectedOnly, bool includeRGBchildren)
		{
			//TODO: 'Selected' not implemented yet

			int count = 0;
			int c = 0;
			int level = 0;
			int tot = seq.Tracks.Count + seq.Channels.Count + seq.ChannelGroups.Count;
			if (includeRGBchildren)
			{
				tot += seq.RGBchannels.Count;
			}
			else
			{
				// Why * 2? 'cus we won't show the 3 Members, but will show the parent.  3-1=2.
				tot -= (seq.RGBchannels.Count * 2);
			}
			//Array.Resize(ref savedIndexes, tot);
			//Array.Resize(ref levels, tot);




			// TEMPORARY, FOR DEBUGGING
			// int tcount = 0;
			// int gcount = 0;
			// int rcount = 0;
			// int ccount = 0;

			//const string ERRproc = " in FillChannels(";
			// const string ERRtrk = "), in Track #";
			// const string ERRitem = ", Items #";
			// const string ERRline = ", Line #";

			for (int t = 0; t < seq.Tracks.Count; t++)
			{
				level = 0;
				Track theTrack = seq.Tracks[t];
				if (!selectedOnly || theTrack.Selected)
				{
					Array.Resize(ref savedIndexes, count + 1);
					Array.Resize(ref levels, count + 1);
					savedIndexes[count] = theTrack.SavedIndex;
					levels[count] = level;
					count++;
					c++;
				}
				//try
				//{
				for (int ti = 0; ti < theTrack.Members.Count; ti++)
				{
					//try
					//{
					IMember member = theTrack.Members.Items[ti];
					int si = member.SavedIndex;
					if (member != null)
					{
						if (member.MemberType == MemberType.ChannelGroup)
						{
							c += BuildGroup(seq, (ChannelGroup)member, level+1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
						}
						if (member.MemberType == MemberType.CosmicDevice)
						{
							c += BuildCosmic(seq, (CosmicDevice)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
						}
						if (member.MemberType == MemberType.RGBchannel)
						{
							c += BuildRGBchannel(seq, (RGBchannel)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
						}
						if (member.MemberType == MemberType.Channel)
						{
							c += BuildChannel(seq, (Channel)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly);
						}
					} // end not null
						//} // end try
					#region catch1
					/*	
					catch (System.NullReferenceException ex)
						{
							StackTrace st = new StackTrace(ex, true);
							StackFrame sf = st.GetFrame(st.FrameCount - 1);
							string emsg = ex.ToString();
							emsg += ERRproc + seq.filename + ERRtrk + t.ToString() + ERRitem + ti.ToString();
							emsg += ERRline + sf.GetFileLineNumber();
							#if DEBUG
								System.Diagnostics.Debugger.Break();
							#endif
							utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
						}
						catch (System.InvalidCastException ex)
						{
							StackTrace st = new StackTrace(ex, true);
							StackFrame sf = st.GetFrame(st.FrameCount - 1);
							string emsg = ex.ToString();
							emsg += ERRproc + seq.filename + ERRtrk + t.ToString() + ERRitem + ti.ToString();
							emsg += ERRline + sf.GetFileLineNumber();
							#if DEBUG
								System.Diagnostics.Debugger.Break();
							#endif
							utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
						}
						catch (Exception ex)
						{
							StackTrace st = new StackTrace(ex, true);
							StackFrame sf = st.GetFrame(st.FrameCount - 1);
							string emsg = ex.ToString();
							emsg += ERRproc + seq.filename + ERRtrk + t.ToString() + ERRitem + ti.ToString();
							emsg += ERRline + sf.GetFileLineNumber();
							#if DEBUG
								System.Diagnostics.Debugger.Break();
							#endif
							utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
						}
						*/
					#endregion

				} // end loop thru track items
				#region catch2 
				/*
					} // end try
					catch (System.NullReferenceException ex)
					{
						StackTrace st = new StackTrace(ex, true);
						StackFrame sf = st.GetFrame(st.FrameCount - 1);
						string emsg = ex.ToString();
						emsg += ERRproc + seq.filename + ERRtrk + t.ToString();
						emsg += ERRline + sf.GetFileLineNumber();
						#if DEBUG
							System.Diagnostics.Debugger.Break();
						#endif
						utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
					}
					catch (System.InvalidCastException ex)
					{
						StackTrace st = new StackTrace(ex, true);
						StackFrame sf = st.GetFrame(st.FrameCount - 1);
						string emsg = ex.ToString();
						emsg += ERRproc + seq.filename + ERRtrk + t.ToString();
						emsg += ERRline + sf.GetFileLineNumber();
						#if DEBUG
							System.Diagnostics.Debugger.Break();
						#endif
						utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
					}
					catch (Exception ex)
					{
						StackTrace st = new StackTrace(ex, true);
						StackFrame sf = st.GetFrame(st.FrameCount - 1);
						string emsg = ex.ToString();
						emsg += ERRproc + seq.filename + ERRtrk + t.ToString();
						emsg += ERRline + sf.GetFileLineNumber();
						#if DEBUG
							System.Diagnostics.Debugger.Break();
						#endif
						utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
					}
					*/
				#endregion

			} // end loop thru Tracks

			// Integrity Checks for debugging
			if (c != count)
			{
				string msg = "Houston, we have a problem!";
			}
			if (!selectedOnly)
			{
				if (c != tot)
				{
					string msg = "Houston, we have another problem!";
				}
			}



			return c;

		} // end fillOldChannels

		public static int BuildGroup(Sequence4 seq, ChannelGroup theGroup, int level, ref int count, ref int[] savedIndexes, ref int[]levels, bool selectedOnly, bool includeRGBchildren)
		{
			int c = 0;
			string nodeText = theGroup.Name;

			if (!selectedOnly || theGroup.Selected)
			{
				Array.Resize(ref savedIndexes, count + 1);
				Array.Resize(ref levels, count + 1);
				savedIndexes[count] = theGroup.SavedIndex;
				levels[count] = level;
				count++;
				c++;
			}

			for (int gi = 0; gi < theGroup.Members.Count; gi++)
			{
				//try
				//{
				IMember member = theGroup.Members.Items[gi];
				int si = member.SavedIndex;
				if (member.MemberType == MemberType.ChannelGroup)
				{
					c += BuildGroup(seq, (ChannelGroup)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
				}
				if (member.MemberType == MemberType.CosmicDevice)
				{
					c += BuildCosmic(seq, (CosmicDevice)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
				}
				if (member.MemberType == MemberType.Channel)
				{
					c += BuildChannel(seq, (Channel)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly);
				}
				if (member.MemberType == MemberType.RGBchannel)
				{
					c += BuildRGBchannel(seq, (RGBchannel)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
				}
				#region catch
				/*
	} // end try
		catch (Exception ex)
		{
			StackTrace st = new StackTrace(ex, true);
			StackFrame sf = st.GetFrame(st.FrameCount - 1);
			string emsg = ex.ToString();
			emsg += ERRproc + seq.filename + ERRgrp + groupIndex.ToString() + ERRitem + gi.ToString();
			emsg += ERRline + sf.GetFileLineNumber();
			#if DEBUG
				Debugger.Break();
			#endif
			utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
		} // end catch
		*/
				#endregion

			} // End loop thru items
			return c;
		} // end AddGroup

		public static int BuildCosmic(Sequence4 seq, CosmicDevice theDevice, int level, ref int count, ref int[] savedIndexes, ref int[] levels, bool selectedOnly, bool includeRGBchildren)
		{
			int c = 0;
			string nodeText = theDevice.Name;

			// const string ERRproc = " in FillChannels-AddGroup(";
			// const string ERRgrp = "), in Group #";
			// const string ERRitem = ", Items #";
			// const string ERRline = ", Line #";

			if (!selectedOnly || theDevice.Selected)
			{
				Array.Resize(ref savedIndexes, count + 1);
				Array.Resize(ref levels, count + 1);
				savedIndexes[count] = theDevice.SavedIndex;
				levels[count] = level;
				count++;
				c++;
			}

			for (int gi = 0; gi < theDevice.Members.Count; gi++)
			{
				//try
				//{
				IMember member = theDevice.Members.Items[gi];
				int si = member.SavedIndex;
				if (member.MemberType == MemberType.ChannelGroup)
				{
					c += BuildGroup(seq, (ChannelGroup)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
				}
				if (member.MemberType == MemberType.CosmicDevice)
				{
					c += BuildCosmic(seq, (CosmicDevice)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
				}
				if (member.MemberType == MemberType.Channel)
				{
					c += BuildChannel(seq, (Channel)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly);
				}
				if (member.MemberType == MemberType.RGBchannel)
				{
					c += BuildRGBchannel(seq, (RGBchannel)member, level + 1, ref count, ref savedIndexes, ref levels, selectedOnly, includeRGBchildren);
				}
				#region catch
				/*
	} // end try
		catch (Exception ex)
		{
			StackTrace st = new StackTrace(ex, true);
			StackFrame sf = st.GetFrame(st.FrameCount - 1);
			string emsg = ex.ToString();
			emsg += ERRproc + seq.filename + ERRgrp + groupIndex.ToString() + ERRitem + gi.ToString();
			emsg += ERRline + sf.GetFileLineNumber();
			#if DEBUG
				Debugger.Break();
			#endif
			utils.WriteLogEntry(emsg, utils.LOG_Error, Application.ProductName);
		} // end catch
		*/
				#endregion

			} // End loop thru items
			return c;
		} // end AddGroup

		public static int BuildChannel(Sequence4 seq, Channel theChannel, int level, ref int count, ref int[] savedIndexes, ref int[] levels, bool selectedOnly)
		{
			int c = 0;
			if (!selectedOnly || theChannel.Selected) 
			{
				Array.Resize(ref savedIndexes, count + 1);
				Array.Resize(ref levels, count + 1);
				savedIndexes[count] = theChannel.SavedIndex;
				levels[count] = level;
				count++;
				c++;
			}
			return c;
		}

		public static int BuildRGBchannel(Sequence4 seq, RGBchannel theRGB, int level, ref int count, ref int[] savedIndexes, ref int[] levels, bool selectedOnly, bool includeRGBchildren)
		{
			int c = 0;

			if (!selectedOnly || theRGB.Selected)
			{
				Array.Resize(ref savedIndexes, count + 1);
				Array.Resize(ref levels, count + 1);
				savedIndexes[count] = theRGB.SavedIndex;
				levels[count] = level;
				count++;
				c++;
				if (includeRGBchildren)
				{
					Array.Resize(ref savedIndexes, count + 3);
					Array.Resize(ref levels, count + 3);
					// * * R E D   S U B  C H A N N E L * *
					savedIndexes[count] = theRGB.redChannel.SavedIndex;
					levels[count] = level + 1;
					count++;

					// * * G R E E N   S U B  C H A N N E L * *
					savedIndexes[count] = theRGB.grnChannel.SavedIndex;
					levels[count] = level + 1;
					count++;

					// * * B L U E   S U B  C H A N N E L * *
					savedIndexes[count] = theRGB.bluChannel.SavedIndex;
					levels[count] = level + 1;
					count++;

					c += 3;
				} // end includeRGBchildren
			}

			return c;
		}

		public static void ClearOutputWindow()
		{
			if (!Debugger.IsAttached)
			{
				return;
			}

			/*
			//Application.DoEvents();  // This is for Windows.Forms.
			// This delay to get it to work. Unsure why. See http://stackoverflow.com/questions/2391473/can-the-visual-studio-debug-output-window-be-programatically-cleared
			Thread.Sleep(1000);
			// In VS2008 use EnvDTE80.DTE2
			EnvDTE.DTE ide = (EnvDTE.DTE)Marshal.GetActiveObject("VisualStudio.DTE.14.0");
			if (ide != null)
			{
				ide.ExecuteCommand("Edit.ClearOutputWindow", "");
				Marshal.ReleaseComObject(ide);
			}
			*/
		}

		public static string GetAppTempFolder()
		{

			string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
			string mySubDir = "\\UtilORama\\";
			string tempPath = appDataDir + mySubDir;
			if (!Directory.Exists(tempPath))
			{
				Directory.CreateDirectory(tempPath);
			}
			mySubDir += Application.ProductName + "\\";
			mySubDir = mySubDir.Replace("-", "");
			tempPath = appDataDir + mySubDir;
			if (!Directory.Exists(tempPath))
			{
				Directory.CreateDirectory(tempPath);
			}
			return tempPath;
		}

		public static Color Color_LORtoNet(Int32 LORcolorVal)
		{
			string colorID = Color_LORtoHTML(LORcolorVal);
			// Convert rearranged hex value a real color
			Color theColor = System.Drawing.ColorTranslator.FromHtml("#" + colorID);
			return theColor;
		}

		public static string Color_LORtoHTML(Int32 LORcolorVal)
		{
			string tempID = LORcolorVal.ToString("X6");
			// LOR's Color Format is in BGR format, so have to reverse the Red and the Blue
			string colorID = tempID.Substring(4, 2) + tempID.Substring(2, 2) + tempID.Substring(0, 2);
			return colorID;
		}

		public static Int32 Color_NettoLOR(Color netColor)
		{
			int argb = netColor.ToArgb();
			string tempID = argb.ToString("X6");
			// LOR's Color Format is in BGR format, so have to reverse the Red and the Blue
			string colorID = tempID.Substring(4, 2) + tempID.Substring(2, 2) + tempID.Substring(0, 2);
			Int32 c = Int32.Parse(colorID, System.Globalization.NumberStyles.HexNumber);
			return c;
		}

		public static Int32 Color_RGBtoLOR(int r, int g, int b)
		{
			int c = r;
			c += g * 0x100;
			c += b * 0x10000;
			return c;
		}
		public static Int32 Color_HTMLtoLOR(string HTMLcolor)
		{
			// LOR's Color Format is in BGR format, so have to reverse the Red and the Blue
			string colorID = HTMLcolor.Substring(4, 2) + HTMLcolor.Substring(2, 2) + HTMLcolor.Substring(0, 2);
			Int32 c = Int32.Parse(colorID, System.Globalization.NumberStyles.HexNumber);
			return c;
		}

		public static string FormatTime(int centiseconds)
		{
			string timeOut = "";

			int totsecs = (int)(centiseconds / 100);
			int centis = centiseconds % 100;
			int min = (int)(totsecs / 60);
			int secs = totsecs % 60;

			if (min>0)
			{
				timeOut = min.ToString() + ":";
				timeOut += secs.ToString("00");
			}
			else
			{
				timeOut = secs.ToString();
			}
			timeOut += "." + centis.ToString("00");

			return timeOut;
		}

		public static int DecodeTime(string theTime)
		{
			// format mm:ss.cs
			int csOut = UNDEFINED;
			int csTmp = UNDEFINED;

			// Split time by :
			string[] tmpM = theTime.Split(':');
			// Not more than 1 : ?
			if (tmpM.Length < 3)
			{
				// has a : ?
				if (tmpM.Length == 2)
				{
					// first part is minutes
					int min = 0;
					// try to parse minutes from first part of string
					int.TryParse(tmpM[0], out min);
					// each minute is 6000 centiseconds
					csTmp = min * 6000;
					// place second part of split into first part for next step of decoding
					tmpM[0] = tmpM[1];
				}
				// split seconds by . ?
				string[] tmpS = tmpM[0].Split('.');
				// not more than 1 . ?
				if (tmpS.Length < 3)
				{
					// has a . ?
					if (tmpS.Length == 2)
					{
						// next part is seconds
						int sec = 0;
						// try to parse seconds from first part of remaining string
						int.TryParse(tmpS[0], out sec);
						// each second is 100 centiseconds (duh!)
						csTmp += (sec * 100);
						// no more than 2 decimal places allowed
						if (tmpS[1].Length > 2)
						{
							tmpS[1] = tmpS[1].Substring(0, 2);
						}
						// place second part into first part for next step of decoding
						tmpS[0] = tmpS[1];
					}
					int cs = 0;
					int.TryParse(tmpS[0], out cs);
					csTmp += cs;
					csOut = csTmp;
				}
			}



			return csOut;
		}


		public struct RGB
		{
			private byte _r;
			private byte _g;
			private byte _b;

			public RGB(byte r, byte g, byte b)
			{
				this._r = r;
				this._g = g;
				this._b = b;
			}

			public byte R
			{
				get { return this._r; }
				set { this._r = value; }
			}

			public byte G
			{
				get { return this._g; }
				set { this._g = value; }
			}

			public byte B
			{
				get { return this._b; }
				set { this._b = value; }
			}

			public bool Equals(RGB rgb)
			{
				return (this.R == rgb.R) && (this.G == rgb.G) && (this.B == rgb.B);
			}
		}

		public struct HSV
		{
			private double _h;
			private double _s;
			private double _v;

			public HSV(double h, double s, double v)
			{
				this._h = h;
				this._s = s;
				this._v = v;
			}

			public double H
			{
				get { return this._h; }
				set { this._h = value; }
			}

			public double S
			{
				get { return this._s; }
				set { this._s = value; }
			}

			public double V
			{
				get { return this._v; }
				set { this._v = value; }
			}

			public bool Equals(HSV hsv)
			{
				return (this.H == hsv.H) && (this.S == hsv.S) && (this.V == hsv.V);
			}
		}

		public static Int32 HSVToRGB(HSV hsv)
		{
			double r = 0, g = 0, b = 0;

			if (hsv.S == 0)
			{
				r = hsv.V;
				g = hsv.V;
				b = hsv.V;
			}
			else
			{
				int i;
				double f, p, q, t;

				if (hsv.H == 360)
					hsv.H = 0;
				else
					hsv.H = hsv.H / 60;

				i = (int)Math.Truncate(hsv.H);
				f = hsv.H - i;

				p = hsv.V * (1.0 - hsv.S);
				q = hsv.V * (1.0 - (hsv.S * f));
				t = hsv.V * (1.0 - (hsv.S * (1.0 - f)));

				switch (i)
				{
					case 0:
						r = hsv.V;
						g = t;
						b = p;
						break;

					case 1:
						r = q;
						g = hsv.V;
						b = p;
						break;

					case 2:
						r = p;
						g = hsv.V;
						b = t;
						break;

					case 3:
						r = p;
						g = q;
						b = hsv.V;
						break;

					case 4:
						r = t;
						g = p;
						b = hsv.V;
						break;

					default:
						r = hsv.V;
						g = p;
						b = q;
						break;
				}

			}

			RGB x = new RGB((byte)(r * 255), (byte)(g * 255), (byte)(b * 255));
			Int32 ret = x.R * 0x10000 + x.G * 0x100 + x.B;
			return ret;
		}

		public static Bitmap RenderEffects(IMember member, int startCentiseconds, int endCentiseconds, int width, int height, bool useRamps)
		{
			// Create a temporary working bitmap
			Bitmap bmp = new Bitmap(width, height);
			if (member.MemberType == MemberType.Channel)
			{
				Channel channel = (Channel)member;
				bmp = RenderEffects(channel, startCentiseconds, endCentiseconds, width, height, useRamps);
			}
			if (member.MemberType == MemberType.RGBchannel)
			{
				RGBchannel rgb = (RGBchannel)member;
				bmp = RenderEffects(rgb, startCentiseconds, endCentiseconds, width, height, useRamps);
			}

			return bmp;

		}

		public static Bitmap RenderEffects(Channel channel, int startCentiseconds, int endCentiseconds, int width, int height, bool useRamps)
		{
			// Create a temporary working bitmap
			Bitmap bmp = new Bitmap(width, height);
			// get the graphics handle from it
			Graphics gr = Graphics.FromImage(bmp);
			// Paint the entire 'background' black
			gr.FillRectangle(Brushes.Silver, 0, 0, width - 1, height - 1);
			Color c = Color_LORtoNet(channel.color);
			Pen p = new Pen(c, 1);
			Brush br = new SolidBrush(c);
			Debug.WriteLine(""); Debug.WriteLine("");
			if (channel.effects.Count > 0)
			{
				int[] levels = PlotLevels(channel, startCentiseconds, endCentiseconds, width);
				for (int x=0; x < width; x++)
				{
					Debug.Write(levels[x].ToString() + " ");
					bool shimmer = ((levels[x] & utils.ADDshimmer) > 0);
					bool twinkle = ((levels[x] & utils.ADDtwinkle) > 0);
					levels[x] &= 0x0FF;
					if (useRamps)
					{
						//int lineLen = levels[x] * Convert.ToInt32((float)height / 100D);
						int ll = levels[x] * height;
						int lineLen = ll / 100 + 1;
						if (shimmer)
						{
							for (int n=0; n< lineLen; n++)
							{
								int m = (n + x) % 6;
								if (m <2)
								{
									gr.FillRectangle(br, x, height - n, 1, 1);
								}
							}
						}
						else if (twinkle)
						{
							for (int n = 0; n < lineLen; n++)
							{
								int m = (n + x) % 6;
								if (m < 1)
								{
									gr.FillRectangle(br, x, height - n, 1, 1);
								}
								m = (x - n + 25000) % 6;
								if (m < 1)
								{
									gr.FillRectangle(br, x, height - n, 1, 1);
								}

							}
						}
						else
						{
							gr.DrawLine(p, x, height - 1, x, height - lineLen);
						}
					}
					else // use fades instead of ramps
					{
						int R = (Color.Silver.R * (100 - levels[x]) / 100) + (c.R * levels[x] / 100);
						int G = (Color.Silver.G * (100 - levels[x]) / 100) + (c.G * levels[x] / 100);
						int B = (Color.Silver.B * (100 - levels[x]) / 100) + (c.B * levels[x] / 100);
						Color d = Color.FromArgb(R, G, B);
						p = new Pen(d, 1);
						br = new SolidBrush(d);
						if (shimmer)
						{
							for (int n = 0; n < height; n++)
							{
								int m = (n + x) % 6;
								if (m < 2)
								{
									gr.FillRectangle(br, x, height - n, 1, 1);
								}
							}
						}
						else if (twinkle)
						{
							for (int n = 0; n < height; n++)
							{
								int m = (n + x) % 6;
								if (m < 1)
								{
									gr.FillRectangle(br, x, height - n, 1, 1);
								}
								m = (x - n + 25000) % 6;
								if (m < 1)
								{
									gr.FillRectangle(br, x, height - n, 1, 1);
								}

							}
						}
						else
						{
							gr.DrawLine(p, x, 0, x, height - 1);
						}
					}
				}
			} // end channel has effects

			return bmp;
		}

		public static Bitmap RenderEffects(RGBchannel rgb, int startCentiseconds, int endCentiseconds, int width, int height, bool useRamps)
		{
			// Create a temporary working bitmap
			Bitmap bmp = new Bitmap(width, height);
			// get the graphics handle from it
			Graphics gr = Graphics.FromImage(bmp);
			// Paint the entire 'background' black
			//gr.FillRectangle(Brushes.Black, 0, 0, width - 1, height - 1);

			int[] rLevels = null;
			Array.Resize(ref rLevels, width);
			int[] gLevels = null;
			Array.Resize(ref gLevels, width);
			int[] bLevels = null;
			Array.Resize(ref bLevels, width);
			int thirdHt = height / 3;

			if (rgb.redChannel.effects.Count > 0)
			{
				rLevels = PlotLevels(rgb.redChannel, startCentiseconds, endCentiseconds, width);
			}
			if (rgb.grnChannel.effects.Count > 0)
			{
				gLevels = PlotLevels(rgb.grnChannel, startCentiseconds, endCentiseconds, width);
			}
			if (rgb.bluChannel.effects.Count > 0)
			{
				bLevels = PlotLevels(rgb.bluChannel, startCentiseconds, endCentiseconds, width);
			}

			for (int x = 0; x < width; x++)
			{
				//Debug.Write(levels[x].ToString() + " ");
				//bool shimmer = ((levels[x] & utils.ADDshimmer) > 0);
				//bool twinkle = ((levels[x] & utils.ADDtwinkle) > 0);
				//levels[x] &= 0x0FF;
				if (useRamps)
				{
					// * * R E D * *
					Pen p = new Pen(Color.Red, 1);
					Brush br = new SolidBrush(Color.Red);
					bool shimmer = ((rLevels[x] & utils.ADDshimmer) > 0);
					bool twinkle = ((rLevels[x] & utils.ADDtwinkle) > 0);
					rLevels[x] &= 0x0FF;
					int ll = rLevels[x] * thirdHt;
					int lineLen = ll / 100 + 1;
					if (shimmer)
					{
						for (int n = 0; n < lineLen; n++)
						{
							int m = (n + x) % 6;
							if (m < 2)
							{
								gr.FillRectangle(br, x, height - n, 1, 1);
							}
						}
					}
					else if (twinkle)
					{
						for (int n = 0; n < lineLen; n++)
						{
							int m = (n + x) % 6;
							if (m < 1)
							{
								gr.FillRectangle(br, x, height - n, 1, 1);
							}
							m = (x - n + 25000) % 6;
							if (m < 1)
							{
								gr.FillRectangle(br, x, height - n, 1, 1);
							}

						}
					}
					else
					{
						gr.DrawLine(p, x, height - 1, x, height - lineLen);
					}
					// END RED

					// * * G R E E N * *
					p = new Pen(Color.Green, 1);
					br = new SolidBrush(Color.Green);
					shimmer = ((rLevels[x] & utils.ADDshimmer) > 0);
					twinkle = ((rLevels[x] & utils.ADDtwinkle) > 0);
					rLevels[x] &= 0x0FF;
					ll = rLevels[x] * thirdHt;
					lineLen = ll / 100 + 1;
					if (shimmer)
					{
						for (int n = 0; n < lineLen; n++)
						{
							int m = (n + x) % 6;
							if (m < 2)
							{
								gr.FillRectangle(br, x, thirdHt + height - n, 1, 1);
							}
						}
					}
					else if (twinkle)
					{
						for (int n = 0; n < lineLen; n++)
						{
							int m = (n + x) % 6;
							if (m < 1)
							{
								gr.FillRectangle(br, x, thirdHt + height - n, 1, 1);
							}
							m = (x - n + 25000) % 6;
							if (m < 1)
							{
								gr.FillRectangle(br, x, thirdHt + height - n, 1, 1);
							}

						}
					}
					else
					{
						gr.DrawLine(p, x, height - 1, x, thirdHt + height - lineLen);
					}
					// END GREEN

					// * * B L U E * *
					p = new Pen(Color.Red, 1);
					br = new SolidBrush(Color.Red);
					shimmer = ((rLevels[x] & utils.ADDshimmer) > 0);
					twinkle = ((rLevels[x] & utils.ADDtwinkle) > 0);
					rLevels[x] &= 0x0FF;
					ll = rLevels[x] * thirdHt;
					lineLen = ll / 100 + 1;
					if (shimmer)
					{
						for (int n = 0; n < lineLen; n++)
						{
							int m = (n + x) % 6;
							if (m < 2)
							{
								gr.FillRectangle(br, x, thirdHt + thirdHt + height - n, 1, 1);
							}
						}
					}
					else if (twinkle)
					{
						for (int n = 0; n < lineLen; n++)
						{
							int m = (n + x) % 6;
							if (m < 1)
							{
								gr.FillRectangle(br, x, thirdHt + thirdHt + height - n, 1, 1);
							}
							m = (x - n + 25000) % 6;
							if (m < 1)
							{
								gr.FillRectangle(br, x, height - n, 1, 1);
							}

						}
					}
					else
					{
						gr.DrawLine(p, x, height - 1, x, thirdHt + thirdHt + height - lineLen);
					}
					// END BLUE

				}
				else // use fades instead of ramps
				{
					rLevels[x] = (int)((float)rLevels[x] * 2.55F);
					gLevels[x] = (int)((float)gLevels[x] * 2.55F);
					bLevels[x] = (int)((float)bLevels[x] * 2.55F);

					Color c = Color.FromArgb(rLevels[x], gLevels[x], bLevels[x]);
					Pen p = new Pen(c, 1);
					gr.DrawLine(p, x, 0, x, height - 1);
				}
			} // end For
			return bmp;
		}

		public static int[] PlotLevels(Channel channel, int startCentiseconds, int endCentiseconds, int width)
		{
			int[] levels = null;
			Array.Resize(ref levels, width);

			int totalCentiseconds = endCentiseconds - startCentiseconds + 1;
			// centisecondsPerPixel = totalCentiseconds / width;
			float cspp = (float)totalCentiseconds / (float)width;
			// int curCs = 0;
			// int lastCs = 0;
			int curLevel = 0;
			int effectIdx = 0;
			bool keepGoing = true;
			int thisClik = 0;
			int nextClik = width;
			Effect curEffect = channel.effects[effectIdx];


			if (cspp >= 1.0F)
			{
				for (int x = 0; x < width; x++)
				{
					keepGoing = true;
					while (keepGoing)
					{
						// at how many centiseconds does this column represent
						//     Convert.ToInt provides rounding
						//      Whereas casting with (int) does not  (per StackExchange)
						thisClik = Convert.ToInt32(cspp * (float)x);
						// if not to the end
						if (x < width - 2)
						{
							// how many centiseconds does the next column represent
							nextClik = Convert.ToInt32(cspp * ((float)(x + 1)));
						}
						else // at the end
						{
							nextClik = width;
						}
						// does the current effect start at or before this time slice?
						if (thisClik >= curEffect.startCentisecond)
						{
							// does it end at or after this time slice?
							if (thisClik <= curEffect.endCentisecond)
							{
								// We Got One!
								keepGoing = false;
								// This is the current effect at this time
								if (curEffect.EffectTypeEX == EffectType.Constant)
								{
									curLevel = curEffect.Intensity;
								}
								if (curEffect.EffectTypeEX == EffectType.Shimmer)
								{
									curLevel = curEffect.Intensity | ADDshimmer;
								}
								if (curEffect.EffectTypeEX == EffectType.Twinkle)
								{
									curLevel = curEffect.Intensity | ADDtwinkle;
								}
								if ((curEffect.EffectTypeEX == EffectType.FadeDown) ||
										(curEffect.EffectTypeEX == EffectType.FadeUp))
								{
									// Amount of difference in level, from start to end
									int levelDiff = curEffect.endIntensity - curEffect.startIntensity;
									// lenth of the effect
									int effLen = curEffect.endCentisecond - curEffect.startCentisecond;
									// how far we currently are from/past the start of the effect - in centiseconds
									int csFromStart = thisClik - curEffect.startCentisecond;
									// how far is that, as related to the length of the effect, expressed as 0 to 1
									float amtThru = (float)csFromStart / (float)effLen;
									// New relative level is the level difference times how relatively far we are thru it
									float newLev = 0F;
									// is it a fade-out/down?
									if (levelDiff < 0)
									{
										// Get inverse of amount thru
										//amtThru = 1F - amtThru;
										// make difference positive
										//levelDiff *= -1;
									}
									// New relative level is the level difference times how relatively far we are thru it
									newLev = (float)levelDiff * amtThru;
									// add the base starting level to get the current level at this slice in time
									curLevel = curEffect.startIntensity + Convert.ToInt32(newLev);
								}
							}
							else // we are past the end of this effect
							{
								// until we figure out otherwise - assume we are BETWEEN effects
								curLevel = 0;
								// are there more effects?
								if (effectIdx < (channel.effects.Count - 1))
								{										// move to next effect
									effectIdx++;
									curEffect = channel.effects[effectIdx];
									// does it end before this time slice
									while (curEffect.endCentisecond < cspp)
									{
										if (effectIdx < (channel.effects.Count - 1))
										{
											// move to next effect
											effectIdx++;
											curEffect = channel.effects[effectIdx];
										}
										else
										{
											curEffect = new Effect();
											curEffect.startCentisecond = endCentiseconds + 1;
											curEffect.endCentisecond = endCentiseconds + 2;
										} // if more effects remain
									} // end while(currentEffect End < this time slice)
								} // end there are more effects left
								else
								{
									keepGoing = false;
								}
							} // end curent effect ends at or before this time slice
						} 
						else
						{
							keepGoing = false;
						} // end current effect starts at or before this time slice
					} // end while(keepGoing) loop looking at effects
					levels[x] = curLevel;
				} // end for loop (columns/pixels, horizontal x left to right)
			} // end muliple centiseconds per pixel
			else
			{
				// mulitple pixels per centisecond
				//TODO
			} // end pixels to centiseconds ratio
			return levels;
		}

		public static int FastIndexOf(string source, string pattern)
		{
			if (pattern == null) throw new ArgumentNullException();
			if (pattern.Length == 0) return 0;
			if (pattern.Length == 1) return source.IndexOf(pattern[0]);
			bool found;
			int limit = source.Length - pattern.Length + 1;
			if (limit < 1) return -1;
			// Store the first 2 characters of "pattern"
			char c0 = pattern[0];
			char c1 = pattern[1];
			// Find the first occurrence of the first character
			int first = source.IndexOf(c0, 0, limit);
			while (first != -1)
			{
				// Check if the following character is the same like
				// the 2nd character of "pattern"
				if (source[first + 1] != c1)
				{
					first = source.IndexOf(c0, ++first, limit - first);
					continue;
				}
				// Check the rest of "pattern" (starting with the 3rd character)
				found = true;
				for (int j = 2; j < pattern.Length; j++)
					if (source[first + j] != pattern[j])
					{
						found = false;
						break;
					}
				// If the whole word was found, return its index, otherwise try again
				if (found) return first;
				first = source.IndexOf(c0, ++first, limit - first);
			}
			return -1;
		}

		public static string ReplaceInvalidFilenameCharacters(string oldName)
		{
			//! This is for the main part of the filename only!
			//! It replaces things like \ and : so it can't be used for full paths + names
			string newName = oldName.Replace('<', '＜');
			newName = newName.Replace('>', '＞');
			newName = newName.Replace(':', '﹕');
			newName = newName.Replace('\"', '＂');
			newName = newName.Replace('/', '∕');
			newName = newName.Replace('\\', '＼');
			newName = newName.Replace('?', '？');
			newName = newName.Replace('|', '￤');
			newName = newName.Replace('$', '§');
			newName = newName.Replace('*', '＊');
			return newName;
		}

		public static string Time_CentisecondsToMinutes(int centiseconds)
		{
			int mm = (int)(centiseconds / 6000);
			int ss = (int)((centiseconds - mm * 6000)/100);
			int cs = (int)(centiseconds - mm * 6000 - ss * 100);
			string ret = mm.ToString("0") + ":" + ss.ToString("00") + "." + cs.ToString("00");
			return ret;
		}

		public static int Time_MinutesToCentiseconds(string timeInMinutes)
		{
			// Time string must be formated as mm:ss.cs
			// Where mm is minutes.  Must be specified, even if zero.
			// Where ss is seconds 0-59.
			// Where cs is centiseconds 0-99.  Must be specified, even if zero.
			// Time string must contain one colon (:) and one period (.)
			// Maximum of 60 minutes  (Anything longer can result in unmanageable sequences)
			string newTime = timeInMinutes.Trim();
			int ret = UNDEFINED;
			int posColon = newTime.IndexOf(':');
			if ((posColon > 0) && (posColon < 3))
			{
				int posc2 = newTime.IndexOf(':', posColon + 1);
				if (posc2 < 0)
				{
					string min = newTime.Substring(0, posColon);
					string rest = newTime.Substring(posColon + 1);
					int posPer = rest.IndexOf('.');
					if ((posPer == 2))
					{
						int posp2 = rest.IndexOf('.', posPer + 1);
						if (posp2 < 0)
						{
							string sec = rest.Substring(0, posPer);
							string cs = rest.Substring(posPer + 1);
							int mn = utils.UNDEFINED;
							int.TryParse(min, out mn);
							if ((mn >=0) && (mn<61))
							{
								int sc = utils.UNDEFINED;
								int.TryParse(sec, out sc);
								if ((sc >=0 ) && (sc<60))
								{
									int c = utils.UNDEFINED;
									int.TryParse(cs, out c);
									if ((c >=0) && (c<100))
									{
										ret = mn * 6000 + sc * 100 + c;
									}
								}
							}
						}
					}
				}
			}

			return ret;
		}

	} // end class utils
} // end namespace LORUtils
