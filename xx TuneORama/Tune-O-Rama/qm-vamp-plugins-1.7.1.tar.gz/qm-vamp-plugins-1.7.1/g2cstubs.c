
void s_wsfe() { }
void do_fio() { }
void e_wsfe() { }
void s_stop() { }
