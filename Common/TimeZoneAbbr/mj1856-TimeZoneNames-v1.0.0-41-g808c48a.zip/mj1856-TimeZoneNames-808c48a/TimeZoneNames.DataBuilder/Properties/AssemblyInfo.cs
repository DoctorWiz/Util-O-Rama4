﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TimeZoneNames.DataBuilder")]
[assembly: AssemblyDescription("Data builder for time zone names.")]

[assembly: ComVisible(false)]