﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PixelDust
{
    class ColorChange
    {
        public string fromName = "White";
        public int fromR = 100;
        public int fromG = 100;
        public int fromB = 100;
        public string toName = "Black";
        public int toR = 0;
        public int toG = 0;
        public int toB = 0;
    }
}
