﻿namespace FuzzyString
{
	public enum FuzzyStringComparisonTolerance
	{
		Strong,

		Normal,

		Weak,

		Manual
	}
}