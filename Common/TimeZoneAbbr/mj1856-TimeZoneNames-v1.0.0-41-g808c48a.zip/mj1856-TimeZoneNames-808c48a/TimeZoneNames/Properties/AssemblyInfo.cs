﻿using System.Reflection;

[assembly: AssemblyTitle("TimeZoneNames")]
[assembly: AssemblyDescription("Provides localized time zone names.")]
