﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PixelFun
{
    public partial class frmPresets : Form
    {
        public frmPresets()
        {
            InitializeComponent();
        }
    }
}
