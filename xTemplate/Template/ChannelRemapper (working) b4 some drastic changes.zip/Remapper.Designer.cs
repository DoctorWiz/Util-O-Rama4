﻿namespace ChannelRemapper
{
	partial class frmRemapper
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRemapper));
			this.pnlAll = new System.Windows.Forms.Panel();
			this.lblStatus = new System.Windows.Forms.Label();
			this.staStatus = new System.Windows.Forms.StatusStrip();
			this.pnlStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.btnSummary = new System.Windows.Forms.Button();
			this.treNewChannels = new System.Windows.Forms.TreeView();
			this.imlTreeIcons = new System.Windows.Forms.ImageList(this.components);
			this.treOldChannels = new System.Windows.Forms.TreeView();
			this.btnSaveMap = new System.Windows.Forms.Button();
			this.txtMappingFile = new System.Windows.Forms.TextBox();
			this.btnLoadMap = new System.Windows.Forms.Button();
			this.btnUnmap = new System.Windows.Forms.Button();
			this.btnMap = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.label4 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.btnBrowseMaster = new System.Windows.Forms.Button();
			this.txtMasterFile = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnBrowseOld = new System.Windows.Forms.Button();
			this.txtOldFile = new System.Windows.Forms.TextBox();
			this.dlgSaveFile = new System.Windows.Forms.SaveFileDialog();
			this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
			this.pnlAll.SuspendLayout();
			this.staStatus.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlAll
			// 
			this.pnlAll.Controls.Add(this.lblStatus);
			this.pnlAll.Controls.Add(this.staStatus);
			this.pnlAll.Controls.Add(this.btnSummary);
			this.pnlAll.Controls.Add(this.treNewChannels);
			this.pnlAll.Controls.Add(this.treOldChannels);
			this.pnlAll.Controls.Add(this.btnSaveMap);
			this.pnlAll.Controls.Add(this.txtMappingFile);
			this.pnlAll.Controls.Add(this.btnLoadMap);
			this.pnlAll.Controls.Add(this.btnUnmap);
			this.pnlAll.Controls.Add(this.btnMap);
			this.pnlAll.Controls.Add(this.btnOK);
			this.pnlAll.Controls.Add(this.label4);
			this.pnlAll.Controls.Add(this.label6);
			this.pnlAll.Controls.Add(this.label2);
			this.pnlAll.Controls.Add(this.btnBrowseMaster);
			this.pnlAll.Controls.Add(this.txtMasterFile);
			this.pnlAll.Controls.Add(this.label1);
			this.pnlAll.Controls.Add(this.btnBrowseOld);
			this.pnlAll.Controls.Add(this.txtOldFile);
			this.pnlAll.Location = new System.Drawing.Point(0, 0);
			this.pnlAll.Name = "pnlAll";
			this.pnlAll.Size = new System.Drawing.Size(1162, 738);
			this.pnlAll.TabIndex = 19;
			// 
			// lblStatus
			// 
			this.lblStatus.AutoSize = true;
			this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStatus.ForeColor = System.Drawing.SystemColors.HotTrack;
			this.lblStatus.Location = new System.Drawing.Point(314, 538);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(83, 13);
			this.lblStatus.TabIndex = 41;
			this.lblStatus.Text = "Status Message";
			this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblStatus.Visible = false;
			// 
			// staStatus
			// 
			this.staStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pnlStatusLabel1});
			this.staStatus.Location = new System.Drawing.Point(0, 716);
			this.staStatus.Name = "staStatus";
			this.staStatus.Size = new System.Drawing.Size(1162, 22);
			this.staStatus.TabIndex = 40;
			this.staStatus.Text = "statusStrip1";
			// 
			// pnlStatusLabel1
			// 
			this.pnlStatusLabel1.Name = "pnlStatusLabel1";
			this.pnlStatusLabel1.Size = new System.Drawing.Size(118, 17);
			this.pnlStatusLabel1.Text = "toolStripStatusLabel1";
			// 
			// btnSummary
			// 
			this.btnSummary.Enabled = false;
			this.btnSummary.Location = new System.Drawing.Point(321, 406);
			this.btnSummary.Name = "btnSummary";
			this.btnSummary.Size = new System.Drawing.Size(76, 29);
			this.btnSummary.TabIndex = 39;
			this.btnSummary.Text = "Summary";
			this.btnSummary.UseVisualStyleBackColor = true;
			this.btnSummary.Click += new System.EventHandler(this.btnSummary_Click);
			// 
			// treNewChannels
			// 
			this.treNewChannels.ImageIndex = 0;
			this.treNewChannels.ImageList = this.imlTreeIcons;
			this.treNewChannels.Location = new System.Drawing.Point(403, 99);
			this.treNewChannels.Name = "treNewChannels";
			this.treNewChannels.SelectedImageIndex = 0;
			this.treNewChannels.Size = new System.Drawing.Size(300, 433);
			this.treNewChannels.TabIndex = 38;
			this.treNewChannels.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treNewChannels_AfterSelect);
			// 
			// imlTreeIcons
			// 
			this.imlTreeIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlTreeIcons.ImageStream")));
			this.imlTreeIcons.TransparentColor = System.Drawing.Color.Transparent;
			this.imlTreeIcons.Images.SetKeyName(0, "Track.ico");
			this.imlTreeIcons.Images.SetKeyName(1, "Group.ico");
			this.imlTreeIcons.Images.SetKeyName(2, "RGBch.ico");
			this.imlTreeIcons.Images.SetKeyName(3, "Channel.ico");
			this.imlTreeIcons.Images.SetKeyName(4, "RedCh.ico");
			this.imlTreeIcons.Images.SetKeyName(5, "GrnCh.ico");
			this.imlTreeIcons.Images.SetKeyName(6, "BluCh.ico");
			// 
			// treOldChannels
			// 
			this.treOldChannels.ImageIndex = 0;
			this.treOldChannels.ImageList = this.imlTreeIcons;
			this.treOldChannels.Location = new System.Drawing.Point(15, 99);
			this.treOldChannels.Name = "treOldChannels";
			this.treOldChannels.SelectedImageIndex = 0;
			this.treOldChannels.Size = new System.Drawing.Size(300, 433);
			this.treOldChannels.TabIndex = 37;
			this.treOldChannels.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treOldChannels_AfterSelect);
			// 
			// btnSaveMap
			// 
			this.btnSaveMap.Enabled = false;
			this.btnSaveMap.Location = new System.Drawing.Point(506, 562);
			this.btnSaveMap.Name = "btnSaveMap";
			this.btnSaveMap.Size = new System.Drawing.Size(100, 25);
			this.btnSaveMap.TabIndex = 34;
			this.btnSaveMap.Text = "Save Mapping...";
			this.btnSaveMap.UseVisualStyleBackColor = true;
			// 
			// txtMappingFile
			// 
			this.txtMappingFile.Enabled = false;
			this.txtMappingFile.Location = new System.Drawing.Point(200, 565);
			this.txtMappingFile.Name = "txtMappingFile";
			this.txtMappingFile.Size = new System.Drawing.Size(300, 20);
			this.txtMappingFile.TabIndex = 36;
			// 
			// btnLoadMap
			// 
			this.btnLoadMap.Location = new System.Drawing.Point(94, 562);
			this.btnLoadMap.Name = "btnLoadMap";
			this.btnLoadMap.Size = new System.Drawing.Size(100, 25);
			this.btnLoadMap.TabIndex = 35;
			this.btnLoadMap.Text = "Load Mapping...";
			this.btnLoadMap.UseVisualStyleBackColor = true;
			// 
			// btnUnmap
			// 
			this.btnUnmap.Enabled = false;
			this.btnUnmap.Location = new System.Drawing.Point(321, 190);
			this.btnUnmap.Name = "btnUnmap";
			this.btnUnmap.Size = new System.Drawing.Size(76, 29);
			this.btnUnmap.TabIndex = 33;
			this.btnUnmap.Text = "Unmap";
			this.btnUnmap.UseVisualStyleBackColor = true;
			this.btnUnmap.Click += new System.EventHandler(this.btnUnmap_Click);
			// 
			// btnMap
			// 
			this.btnMap.Enabled = false;
			this.btnMap.Location = new System.Drawing.Point(321, 142);
			this.btnMap.Name = "btnMap";
			this.btnMap.Size = new System.Drawing.Size(76, 29);
			this.btnMap.TabIndex = 32;
			this.btnMap.Text = "Map";
			this.btnMap.UseVisualStyleBackColor = true;
			this.btnMap.Click += new System.EventHandler(this.btnMap_Click);
			// 
			// btnOK
			// 
			this.btnOK.Enabled = false;
			this.btnOK.Location = new System.Drawing.Point(297, 607);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(129, 62);
			this.btnOK.TabIndex = 31;
			this.btnOK.Text = "Remap";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(403, 72);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(97, 13);
			this.label4.TabIndex = 30;
			this.label4.Text = "Available Channels";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(15, 72);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(128, 13);
			this.label6.TabIndex = 28;
			this.label6.Text = "Channel to be Remapped";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(403, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(125, 13);
			this.label2.TabIndex = 25;
			this.label2.Text = "New Master Channel File";
			// 
			// btnBrowseMaster
			// 
			this.btnBrowseMaster.Location = new System.Drawing.Point(709, 40);
			this.btnBrowseMaster.Name = "btnBrowseMaster";
			this.btnBrowseMaster.Size = new System.Drawing.Size(36, 20);
			this.btnBrowseMaster.TabIndex = 24;
			this.btnBrowseMaster.Text = "...";
			this.btnBrowseMaster.UseVisualStyleBackColor = true;
			this.btnBrowseMaster.Click += new System.EventHandler(this.btnBrowseMaster_Click);
			// 
			// txtMasterFile
			// 
			this.txtMasterFile.Enabled = false;
			this.txtMasterFile.Location = new System.Drawing.Point(403, 40);
			this.txtMasterFile.Name = "txtMasterFile";
			this.txtMasterFile.Size = new System.Drawing.Size(300, 20);
			this.txtMasterFile.TabIndex = 23;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(15, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(124, 13);
			this.label1.TabIndex = 21;
			this.label1.Text = "Old File to be Remapped";
			// 
			// btnBrowseOld
			// 
			this.btnBrowseOld.Location = new System.Drawing.Point(321, 40);
			this.btnBrowseOld.Name = "btnBrowseOld";
			this.btnBrowseOld.Size = new System.Drawing.Size(36, 20);
			this.btnBrowseOld.TabIndex = 20;
			this.btnBrowseOld.Text = "...";
			this.btnBrowseOld.UseVisualStyleBackColor = true;
			this.btnBrowseOld.Click += new System.EventHandler(this.btnBrowseOld_Click);
			// 
			// txtOldFile
			// 
			this.txtOldFile.Enabled = false;
			this.txtOldFile.Location = new System.Drawing.Point(15, 40);
			this.txtOldFile.Name = "txtOldFile";
			this.txtOldFile.Size = new System.Drawing.Size(300, 20);
			this.txtOldFile.TabIndex = 19;
			// 
			// dlgOpenFile
			// 
			this.dlgOpenFile.FileName = "openFileDialog1";
			// 
			// frmRemapper
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(754, 689);
			this.Controls.Add(this.pnlAll);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "frmRemapper";
			this.Text = "Channel Remapper";
			this.Load += new System.EventHandler(this.frmRemapper_Load);
			this.Shown += new System.EventHandler(this.frmRemapper_Shown);
			this.pnlAll.ResumeLayout(false);
			this.pnlAll.PerformLayout();
			this.staStatus.ResumeLayout(false);
			this.staStatus.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel pnlAll;
		private System.Windows.Forms.Button btnSaveMap;
		private System.Windows.Forms.TextBox txtMappingFile;
		private System.Windows.Forms.Button btnLoadMap;
		private System.Windows.Forms.Button btnUnmap;
		private System.Windows.Forms.Button btnMap;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnBrowseMaster;
		private System.Windows.Forms.TextBox txtMasterFile;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnBrowseOld;
		private System.Windows.Forms.TextBox txtOldFile;
		private System.Windows.Forms.SaveFileDialog dlgSaveFile;
		private System.Windows.Forms.OpenFileDialog dlgOpenFile;
		private System.Windows.Forms.TreeView treOldChannels;
		private System.Windows.Forms.ImageList imlTreeIcons;
		private System.Windows.Forms.TreeView treNewChannels;
		private System.Windows.Forms.Button btnSummary;
		private System.Windows.Forms.StatusStrip staStatus;
		private System.Windows.Forms.ToolStripStatusLabel pnlStatusLabel1;
		private System.Windows.Forms.Label lblStatus;
	}
}

