﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using LORUtils;

namespace ChannelRemapper
{

	public class MapInfo
	{
		public int fromSavedIndex = -1;
		public int toSavedIndex = -1;
	}

	public partial class frmRemapper : Form
	{
		int[] chMapTo;
		int[][] chsMapTo;
		int[] chsUnused;
		Sequence oldSeq = new Sequence();
		Sequence newSeq = new Sequence();
		string oldFile;
		string newFile;
		string basePath;
		string masterFile;
		TreeNode activeOldChannel;
		TreeNode activeNewChannel;
		int activeList = 0;
		private const int LIST_OLD = 1;
		private const int LIST_NEW = 2;
		public string statMsg = "Hello World!";
		//private Assembly assy = this.GetType().Assembly;
		//ResourceManager resources = new ResourceManager("Resources.Strings", assy);

		private const char DELIM_Map = (char)164;  // ¤
		private const char DELIM_SID = (char)177;  // ±
		private const char DELIM_Name = (char)167;  // §
		private const char DELIM4 = (char)182;  // ¶

		private const string MSG_MapRegularToRegular = "Regular channels can only be mapped to other regular channels.";
		private const string MSG_MapRGBtoRGB	 = "RGB channels can only be mapped to other RGB channels.";
		private const string MSG_GroupToGroup	 = "Groups can only be mapped to other groups, and only if they have the same number of regular channels and RGB channels in the same order.";
		private const string MSG_GroupMatch = "Groups can only be mapped to other groups if they have the same number of regular channels, RGB channels, and subgroups in the same order.";
		private const string MSG_Tracks = "Tracks can not be mapped.";
		private const string MSG_OnlyOneOldToNew = "The selected new channel already has an old channel mapped to it.";
		private const string MSG_OnlyOneGroupToNew = "The selected new group already has an old group mapped to it.";

		// Used only at load time to restore previous size/position
		private int miLoadHeight = 400;
		private int miLoadWidth = 620;
		private int miLoadLeft = 0;
		private int miLoadTop = 0;


		private class ChanInfo
		{
			public tableType chType = tableType.None;
			public int chIndex = 0;
			public int savedIndex = -1;
			public int mapCount = 0;
			public int[] mapChIndexes;
			public int[] mapSavedIndexes;
			public int nodeIndex = -1;
		}
		
		int nodeIndex = -1;
		public MapInfo[] mappings;
		private int mappingCount = 0;

		public frmRemapper()
		{
			InitializeComponent();
		}

		private void btnBrowseOld_Click(object sender, EventArgs e)
		{


			dlgOpenFile.Filter = "Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lms";
			dlgOpenFile.InitialDirectory = basePath;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			DialogResult result = dlgOpenFile.ShowDialog();

			pnlAll.Enabled = false;
			if (result == DialogResult.OK)
			{
				oldFile = dlgOpenFile.FileName;
				//if (oldFile.Substring(1, 2) != ":\\")
				//{
				//	oldFile = basePath + "\\" + oldFile;
				//}

				FileInfo fi = new FileInfo(oldFile);
				Properties.Settings.Default.BasePath = fi.DirectoryName;
				Properties.Settings.Default.Save();

				//if (oldFile.Length > basePath.Length)
				//{
				//	if (oldFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
				//	{
				//		txtOldFile.Text = oldFile.Substring(basePath.Length);
				//		oldSeq.readFile(oldFile);
				//		FillOldChannels();
				//	}
				//	else
				//	{
						//txtOldFile.Text = oldFile;
						txtOldFile.Text = ShortenLongPath(oldFile, 80);
						oldSeq.readFile(oldFile);
						FillChannels(treOldChannels, oldSeq);
				//	} // End else (oldFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
				//} // end if (oldFile.Length > basePath.Length)
			} // end if (result = DialogResult.OK)
			pnlAll.Enabled = true;
			if (treNewChannels.Nodes.Count > 0)
			{
				btnSummary.Enabled = true;
			}

		}

		private void frmRemapper_Load(object sender, EventArgs e)
		{
		}

		
		private void SaveFormPosition()
		{
			// Called with form is closed
			if (WindowState == FormWindowState.Normal)
			{
				Properties.Settings.Default.Location = Location;
				Properties.Settings.Default.Size = Size;
				Properties.Settings.Default.Minimized = false;
			}
			else
			{
				Properties.Settings.Default.Location = RestoreBounds.Location;
				Properties.Settings.Default.Size = RestoreBounds.Size;
				Properties.Settings.Default.Minimized = true;
			}
			Properties.Settings.Default.Save();

		} // End SaveFormPosition

		private void RestoreFormPosition()
		{
			// Called when form is loaded
			//TODO: This only gets the area of the first screen in a multi-screen setup

			int itop = Properties.Settings.Default.Location.X;
			int ileft = Properties.Settings.Default.Location.Y;

			// Should get all screens and figure out if size/placement of the form is valid
			//TODO: Restore form.WindowState and if maximized use RestoreBounds()
			this.SetDesktopLocation(ileft, itop);

		} // End RestoreFormPosition

		private void FillChannels(TreeView tree, Sequence seq)
		{
			treOldChannels.Nodes.Clear();
			//ChanInfo tagInfo = new ChanInfo();
			string nodeText = "";
			ChanInfo nodeTag = new ChanInfo();
			nodeIndex = 1;
			
			for (int t = 0; t < seq.trackCount; t++)
			{
				int tNo = t + 1;
				nodeText = "Track " + tNo.ToString() + ":" + seq.tracks[t].name;
				TreeNode trackNode = tree.Nodes.Add(nodeText);
				nodeTag.chType = tableType.track;
				nodeTag.chIndex = t;
				nodeTag.nodeIndex = nodeIndex;
				nodeIndex++;
				trackNode.Tag = nodeTag;

				trackNode.ImageIndex = 0;
				trackNode.SelectedImageIndex = 0;

				for (int ti = 0; ti < seq.trackItemCount; ti++)
				{
					if (seq.trackItems[ti].trackIndex == t)
					{
						int si = seq.trackItems[ti].savedIndex;
						if (seq.savedIndexes[si].objType == tableType.channelGroup)
						{
							TreeNode groupNode = AddGroup(seq, trackNode, seq.savedIndexes[si].objIndex);
						}
						if (seq.savedIndexes[si].objType == tableType.channel)
						{
							TreeNode groupNode = AddChannel(seq, trackNode, seq.savedIndexes[si].objIndex);
						}
						if (seq.savedIndexes[si].objType == tableType.rgbChannel)
						{
							TreeNode groupNode = AddRGBchannel(seq, trackNode, seq.savedIndexes[si].objIndex);
						}
					}

				}


			}

		} // end fillOldChannels

		private TreeNode AddGroup(Sequence seq, TreeNode parentNode, int groupIndex)
		{
			string nodeText = seq.channelGroups[groupIndex].name;
			TreeNode groupNode = parentNode.Nodes.Add(nodeText);
			ChanInfo nodeTag = new ChanInfo();
			nodeTag.chType = tableType.channelGroup;
			nodeTag.chIndex = groupIndex;
			nodeTag.savedIndex = seq.channelGroups[groupIndex].savedIndex;
			nodeTag.nodeIndex = nodeIndex;
			nodeIndex++;
			groupNode.Tag = nodeTag;
			groupNode.ImageIndex = 1;
			groupNode.SelectedImageIndex = 1;

			for (int gi = 0; gi < seq.groupItemCount; gi++)
			{
				if (seq.channelGroupItems[gi].channelGroupObjIndex == groupIndex)
				{
					int si = seq.channelGroupItems[gi].channelGroupItemSavedIndex;
					if (seq.savedIndexes[si].objType == tableType.channelGroup)
					{
						TreeNode subGroupNode = AddGroup(seq, groupNode, seq.savedIndexes[si].objIndex);
					}
					if (seq.savedIndexes[si].objType == tableType.channel)
					{
						TreeNode channelNode = AddChannel(seq, groupNode, seq.savedIndexes[si].objIndex);
					}
					if (seq.savedIndexes[si].objType == tableType.rgbChannel)
					{
						TreeNode RGBchannelNode = AddRGBchannel(seq, groupNode, seq.savedIndexes[si].objIndex);
					}
				}

			}


			return groupNode;
		}

		private TreeNode AddChannel(Sequence seq, TreeNode parentNode, int channelIndex)
		{
			string nodeText = seq.channels[channelIndex].name;
			TreeNode channelNode = parentNode.Nodes.Add(nodeText);
			ChanInfo nodeTag = new ChanInfo();
			nodeTag.chType = tableType.channel;
			nodeTag.chIndex = channelIndex;
			nodeTag.savedIndex = seq.channels[channelIndex].savedIndex;
			nodeTag.nodeIndex = nodeIndex;
			nodeIndex++;
			channelNode.Tag = nodeTag;
			channelNode.ImageIndex = 3;
			channelNode.SelectedImageIndex = 3;

			return channelNode;
		}

		private TreeNode AddRGBchannel(Sequence seq, TreeNode parentNode, int RGBIndex)
		{
			string nodeText = seq.rgbChannels[RGBIndex].name;
			TreeNode channelNode = parentNode.Nodes.Add(nodeText);
			ChanInfo nodeTag = new ChanInfo();
			nodeTag.chType = tableType.rgbChannel;
			nodeTag.chIndex = RGBIndex;
			nodeTag.savedIndex = seq.rgbChannels[RGBIndex].savedIndex;
			nodeTag.nodeIndex = nodeIndex;
			nodeIndex++;
			channelNode.Tag = nodeTag;
			channelNode.ImageIndex = 2;
			channelNode.SelectedImageIndex = 2;


			int ci = seq.rgbChannels[RGBIndex].redChannelIndex;
			nodeText = seq.channels[ci].name;
			TreeNode colorNode = channelNode.Nodes.Add(nodeText);
			nodeTag = new ChanInfo();
			nodeTag.chType = tableType.channel;
			nodeTag.chIndex = ci;
			nodeTag.savedIndex = seq.channels[ci].savedIndex;
			nodeTag.nodeIndex = nodeIndex;
			nodeIndex++;
			colorNode.Tag = nodeTag;
			colorNode.ImageIndex = 4;
			colorNode.SelectedImageIndex = 4;

			ci = seq.rgbChannels[RGBIndex].grnChannelIndex;
			nodeText = seq.channels[ci].name;
			colorNode = channelNode.Nodes.Add(nodeText);
			nodeTag = new ChanInfo();
			nodeTag.chType = tableType.channel;
			nodeTag.chIndex = ci;
			nodeTag.savedIndex = seq.channels[ci].savedIndex;
			nodeTag.nodeIndex = nodeIndex;
			nodeIndex++;
			colorNode.Tag = nodeTag;
			colorNode.ImageIndex = 5;
			colorNode.SelectedImageIndex = 5;

			ci = seq.rgbChannels[RGBIndex].bluChannelIndex;
			nodeText = seq.channels[ci].name;
			colorNode = channelNode.Nodes.Add(nodeText);
			nodeTag = new ChanInfo();
			nodeTag.chType = tableType.channel;
			nodeTag.chIndex = ci;
			nodeTag.savedIndex = seq.channels[ci].savedIndex;
			nodeTag.nodeIndex = nodeIndex;
			nodeIndex++;
			colorNode.Tag = nodeTag;
			colorNode.ImageIndex = 6;
			colorNode.SelectedImageIndex = 6;


			return channelNode;
		}


		private string ShortenLongPath(string longPath, int maxLen)
		{
			string shortPath = longPath;
			// Can't realistically shorten a path and filename to much less than 18 characters, reliably
			if (maxLen > 18)
			{
				// Do even need to shorten it all?
				if (longPath.Length > maxLen)
				{
					// Split it into pieces, get count
					string[] splits = longPath.Split('\\');
					int parts = splits.Length;
					int h = maxLen / 2;
					// loop thru, look for excessively long single pieces
					for (int i = 0; i < parts; i++)
					{
						if (splits[i].Length > h)
						{
							// Is it the filename itself that's too long?
							if (i == (parts - 1))
							{
								// if filename is too long, shorten it, but not as aggressively as a folder
								if (splits[i].Length > (maxLen * .7))
								{
									// shorten filename to "xxxxx…xxxx" (10 characters)
									// which should include .ext assuming a 3 char extension
									splits[i] = splits[i].Substring(0, 5) + "…" + splits[i].Substring(splits[i].Length - 4, 4);
								}
							}
							else
							{
								// shorten folder to "xxx…xxx" (7 characters)
								splits[i] = splits[i].Substring(0, 3) + "…" + splits[i].Substring(splits[i].Length - 3, 3);
							}
						}
					}

					// at minimum, we want the filename, lets start with that
					shortPath = splits[parts - 1];
					// figure out what drive it is on
					string drive = "";
					byte b = 0;
					if (splits[0].Length == 2)
					{
						// Regular drive letter like C:
						drive = splits[0] + "\\";
						b = 1;
					}
					if (splits[0].Length + splits[1].Length == 0)
					{
						// UNC path like //server/share
						drive = "\\\\" + splits[0] + "\\" + splits[1] + "\\";
						b = 2;
					}
					// if drive + filename is still short enough, change to that
					if ((shortPath.Length + drive.Length + 2) <= maxLen)
					{
						shortPath = drive + "…\\" + shortPath;
					}
					// if drive + last folder + filename is still short enough, change to that
					if ((shortPath.Length + splits[parts - 2].Length + 1) <= maxLen)
					{
						shortPath = drive + "…\\" + splits[parts - 2] + "\\" + splits[parts - 1];
					}
					// if drive + first folder + last folder + filename is still short enough, change to that
					if ((shortPath.Length + splits[1].Length + 1) <= maxLen)
					{
						shortPath = drive + splits[1] + "\\…\\" + splits[parts - 2] + "\\" + splits[parts - 1];
					}
				} // end if (longPath.Length > maxLen)
			} // end if (maxLen > 18)
				// whatever we ended up with, return it
			return shortPath;
		} // end ShortenLongPath(string longPath, int maxLen)

		public string JustName(string fileName)
		{
			// Returns just the name portion of a filename
			// without the path, without any /'s
			// and without the extension and it's associated .
			string nameOnly = "";
			int i = fileName.IndexOf("\\");
			if (i < 0)
			{
				nameOnly = fileName;
			}
			else
			{
				string[] parts = fileName.Split('\\');
				nameOnly = parts[parts.Length - 1];
			}
			i = nameOnly.LastIndexOf(".");
			if (i > 0)
			{
				nameOnly = nameOnly.Substring(0, i - 1);
			}


			return nameOnly;
		} // end JustName function

		private void label5_Click(object sender, EventArgs e)
		{

		}

		private void btnBrowseMaster_Click(object sender, EventArgs e)
		{

			dlgOpenFile.Filter = "Channel Configs (*.lcc)|*.lcc|Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lee";
			dlgOpenFile.InitialDirectory = basePath;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			DialogResult result = dlgOpenFile.ShowDialog();

			pnlAll.Enabled = false;
			if (result == DialogResult.OK)
			{
				masterFile = dlgOpenFile.FileName;

				FileInfo fi = new FileInfo(masterFile);
				Properties.Settings.Default.MasterFile = masterFile;
				Properties.Settings.Default.Save();

				txtMasterFile.Text = ShortenLongPath(masterFile, 80);
				newSeq.readFile(masterFile);
				FillChannels(treNewChannels, newSeq);
			} // end if (result = DialogResult.OK)
			pnlAll.Enabled = true;
			if (treOldChannels.Nodes.Count > 0)
			{
				btnSummary.Enabled = true;
			}

		}

		private void InitForm()
		{
			basePath = Properties.Settings.Default.BasePath;
			masterFile = Properties.Settings.Default.MasterFile;
			if (File.Exists(masterFile))
			{
				txtMasterFile.Text = ShortenLongPath(masterFile, 80);
				newSeq.readFile(masterFile);
				FillChannels(treNewChannels, newSeq);
			}
			else
			{
				masterFile = "";
			}

			RestoreFormPosition();

		} // end InitForm

		private void treOldChannels_AfterSelect(object sender, TreeViewEventArgs e)
		{
			bool enM = false;    // Default enabled state for the map button will be false
			TreeNode oldCh = e.Node;
			activeOldChannel = e.Node;
			activeList = LIST_OLD;
			ChanInfo oldTag = (ChanInfo)oldCh.Tag;
			int oldSI = oldTag.savedIndex;

			// Unhighlight any previous selections
			UnHighlightAllNodes(treOldChannels.Nodes);
			// and highlight this one (and any others in this tree with a matching savedIndex)
			HighlightNodes(treOldChannels.Nodes, oldTag.savedIndex);

			int[] newChs = FindMapingsFrom(oldSI);


			if (newChs[0] >= 0)
			{
				// this old Channel has been mapped
				UnHighlightAllNodes(treNewChannels.Nodes);
				for (int m = 0; m <= newChs.Length; m++)
				{
					//TreeNode hiNode = FindNode(treNewChannels.Nodes, mappings[m]);
					//HighlightNode(hiNode, true);
					HighlightNodes(treNewChannels.Nodes, newChs[m]);
				}
				btnUnmap.Enabled = true;
			}
			else
			{
				// This old Channel has NOT been mapped
				btnUnmap.Enabled = false;

				if (activeNewChannel != null)
				{
					TreeNode newCh = activeNewChannel;
					ChanInfo newTag = (ChanInfo)newCh.Tag;
					// Is the new one unmapped?
					//if (newTag.IndexOf(DELIM_Map) >= 0)
					//{
					//	StatusMessage(MSG_OnlyOneOldToNew);
					//}
					//else
					//{

						enM = IsMappable(oldTag.chType, newTag.chType);

					//} // end new channel is already mapped (or not)
				} // end new channel selected
			} // end old channel is mapped (or not)
			btnMap.Enabled = enM;
		} // end treOldChannels_AfterSelect

		bool IsMappable(tableType oldType, tableType  newType)
		{
			bool enM = false;
			// Are they both regular channels?
			if (oldType == tableType.channel)
			{
				if (newType == tableType.channel)
				{
					enM = true;
				}
				else
				{
					StatusMessage(MSG_MapRegularToRegular);
				}
			} // end old type is regular ch
				// Are they both RGB channels?
			if (oldType == tableType.rgbChannel)
			{
				if (newType == tableType.rgbChannel)
				{
					enM = true;
				}
				else
				{
					StatusMessage(MSG_MapRGBtoRGB);
				}
			} // end old type is RGB
				// Are they both groups?
			if (oldType == tableType.channelGroup)
			{
				if (newType == tableType.channelGroup)
				{
					// are they similar enough?
					TreeNode oldCh = treOldChannels.SelectedNode;
					ChanInfo oldChan = (ChanInfo)oldCh.Tag;
					int oldSI = oldChan.savedIndex;
					TreeNode newCh = treNewChannels.SelectedNode;
					ChanInfo newChan = (ChanInfo)newCh.Tag;
					int newSI = newChan.savedIndex;
					enM = CompareGroups(oldSI, newSI);
					if (!enM)
					{
						StatusMessage(MSG_GroupMatch);
					}
				}
				else
				{
					StatusMessage(MSG_GroupToGroup);
				}
			} // end old type is group
			if (newType == tableType.track)
			{
				StatusMessage(MSG_Tracks);
			}
			if (oldType == tableType.track)
			{
				StatusMessage(MSG_Tracks);
			}
			return enM;
		} // end IsMappable


		bool CompareGroups(int oldSI, int newSI)
		// not necessarily groups, called recursively
		{
			bool ret = true;

			if (oldSeq.savedIndexes[oldSI].objType != newSeq.savedIndexes[newSI].objType)
			{
				ret = false;
			} else
			{
				if (oldSeq.savedIndexes[oldSI].objType == tableType.track)
				{
					ret = false;
				} else {
					if (oldSeq.savedIndexes[oldSI].objType == tableType.channelGroup)
					{
						int[] oldChildren = oldSeq.getChannelGroupItems(oldSI);
						int[] newChildren = newSeq.getChannelGroupItems(newSI);
						if ((oldChildren[0] < 0) || (newChildren[0] < 0))
						{
							ret = false;
						}
						else
						{
							if (oldChildren.Length != newChildren.Length)
							{
								ret = false;
							}
							else
							{
								for (int itm = 0; itm < oldChildren.Length; itm++)
								{
									if (ret)
									{
										ret = CompareGroups(oldChildren[itm], newChildren[itm]);
									}
								}
							}
						}
					}
				}
			}
			return ret;
		}

		private TreeNode FindNode(TreeNodeCollection treeNodes, string tag)
		{
			int tl = tag.Length;
			string st = "";
			TreeNode ret = new TreeNode("NOT FOUND");
			bool found = false;
			foreach (TreeNode nOde in treeNodes)
			{
				if (!found)
				{
					if (nOde.Tag.ToString().Length >= tag.Length)
					{
						st = nOde.Tag.ToString().Substring(0, tl);
						if (tag.CompareTo(st) == 0)
						{
							ret = nOde;
							found = true;
							break;
						}
					}
					if (!found)
					{
						if (nOde.Nodes.Count > 0)
						{
							ret = FindNode(nOde.Nodes, tag);
							if (ret.Text.CompareTo("NOT FOUND") != 0)
							{
								found = true;
							}
						}
					}
				}
			}
			return ret;
		}

		/*
		private int HighlightNode(TreeView tree, string tag)
		{
			int tl = tag.Length;
			int found = 0;
			foreach (TreeNode nOde in tree.Nodes)
			{
				// Reset any previous selections
				//HighlightNode(nOde, false);

				// If node is mapped, it's tag will include the node it is mapped to, and thus the tag length
				// will be longer than just it's own tag info
				int iPos = nOde.Tag.ToString().IndexOf(DELIM_Map);
				if (iPos > 0)
				{
					string mappedTag = nOde.Tag.ToString().Substring(iPos + 1);
					if (mappedTag.CompareTo(oldTag) == 0)
					{
						// The old channel is mapped to this one
						nOde.EnsureVisible();
						HighlightNode(nOde, true);
						if (found == 0)
						{
							treNewChannels.SelectedNode = nOde;
						}
						found++;

					}
				} // end long tag
			} // end foreach
			return found;
		} // end HighlightNewNodes
		*/

		private int HighlightOldNode(string tag)
		{
			int tl = tag.Length;
			int found = 0;
			foreach (TreeNode nOde in treOldChannels.Nodes)
			{
				// Reset any previous selections
				HighlightNode(nOde, false);

				// If node is mapped, it's tag will include the node it is mapped to, and thus the tag length
				// will be longer than just it's own tag info
				if (nOde.Tag.ToString().Length > tl)
				{
					string myTag = nOde.Tag.ToString().Substring(0, tl);
					if (tag.CompareTo(myTag) == 0)
					{
						// The old channel is mapped to this one
						nOde.EnsureVisible();
						HighlightNode(nOde, true);
						treOldChannels.SelectedNode = nOde;
						found++;

					}
				} // end long tag
			} // end foreach
			return found;
		} // end HighlightNewNodes

		private void UnHighlightAllNodes(TreeNodeCollection treeNodes)
		{
			foreach (TreeNode nOde in treeNodes)
			{
				// Reset any previous selections
				HighlightNode(nOde, false);
				if (nOde.Nodes.Count > 0)
				{
					UnHighlightAllNodes(nOde.Nodes);
				}
			} // end foreach
		}

		private void treNewChannels_AfterSelect(object sender, TreeViewEventArgs e)
		{
			bool enM = false;    // Default enabled state for the map button will be false
			TreeNode newCh = e.Node;
			activeNewChannel = e.Node;
			activeList = LIST_NEW;
			ChanInfo newTag = (ChanInfo)newCh.Tag;

			// Unhighlight any previous selections
			UnHighlightAllNodes(treNewChannels.Nodes);
			// and highlight this one (and any others in this tree with a matching savedIndex)
			HighlightNodes(treNewChannels.Nodes, newTag.savedIndex);

			int oldSI = FindMappingTo(newTag.savedIndex);
			if (oldSI >= 0)
			{
				// this new Channel has been mapped
				UnHighlightAllNodes(treOldChannels.Nodes);
				//string mapping = newTag.Substring(iPos);
				//TreeNode nOde = FindNode(treOldChannels.Nodes, mapping);
				//HighlightNode(nOde, true);
				HighlightNodes(treOldChannels.Nodes,oldSI);
				btnUnmap.Enabled = true;
			}
			else
			{
				// This new Channel has NOT been mapped
				btnUnmap.Enabled = false;
				TreeNode oldCh = activeOldChannel;
				if (oldCh != null)
				{
					ChanInfo oldTag = (ChanInfo)oldCh.Tag;

					enM = IsMappable(oldTag.chType, newTag.chType);
				} // end old channel selected
			} // end old channel is mapped (or not)
			btnMap.Enabled = enM;
		} // end treNewChannel_Click

		private void btnMap_Click(object sender, EventArgs e)
		{
			// The button should not have even been enabled if the 2 channels are not eligible to be mapped ... but--
			// Verify it anyway!

			// Is a node selected on each side?
			if (activeOldChannel != null)
			{
				TreeNode oldCh = activeOldChannel;
				ChanInfo oldTag = (ChanInfo)oldCh.Tag;
				int oldSI = oldTag.savedIndex;
				if (activeNewChannel != null)
				{
					TreeNode newCh = activeNewChannel;
					ChanInfo newTag = (ChanInfo)newCh.Tag;
					int newSI = newTag.savedIndex;
					// Types match?
					if (oldSeq.savedIndexes[oldSI].objType == tableType.channel)
					{
						if (newSeq.savedIndexes[newSI].objType == tableType.channel)
						{
							MapChannels(oldSI, newSI, true);
						}
						else
						{
							statMsg = Resources.MSG_MapRegularToRegular;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (oldSeq.savedIndexes[oldSI].objType == tableType.rgbChannel)
					{
						if (newSeq.savedIndexes[newSI].objType == tableType.rgbChannel)
						{
							MapChannels(oldSI, newSI, true);
						}
						else
						{
							statMsg = Resources.MSG_MapRGBtoRGB;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (oldSeq.savedIndexes[oldSI].objType == tableType.channelGroup)
					{
						if (newSeq.savedIndexes[newSI].objType == tableType.channelGroup)
						{
							MapChannels(oldSI, newSI, true);
						}
						else
						{
							statMsg = Resources.MSG_GroupToGroup;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (oldSeq.savedIndexes[oldSI].objType == tableType.track)
					{
						statMsg = Resources.MSG_Tracks;
						StatusMessage(statMsg);
						System.Media.SystemSounds.Beep.Play();
					}
					if (newSeq.savedIndexes[newSI].objType == tableType.track)
					{
						statMsg = Resources.MSG_Tracks;
						StatusMessage(statMsg);
						System.Media.SystemSounds.Beep.Play();
					}
				}
				else
				{
					System.Media.SystemSounds.Beep.Play();
				}
			}
			else
			{
				System.Media.SystemSounds.Beep.Play();
			}
		} // end btnMap_Click

		private void HighlightNode(TreeNode nOde, bool highlight)
		{
			if (highlight)
			{
				nOde.BackColor = SystemColors.Highlight;
				nOde.ForeColor = SystemColors.HighlightText;
			}
			else
			{
				nOde.BackColor = SystemColors.Window;
				nOde.ForeColor = SystemColors.WindowText;
			}
		}

		private void HighlightNodes(TreeNodeCollection nOdes, int savedIndex, bool highlight)
		{
			string nTag = "";
			ChanInfo nCI;
			foreach (TreeNode nOde in nOdes)
			{
				nCI = (ChanInfo)nOde.Tag;
				if (nCI.savedIndex == savedIndex)
				{
					if (highlight)
					{
						nOde.BackColor = SystemColors.Highlight;
						nOde.ForeColor = SystemColors.HighlightText;
					}
					else
					{
						nOde.BackColor = SystemColors.Window;
						nOde.ForeColor = SystemColors.WindowText;
					}
				}
				if (nOde.Nodes.Count > 0)
				{
					// Recurse if child nodes
					HighlightNodes(nOde.Nodes, savedIndex, highlight);
				}
			}
		}

		private void UnhighlightAllNodes(TreeNodeCollection nOdes)
		{
			foreach (TreeNode nOde in nOdes)
			{
				nOde.BackColor = SystemColors.Window;
				nOde.ForeColor = SystemColors.WindowText;
				if (nOde.Nodes.Count > 0)
				{
					// Recurse if child nodes
					UnhighlightAllNodes(nOde.Nodes);
				}
			}
		}

		private void BoldNodes(TreeNodeCollection nOdes, int savedIndex, bool emBolden)
		{
			string nTag = "";
			ChanInfo nCI;
			foreach (TreeNode nOde in nOdes)
			{
				nCI = (ChanInfo)nOde.Tag;
				if (nCI.savedIndex == savedIndex)
				{
					if (emBolden)
					{
						nOde.NodeFont = new Font(treOldChannels.Font, FontStyle.Bold);
					}
					else
					{
						nOde.NodeFont = new Font(treOldChannels.Font, FontStyle.Regular);
					}
					nOde.Checked = emBolden;
				}
				if (nOde.Nodes.Count > 0)
				{
					// Recurse if child nodes
					BoldNodes(nOde.Nodes, savedIndex, emBolden);
				}
			}
		}

		private void MapNodes(TreeNode oldCh, TreeNode newCh, bool map)
		{
			// Is a node selected on each side?
			if (oldCh != null)
			{
				ChanInfo oldTag = (ChanInfo)oldCh.Tag;
				if (newCh != null)
				{
					ChanInfo newTag = (ChanInfo)newCh.Tag;
					MapChannels(oldTag.savedIndex, newTag.savedIndex, map);
				} // end newChannel Node isn't null
			} // end oldChannel Node isn't null
		} // end btnMap_Click

		private void MapChannels(int oldSI, int newSI, bool map)
		{
			// Are we mapping or unmapping?
			if (map)
			{
				// Is the new channel already mapped?
				int PrevSI = FindMappingTo(newSI);
				if (PrevSI >= 0)
				{
					MapChannels(PrevSI, newSI, false);
				} // end was mapped, remove old map

				// Types match?
				if (oldSeq.savedIndexes[oldSI].objType == tableType.channel)
				{
					if (newSeq.savedIndexes[newSI].objType == tableType.channel)
					{
						AddMapping(oldSI, newSI);
						BoldNodes(treOldChannels.Nodes, oldSI, true);
						BoldNodes(treNewChannels.Nodes, newSI, true);

						btnMap.Enabled = false;
						btnUnmap.Enabled = true;
					}
					else // new type doesn't match
					{
						statMsg = Resources.MSG_MapRegularToRegular;
						LogMessage(statMsg);
						statMsg = oldSeq.getItemName(oldSI) + DELIM_Name + oldSI.ToString() + " to " + newSeq.getItemName(newSI) + DELIM_Name + newSI.ToString();
						LogMessage(statMsg);
					} // end newCh is regular channel
				} // end oldCh is regular channel
				if (oldSeq.savedIndexes[oldSI].objType == tableType.rgbChannel)
				{
					if (newSeq.savedIndexes[newSI].objType == tableType.rgbChannel)
					{
						AddMapping(oldSI, newSI);
						BoldNodes(treOldChannels.Nodes, oldSI, true);
						BoldNodes(treNewChannels.Nodes, newSI, true);

						// now do it for the child nodes, regular channels (R) (G) and (B)
						int os = oldSeq.rgbChannels[oldSeq.savedIndexes[oldSI].objIndex].redSavedIndex;
						int ns = newSeq.rgbChannels[newSeq.savedIndexes[newSI].objIndex].redSavedIndex;
						AddMapping(os, ns);
						BoldNodes(treOldChannels.Nodes, os, true);
						BoldNodes(treNewChannels.Nodes, ns, true);

						os = oldSeq.rgbChannels[oldSeq.savedIndexes[oldSI].objIndex].grnSavedIndex;
						ns = newSeq.rgbChannels[newSeq.savedIndexes[newSI].objIndex].grnSavedIndex;
						AddMapping(os, ns);
						BoldNodes(treOldChannels.Nodes, os, true);
						BoldNodes(treNewChannels.Nodes, ns, true);

						os = oldSeq.rgbChannels[oldSeq.savedIndexes[oldSI].objIndex].bluSavedIndex;
						ns = newSeq.rgbChannels[newSeq.savedIndexes[newSI].objIndex].bluSavedIndex;
						AddMapping(os, ns);
						BoldNodes(treOldChannels.Nodes, os, true);
						BoldNodes(treNewChannels.Nodes, ns, true);

						btnMap.Enabled = false;
						btnUnmap.Enabled = true;
					}
					else // new type is NOT RGB
					{
						LogMessage(MSG_MapRGBtoRGB);
						//LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
					} // end newCh is NOT RGB
				} // end oldCh is RGB
				if (oldSeq.savedIndexes[oldSI].objType == tableType.channelGroup)
				{
					if (newSeq.savedIndexes[newSI].objType == tableType.channelGroup)
					{
						bool compatible = CompareGroups(oldSI, newSI);
						if (compatible)
						{
							AddMapping(oldSI, newSI);
							BoldNodes(treOldChannels.Nodes, oldSI, true);
							BoldNodes(treNewChannels.Nodes, newSI, true);
							// now do it for the child nodes
							int[] oldChildItemsSI = oldSeq.getChannelGroupItems(oldSI);
							int[] newChildItemsSI = newSeq.getChannelGroupItems( newSI);
							// Just an error check, shouldn't ever get here if it fails CompareGroups() test
							//TODO: remove later after I'm sure this is working OK
							if (newChildItemsSI.Length == oldChildItemsSI.Length)
							{
								for (int itm = 0; itm < oldChildItemsSI.Length; itm++)
								{
									int itmSI = newChildItemsSI[itm];
									// Just an error check, shouldn't ever get here if it fails CompareGroups() test
									//TODO: remove later after I'm sure this is working OK
									if (newSeq.savedIndexes[newChildItemsSI[itm]].objType == oldSeq.savedIndexes[oldChildItemsSI[itm]].objType)
									{
										MapChannels(oldChildItemsSI[itm], newChildItemsSI[itm], true);
									}
								}
							}

							btnMap.Enabled = false;
							btnUnmap.Enabled = true;
						}
						else // groups are NOT compatible
						{
							statMsg = Resources.MSG_GroupMatch;
							LogMessage(statMsg);
							statMsg = oldSeq.getItemName(oldSI) + DELIM_Name + oldSI.ToString() + " to " + newSeq.getItemName(newSI) + DELIM_Name + newSI.ToString();
							LogMessage(statMsg);
						} // end groups compatible
					}
					else // newType is NOT a group
					{
						statMsg = Resources.MSG_GroupToGroup;
						LogMessage(statMsg);
						statMsg = oldSeq.getItemName(oldSI) + DELIM_Name + oldSI.ToString() + " to " + newSeq.getItemName(newSI) + DELIM_Name + newSI.ToString();
						LogMessage(statMsg);
					} // end newType is a group
				} // end oldtype is group
				if (oldSeq.savedIndexes[oldSI].objType == tableType.track)
				{
					statMsg = Resources.MSG_Tracks;
					LogMessage(statMsg);
					statMsg = oldSeq.getItemName(oldSI) + DELIM_Name + oldSI.ToString() + " to " + newSeq.getItemName(newSI) + DELIM_Name + newSI.ToString();
					LogMessage(statMsg);
				}
				if (newSeq.savedIndexes[newSI].objType == tableType.track)
				{
					statMsg = Resources.MSG_Tracks;
					LogMessage(statMsg);
					statMsg = oldSeq.getItemName(oldSI) + DELIM_Name + oldSI.ToString() + " to " + newSeq.getItemName(newSI) + DELIM_Name + newSI.ToString();
					LogMessage(statMsg);
				}
			} // end Map channels (map = true)
			else // Lets UNMap these channels
			{
				// Are they indeed mapped to each other already?
				if (FindMappingTo(newSI) == oldSI)
				{
					// remove mapping from new node (easy)
					RemoveMapping(newSI);
					BoldNodes(treNewChannels.Nodes, newSI, false);
					// is the old channel still mapped to any other channels?
					int[] remaining = FindMapingsFrom(oldSI);
					if (remaining[0] < 0)
					{
						// no, not mapped to any other channels, remove bolding
						BoldNodes(treOldChannels.Nodes, oldSI, false);
					}

					btnMap.Enabled = true;
					btnUnmap.Enabled = false;

					//TODO: Left off here...
					
					// Is it an RGB channel with children?
					if (oldSeq.savedIndexes[oldSI].objType == tableType.rgbChannel)
					{
						// now do it for the child nodes, regular channels (R) (G) and (B)
						int os = oldSeq.rgbChannels[oldSeq.savedIndexes[oldSI].objIndex].redSavedIndex;
						int ns = newSeq.rgbChannels[newSeq.savedIndexes[newSI].objIndex].redSavedIndex;
						RemoveMapping(ns);
						BoldNodes(treNewChannels.Nodes, ns, false);
						// is the old channel still mapped to any other channels?
						int[] leftover = FindMapingsFrom(oldSI);
						if (leftover[0] < 0)
						{
							// no, not mapped to any other channels, remove bolding
							BoldNodes(treOldChannels.Nodes, os, false);
						}

						os = oldSeq.rgbChannels[oldSeq.savedIndexes[oldSI].objIndex].grnSavedIndex;
						ns = newSeq.rgbChannels[newSeq.savedIndexes[newSI].objIndex].grnSavedIndex;
						RemoveMapping(ns);
						BoldNodes(treOldChannels.Nodes, ns, false);
						// is the old channel still mapped to any other channels?
						leftover = FindMapingsFrom(oldSI);
						if (leftover[0] < 0)
						{
							// no, not mapped to any other channels, remove bolding
							BoldNodes(treOldChannels.Nodes, os, false);
						}

						os = oldSeq.rgbChannels[oldSeq.savedIndexes[oldSI].objIndex].bluSavedIndex;
						ns = newSeq.rgbChannels[newSeq.savedIndexes[newSI].objIndex].bluSavedIndex;
						RemoveMapping(ns);
						BoldNodes(treOldChannels.Nodes, ns, false);
						// is the old channel still mapped to any other channels?
						leftover = FindMapingsFrom(oldSI);
						if (leftover[0] < 0)
						{
							// no, not mapped to any other channels, remove bolding
							BoldNodes(treOldChannels.Nodes, os, false);
						}
					}
					// Is it an channel Group with children?
					if (oldSeq.savedIndexes[oldSI].objType == tableType.channelGroup)
					{
						int[] newGrpItems = newSeq.getChannelGroupItems(newSI);
						if (newGrpItems[0] >= 0)
						{
							for (int itm = 0; itm < newGrpItems.Length; itm++)
							{
								MapChannels(FindMappingTo ( newGrpItems[itm]),newGrpItems[itm], false);
							}
						}
						
					}
					else // new channel was mapped to old, but old wasn't mapped to new?
					{
						statMsg = Resources.MSG_OneWay;
						LogMessage(statMsg);
						statMsg = oldSeq.getItemName(oldSI) + DELIM_Name + oldSI.ToString() + " to " + newSeq.getItemName(newSI) + DELIM_Name + newSI.ToString();
						LogMessage(statMsg);
					} // end and old channel was mapped to the new channel
				}
				else
				{
					statMsg = Resources.MSG_NoMap;
					LogMessage(statMsg);
					statMsg = oldSeq.getItemName(oldSI) + DELIM_Name + oldSI.ToString() + " to " + newSeq.getItemName(newSI) + DELIM_Name + newSI.ToString();
					LogMessage(statMsg);
				} // end new channel was mapped to the old channel
			} // end map or unmap

		}

		private int addElement(ref int[] numbers)
		{
			int newIdx = -1;

			if (numbers == null)
			{
				Array.Resize(ref numbers, 1);
				newIdx = 0;
			}
			else
			{
				int l = numbers.Length;
				Array.Resize(ref numbers, l + 1);
				newIdx = l;
			}

			return newIdx;
		}

		private int removeElement(ref int[] numbers, int index)
		{
			int l = numbers.Length;
			if (index < l)
			{
				l--;
				if (index < (l))
				{
					for (int i = index; i < l; i++)
					{
						numbers[i] = numbers[i + 1];
					}
				}
			}
			if (l == 0)
			{
				numbers = null;
			}
			else
			{
				Array.Resize(ref numbers, l);
			}

			return l;
		}

		private int FindElement(ref int[] numbers, int SID)
		{
			int found = -1;
			for (int i = 0; i < numbers.Length; i++)
			{
				if (numbers[i] == SID)
				{
					found = i;
					break;
				}
			}
			return found;
		}

		private TreeNode[] FindNodes(TreeNodeCollection nOdes, int SID)
		{
			TreeNode[] foundNodes = { new TreeNode() };
			int count = 0;
			ChanInfo ci;
			foreach (TreeNode nOde in nOdes)
			{
				ci = (ChanInfo)nOde.Tag;
				if (ci.savedIndex == SID)
				{
					count++;
					Array.Resize(ref foundNodes, count);
					foundNodes[count - 1] = nOde;
				}
				if (nOde.Nodes.Count > 0)
				{
					TreeNode[] moreNodes = FindNodes(nOde.Nodes, SID);
					if (moreNodes != null)
					{
						for (int m = 0; m < moreNodes.Length; m++)
						{
							count++;
							Array.Resize(ref foundNodes, count);
							foundNodes[count - 1] = moreNodes[m];
						}
					}
				}
			}
			return foundNodes;
		} // end FindNodes

		private void HighlightNodes(TreeNodeCollection nOdes, int SID)
		{
			ChanInfo ci;
			foreach (TreeNode nOde in nOdes)
			{
				ci = (ChanInfo)nOde.Tag;
				if (ci.savedIndex == SID)
				{
					HighlightNode(nOde, true);
				}
				if (nOde.Nodes.Count > 0)
				{
					HighlightNodes(nOde.Nodes, SID);
				}
			}
		}

		private void btnUnmap_Click(object sender, EventArgs e)
		{

		}


		private void StatusMessage(string message)
		{
			// For now at least... I think I'm gonna use this just to show WHY the 'Map' button is not enabled
			

			lblStatus.Text = message;
			lblStatus.Visible = (message.Length > 0);
			lblStatus.Left = (this.Width - lblStatus.ClientSize.Width) / 2;

		}

		private void LogMessage(string message)
		{
			//TODO: This
		}

		private void frmRemapper_Shown(object sender, EventArgs e)
		{
			InitForm();
		}

		private void btnSummary_Click(object sender, EventArgs e)
		{
			frmMapList dlgList = new frmMapList();
			dlgList.oldSeq = oldSeq;
			dlgList.newSeq = newSeq;
			dlgList.mappings = mappings;
			dlgList.BuildList();

			DialogResult result = dlgList.ShowDialog();
		}

		private void frmRemapper_FormClosing(object sender, FormClosingEventArgs e)
		{
			SaveFormPosition();
		}

		private int AddMapping(int fromSavedIndex, int toSavedIndex)
		{
			mappingCount ++;
			Array.Resize(ref mappings, mappingCount);
			mappings[mappingCount - 1] = new MapInfo(); 
			mappings[mappingCount - 1].fromSavedIndex = fromSavedIndex;
			mappings[mappingCount - 1].toSavedIndex = toSavedIndex;
			return mappingCount;
		}

		private bool RemoveMapping(int TOSavedIndex)
			//Note: Remove based on the TO/New index, because a FROM/Old can map to more than one TO/New
		{
			bool found = false;
			for (int i = 0; i < mappingCount; i++)
			{
				if (mappings[i].toSavedIndex == TOSavedIndex)
				{
					found = true;
					for (int j = i + 1; j < mappingCount; j++) 
					{
						mappings[i] = mappings[j];
					}
					i = mappingCount;
				}
			}
			if (found)
			{
				mappingCount--;
				Array.Resize(ref mappings, mappingCount);
			}
			return found;
		}

		private int FindMappingTo(int toSavedIndex)
		// ToSavedIndex from New Channels
		{
			int fromSavedIndex = -1;
			for (int i = 0; i < mappingCount; i++)
			{
				if (mappings[i].toSavedIndex == toSavedIndex)
				{
					fromSavedIndex = mappings[i].fromSavedIndex;
					i = mappingCount;
				}
			}
			return fromSavedIndex;
		}

		private int[] FindMapingsFrom(int fromSavedIndex)
		// FromSavedIndex from Old Channels
		{
			int[] toSavedIndex = new int[1];
			toSavedIndex[0] = -1;
			int foundCount = 0;
			for (int i = 0; i < mappingCount; i++)
			{
				if (mappings[i].fromSavedIndex == fromSavedIndex)
				{
					foundCount++;
					Array.Resize(ref toSavedIndex, foundCount);
					toSavedIndex[foundCount-1] = mappings[i].toSavedIndex;
				}
			}
			return toSavedIndex;
		}


	} // end class frmRemapper
} // end namespace ChannelRemapper
