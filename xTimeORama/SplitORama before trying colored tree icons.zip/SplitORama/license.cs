﻿////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//  The Util-O-Rama Suite and this program are copyrighted 2017-2018 by       //
//  Doctor Wizard and Wizster Software.  All rights reserved.                 //
//                                                                            //
//  The Util-O-Rama Suite and this program are released as FREEWARE for the   //
//  benefit of the Light-O-Rama community.                                    //
//                                                                            //
//  Source code is available on GitHub (but you already know that) under a    //
//  General Public License (GPL).                                             //
//                                                                            //
//  The Util-O-Rama Suite is not a product of, nor officially endorsed by     //
//  the Light-O-Rama company.                                                 //
//                                                                            //
//  The official compiled version of the Util-O-Rama suite can be downloaded  //
//  from http://wizlights.com/util-o-rama/download                            //
//                                                                            //
//  To submit bug reports, ideas, suggestions, rants, cool sequences, or      //
//  just some good dirty jokes, contact Dr. Wizard at:                        //
//  dev.utilorama@wizster.com                                                 //
//                                                                            //
//     Enjoy!                                                                 //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
