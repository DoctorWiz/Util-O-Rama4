﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LORUtils;

namespace ChannelRemapper
{
	public partial class frmMapList : Form
	{
		public bool sortByOld = true;
		public bool sortAlpha = false;
		public Sequence oldSeq;
		public Sequence newSeq;
		public MapInfo[] mappings;
		private const char DELIM_Map = (char)164;  // ¤
		private const string NOTMAPPED = "(Not Mapped)";

		public frmMapList()
		{
			InitializeComponent();
		}

		private void frmMapList_Load(object sender, EventArgs e)
		{
			lstMap.Columns[0].TextAlign = HorizontalAlignment.Right;
		}

		

		public void BuildList()
		{
			lstMap.Items.Clear();
			string itemText = "";
			ListViewItem newItem;
			if (sortByOld)
			{
				if (sortAlpha)
				{

				}
				else // NOT sort Alpha
				{

					for (int t = 0; t < oldSeq.trackCount; t++)
					{
						int tNo = t + 1;
						if (chkUnmapped.Checked)
						{
							newItem = new ListViewItem(NOTMAPPED);
							itemText = "Track " + tNo.ToString() + ":" + oldSeq.tracks[t].name;
							newItem.SubItems.Add(itemText);
							newItem.ImageIndex = 0;
							lstMap.Items.Add(newItem);
						}
						for (int ti = 0; ti < oldSeq.trackItemCount; ti++)
						{
							if (oldSeq.trackItems[ti].trackIndex == t)
							{
								//newItem = new ListViewItem(NOTMAPPED);
								//itemText = "Track " + tNo.ToString() + ":" + oldSeq.tracks[t].name;
								//newItem.SubItems.Add(itemText);
								//newItem.ImageIndex = 0;
								//lstMap.Items.Add(newItem);

								int si = oldSeq.trackItems[ti].savedIndex;
								if (oldSeq.savedIndexes[si].objType == tableType.channelGroup)
								{
									newItem = AddGroup(oldSeq, trackNode, oldSeq.savedIndexes[si].objIndex);
								}
								if (seq.savedIndexes[si].objType == tableType.channel)
								{
									newItem = AddChannel(oldSeq, trackNode, oldSeq.savedIndexes[si].objIndex);
								}
								if (seq.savedIndexes[si].objType == tableType.rgbChannel)
								{
									newItem = AddRGBchannel(oldSeq, trackNode, oldSeq.savedIndexes[si].objIndex);
								}
							}

						}


					}





				} // end Sort by Alpha
			}
			else // NOT sort by Old
			{
				// Sort by New

			}




		}

		private  void addNode(TreeNode nOde)
		{
			string oldTag = nOde.Tag.ToString();
			if (oldTag.Substring(0, 1).CompareTo("t") != 0)
			{
				ListViewItem newItem = new ListViewItem("");
				newItem.SubItems.Add("");
				int iPos = oldTag.IndexOf(DELIM_Map);
				if (iPos > 0)
				{
					string[] mappings = oldTag.Split(DELIM_Map);
					for (int m = 1; m < mappings.Length; m++)
					{
						newItem.Text = nOde.Text;
						TreeNode mappedNode = FindNode(oldTree.Nodes, mappings[m]);
						newItem.SubItems[1].Text = mappedNode.Text;
						lstMap.Items.Add(newItem);
					}
				}
				else
				{
					if (chkUnmapped.Checked)
					{
						newItem.Text = nOde.Text;
						newItem.SubItems[1].Text = NOTMAPPED;
						newItem.SubItems[1].Font = new Font(lstMap.Font, FontStyle.Italic);
						lstMap.Items.Add(newItem);
					}
				} // end mapped or not
			} // end node is not a track
			if (nOde.Nodes.Count > 0)
			{
				foreach (TreeNode child in nOde.Nodes)
				{
					addNode(child);
				}
			}
		}


		private TreeNode FindNode(TreeNodeCollection treeNodes, string tag)
		{
			int tl = tag.Length;
			string st = "";
			TreeNode ret = new TreeNode("NOT FOUND");
			bool found = false;
			foreach (TreeNode nOde in treeNodes)
			{
				if (!found)
				{
					if (nOde.Tag.ToString().Length >= tag.Length)
					{
						st = nOde.Tag.ToString().Substring(0, tl);
						if (tag.CompareTo(st) == 0)
						{
							ret = nOde;
							found = true;
							break;
						}
					}
					if (!found)
					{
						if (nOde.Nodes.Count > 0)
						{
							ret = FindNode(nOde.Nodes, tag);
							if (ret.Text.CompareTo("NOT FOUND") != 0)
							{
								found = true;
							}
						}
					}
				}
			}
			return ret;
		}



	}
}
