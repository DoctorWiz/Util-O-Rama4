﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Windows.Forms;
using System.IO;
using System.Media;
using LORUtils;


namespace SplitORama
{
	public partial class frmSplit : Form
	{
		private string seqFile = "";
		private string lastSeq = "";
		private string mapFile = "";
		private string lastMap = "";
		private Sequence seq = new Sequence();
		private int nodeIndex = LOR.UNDEFINED;
		private int selectionCount = 0;
		private int part = 1;
		private bool dirtyMap = false;
		private bool dirtySeq = false;
		private const string helpPage = "http://wizlights.com/util-o-rama/split-o-rama";
		private bool useFuzzy = true;
		private double minPreMatchScore = .8F;
		private double minFinalMatchScore = .95F;
		private string programName = "Split-O-Rama";
		private string tempPath = "C:\\Windows\\Temp\\";  // Gets overwritten with X:\\Username\\AppData\\Roaming\\Util-O-Rama\\Split-O-Rama\\

		//private List<TreeNode>[] siNodes;
		private List<List<TreeNode>> siNodes = new List<List<TreeNode>>();

		private bool firstShown = false;
		const char DELIM1 = '⬖';
		const char DELIM4 = '⬙';

		//private	string[] trackNames = null;
		//private int[] trackNums = null;
		//private string[] channelGroupNames = null;
		//private int[] channelGroupSIs = null;
		//private string[] rgbChannelNames = null;
		//private int[] rgbChannelSIs = null;
		//private string[] channelNames = null;
		//private int[] channelSIs = null;

		private Color COLOREDTEXT = System.Drawing.Color.Blue;
		private Color REGULARTEXT = System.Drawing.Color.Black;
		private Color HIGHLIGHTBACKGROUND = System.Drawing.Color.Yellow;
		private Color REGULARBACKGROUND = System.Drawing.Color.White;



		public frmSplit()
		{
			InitializeComponent();
			//? Why does this work in the about form, but not here???
			//programName = AssemblyTitle;
		}

		private void cmdBrowseSeq_Click(object sender, EventArgs e)
		{
			string initDir = Sequence.SequenceFolder;
			string initFile = "";

			dlgOpenFile.Filter = "Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lms";
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			dlgOpenFile.Title = "Select a Sequence...";
			//pnlAll.Enabled = false;
			DialogResult result = dlgOpenFile.ShowDialog(this);

			if (result == DialogResult.OK)
			{
				this.Cursor = Cursors.WaitCursor;
				seqFile = dlgOpenFile.FileName;

				FileInfo fi = new FileInfo(seqFile);
				Properties.Settings.Default.LastSequence = seqFile;
				Properties.Settings.Default.Save();

				txtSequenceFile.Text = utils.ShortenLongPath(seqFile, 80);
				seq.ReadSequenceFile(seqFile);
				utils.FillChannels(treChannels, seq, siNodes);
				part = 1;
				dirtySeq = false;
				this.Cursor = Cursors.Default;

				//TODO if map file exists, ask if user wants to apply it


			} // end if (result = DialogResult.OK)
				//pnlAll.Enabled = true;
		} // end browse for First File

		private void frmSplit_Load(object sender, EventArgs e)
		{
			InitForm();
		}

		private void InitForm()
		{
			this.Cursor = Cursors.WaitCursor;
			RestoreFormPosition();

			lastSeq = Properties.Settings.Default.LastSequence;
			lastMap = Properties.Settings.Default.LastMap;

			string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			string mySubDir = "\\Util-O-Rama\\" + Application.ProductName + "\\";
			tempPath = appDataDir + mySubDir;

			useFuzzy = Properties.Settings.Default.useFuzzy;
			minPreMatchScore = Properties.Settings.Default.preMatchScore;
			if ((minPreMatchScore < .5) || (minPreMatchScore > 1))
			{
				minPreMatchScore = 0.8F;
			}
			minFinalMatchScore = Properties.Settings.Default.finalMatchScore;
			if ((minFinalMatchScore < .5) || (minFinalMatchScore > 1))
			{
				minFinalMatchScore = 0.95F;
			}

			if (File.Exists(lastSeq))
			{
				seq.ReadSequenceFile(lastSeq);
				seqFile = lastSeq;
				utils.FillChannels(treChannels, seq, siNodes);
				txtSequenceFile.Text = utils.ShortenLongPath(seqFile, 80);




			}
			this.Cursor = DefaultCursor;

		}

		private void ReadApplyPreviousMap()
		{
			string lastSelFile = "lastSelections.ChSel";
			string file = tempPath + lastSelFile;
			if (File.Exists(file))
			{
				ReadApplyMap(file, false);
			}
		}


		private void SaveFormPosition()
		{
			// Called with form is closed
			if (WindowState == FormWindowState.Normal)
			{
				Properties.Settings.Default.Location = Location;
				Properties.Settings.Default.Size = Size;
				Properties.Settings.Default.Minimized = false;
			}
			else
			{
				Properties.Settings.Default.Location = RestoreBounds.Location;
				Properties.Settings.Default.Size = RestoreBounds.Size;
				Properties.Settings.Default.Minimized = true;
			}
			Properties.Settings.Default.Save();
			this.Cursor = Cursors.Default;

		} // End SaveFormPosition

		private void RestoreFormPosition()
		{
			// Called when form is loaded
			//TODO: This only gets the area of the first screen in a multi-screen setup

			int ileft = Properties.Settings.Default.Location.X;
			int itop = Properties.Settings.Default.Location.Y;
			//int scrHt = Screen.PrimaryScreen.Bounds.Height;
			//int scrWd = Screen.PrimaryScreen.Bounds.Width;
			//int scrHt = SystemInformation.VirtualScreen.Height;
			//int scrWd = SystemInformation.VirtualScreen.Width;
			int scrWd = SystemInformation.WorkingArea.Width;
			int scrHt = SystemInformation.WorkingArea.Height;



			if (itop > (scrHt - this.Height))
			{
				itop = scrHt - this.Height;
			}
			if (ileft > (scrWd - this.Width))
			{
				ileft = scrWd - this.Width;
			}
			
			
			// Should get all screens and figure out if size/placement of the form is valid
			//TODO: Restore form.WindowState and if maximized use RestoreBounds()
			this.SetDesktopLocation(ileft, itop);

		} // End RestoreFormPosition

		private void CloseForm()
		{
			SaveFormPosition();
		}



		private void frmSplit_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (dirtySeq)
			{
				string msg = "Your selections have changed.\r\n\r\n";
				msg += "Do you want to save the selected channels to a new sequence?";
				DialogResult result = MessageBox.Show(this, msg, "Save Changes?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question,
					MessageBoxDefaultButton.Button1);

				if (result == DialogResult.Cancel)
				{
					e.Cancel = true;
				}
				else
				{
					if (result == DialogResult.Yes)
					{
						cmdSaveSequence.PerformClick();
					}
				}

				if (!e.Cancel)
				{
					if (dirtyMap)
					{
						msg = "Your selections have changed.\r\n\r\n";
						msg += "Do you want to save the selections to a Channel Selection file?";
						result = MessageBox.Show(this, msg, "Save Changes?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question,
							MessageBoxDefaultButton.Button1);

						if (result == DialogResult.Cancel)
						{
							e.Cancel = true;
						}
						else
						{
							if (result == DialogResult.Yes)
							{
								cmdSaveMap.PerformClick();
							}
						}
					}
				}
			}

			if (!e.Cancel)
			{
				this.Cursor = Cursors.WaitCursor;
				string where = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
				string when = "\\Util-O-Rama\\" + programName + "\\";
				if (!Directory.Exists(where + "\\Util-O-Rama"))
				{
					Directory.CreateDirectory(where + when);
				}
				string what = "lastSelections.ChSel";
				string file = where + when + what;
				SaveMap(file);
				CloseForm();

			}
		}

		private void treChannels_AfterSelect(object sender, TreeViewEventArgs e)
		{
			utils.ChanInfo nodeTag;
			bool ignoreRGB = false;
			nodeTag = (utils.ChanInfo)e.Node.Tag;
			string foo = e.Node.Text;  //! FOR DEBUGGING, REMOVE LATER
			if (e.Node.Parent != null)
			{
				utils.ChanInfo nt = (utils.ChanInfo)e.Node.Parent.Tag;
				if (nt.tableType == tableType.rgbChannel)
				{
					// If the node clicked on has a parent,
					// and that parent is an RGBchannel,
					// Then this is an RGB sub channel,
					// So IGNORE this click
					ignoreRGB = true;
				}
			}
			if (!ignoreRGB)
			{
				HighlightNode(e.Node, !e.Node.Checked);
			}
			//? Why doesn't this work?
			//cmdSaveMap.Enabled = (selectionCount > 0);
			if (selectionCount > 0)
			{
				//cmdSaveMap.Enabled = true;
				//btnSave.Enabled = true;
			}
			else
			{
				//cmdSaveMap.Enabled = false;
				//btnSave.Enabled = false;
			}
			lblSelectionCount.Text = selectionCount.ToString();
			//cmdNothing.Focus();
			treChannels.SelectedNode = null;
			txtMapFile.Focus();
			dirtyMap = true;
			dirtySeq = true;

		}

		void HighlightNode(TreeNode nOde, bool highlight)
		{
			// Set this one
			nOde.Checked = highlight;
			HighlightNodeBackground(nOde, highlight);
			utils.ChanInfo ci = (utils.ChanInfo)nOde.Tag;
			//SelectChannel(ci.savedIndex, highlight);
			SelectChannel(nOde, highlight);
			if (highlight)
			{
				selectionCount++;
			}
			else
			{
				selectionCount--;
			}
			// And all children
			HighlightChildNodes(nOde.Nodes, highlight);
			// and now parents
			TreeNode pArent = nOde.Parent;
			while (pArent != null)
			{
				if (highlight)
				{
					// If turning on the highlight, turn on each parent
					pArent.Checked = highlight;
					HighlightNodeBackground(pArent, highlight);
					selectionCount++;
				}
				else
				{
					bool otherChildren = HasSelectedChildren(pArent);
					if (otherChildren)
					{
						// Has other children that are still selected
						// therefore, do not unhighlight it
					}
					else
					{
						// Has no remaining children selected
						// OK to unhighlight it
						pArent.Checked = false;
						HighlightNodeBackground(pArent, highlight);
						selectionCount--;
					}
				}
				pArent = pArent.Parent;
			}
		} // end highlight node

		void HighlightChildNodes(TreeNodeCollection nOdes, bool highlight)
		{
			foreach (TreeNode nOde in nOdes)
			{
				// Highlight all children
				nOde.Checked = highlight;
				HighlightNodeBackground(nOde, highlight);
				if (highlight)
				{
					selectionCount++;
				}
				else
				{
					selectionCount--;
				}
				if (nOde.Nodes.Count > 0)
				{
					HighlightChildNodes(nOde.Nodes, highlight);
				}
			}
		} // end highlight child nodes

		void SelectChannel(TreeNode nOde, bool select)
		{
			utils.ChanInfo nodeTag = (utils.ChanInfo)nOde.Tag;
			List<TreeNode> chNodes = siNodes[nodeTag.savedIndex];
			int selCount = 0;
			bool selSome = false;

			for (int cx=0; cx< chNodes.Count; cx++)
			{
				if(chNodes[cx].Checked)
				{
					selCount++;
				}
			}
			if (selCount > 0) selSome = true; else selSome = false;
			//selSome = (selCount > 0);  //? Why doesn't this work?
			for (int cx = 0; cx < chNodes.Count; cx++)
			{
				ItalisizeNode(chNodes[cx], selSome);
			}
		}


		void SelectNodes(int nodeSI, bool select, bool andChildren)
		{
			utils.ChanInfo nodeTag;
			List<TreeNode> qlist;

			//if (siNodes[nodeSI]!= null)
			if (nodeSI == LOR.UNDEFINED)
			{
				// WHY?
				int xx = 1;
			}
			else
			{
				qlist = siNodes[nodeSI];
				if (qlist.Count > 0)
				{
					//if (siNodes[nodeSI].Length > 0)
					//if (siNodes[nodeSI])
					//{
					//foreach (TreeNode nOde in siNodes[nodeSI])
					for (int q = 0; q < siNodes[nodeSI].Count; q++)
					{
						TreeNode nOde = siNodes[nodeSI][q];
						if (select)
						{
							if (!nOde.Checked) // sanity check, should not be checked
							{
								nOde.Checked = true;
								selectionCount++;
								nOde.ForeColor = Color.Yellow;
								nOde.BackColor = Color.DarkBlue;
								if (andChildren)
								{
									if (nOde.Nodes.Count > 0)
									{
										foreach (TreeNode childNode in nOde.Nodes)
										{
											nodeTag = (utils.ChanInfo)childNode.Tag;
											SelectNodes(nodeTag.savedIndex, select, true);
										}
									}
								}
								if (nOde.Parent != null)
								{
									nodeTag = (utils.ChanInfo)nOde.Parent.Tag;
									SelectNodes(nodeTag.savedIndex, select, false);
								}
							} // node.!checked
						}
						else // !select
						{
							if (nOde.Checked) // sanity check, should be checked
							{
								nOde.Checked = false;
								selectionCount--;
								nOde.ForeColor = SystemColors.WindowText;
								nOde.BackColor = SystemColors.Window;
								if (andChildren)
								{
									if (nOde.Nodes.Count > 0)
									{
										foreach (TreeNode childNode in nOde.Nodes)
										{
											nodeTag = (utils.ChanInfo)childNode.Tag;
											SelectNodes(nodeTag.savedIndex, select, true);
										}
									}
								}
								if (nOde.Parent != null)
								{
									if (!HasSelectedChildren(nOde.Parent))
									{
										nodeTag = (utils.ChanInfo)nOde.Parent.Tag;
										SelectNodes(nodeTag.savedIndex, select, false);
									}
								}
							} // node.checked
						} // if (select)
					} // foreach (TreeNode nOde in siNodes[nodeSI])
						//}
				} // siNodes[nodeSI].Count > 0
				else
				{
					// siNodes[nodeSI].Count = 0
					//? Why Not?
					int x = 1;
				}
			}
		} // end SelectNode

		private bool HasSelectedChildren(TreeNode nOde)
		{
			bool ret = false;
			if (nOde.Nodes.Count > 0)
			{
				foreach (TreeNode childNode in nOde.Nodes)
				{
					ret = childNode.Checked;
					if (ret)
					{
						break;
					}
				}
			}
			return ret;
		} // end HasSelectedChildren

		#region Node Appearnce
		private void ItalisizeNode(TreeNode nOde, bool italisize)
		{
			if (italisize)
			{
				nOde.NodeFont = new Font(treChannels.Font, FontStyle.Italic);
							}
			else
			{
				nOde.NodeFont = new Font(treChannels.Font, FontStyle.Regular);
			}
		}
		private void EmboldenNode(TreeNode nOde, bool embolden)
		{
			if (embolden)
			{
				nOde.NodeFont = new Font(nOde.NodeFont, FontStyle.Bold);
			}
			else
			{
				nOde.NodeFont = new Font(nOde.NodeFont, FontStyle.Regular);
			}
		}
		private void HighlightNodeBackground(TreeNode nOde, bool highlight)
		{
			if (highlight)
			{
				nOde.BackColor = HIGHLIGHTBACKGROUND;
			}
			else
			{
				nOde.BackColor = REGULARBACKGROUND;
			}
		}
		private void ColorNodeText(TreeNode nOde, bool colorize)
		{
			if (colorize)
			{
				nOde.ForeColor = COLOREDTEXT;
			}
			else
			{
				nOde.ForeColor = REGULARTEXT;
			}
		}
		#endregion

		private void treChannels_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
		{
		}

		private void cmdInvert_Click(object sender, EventArgs e)
		{
			this.Cursor = Cursors.WaitCursor;
			InvertSelections(treChannels.Nodes);
			this.Cursor = Cursors.Default;
		}

		void InvertSelections(TreeNodeCollection nOdes)
		{ 
			foreach (TreeNode nOde in nOdes)
			{
				utils.ChanInfo nodeTag = (utils.ChanInfo)nOde.Tag;
				if (nodeTag.tableType == tableType.channel)
				{
					HighlightNode(nOde, !nOde.Checked);
				}
				if (nOde.Nodes.Count > 0)
				{
					InvertSelections(nOde.Nodes);
				}
			} // foreach nodes
		} // end Invert Selection

		private void CopySelectionsToSequence()
		{
			// Clear any previous selections
			for (int tr=0; tr< seq.tracks.Count; tr++)
			{
				seq.tracks[tr].selected = false;
			}
			for (int tg = 0; tg < seq.timingGrids.Count; tg++)
			{
				seq.timingGrids[tg].selected = false;
			}
			for (int chg=0; chg<seq.channelGroups.Count; chg++)
			{
				seq.channelGroups[chg].selected = false;
			}
			for (int rch=0; rch< seq.rgbChannels.Count; rch++)
			{
				seq.rgbChannels[rch].selected = false;
			}
			for (int ch=0; ch< seq.channels.Count; ch++)
			{
				seq.channels[ch].selected = false;
			}

			// Select only timing grids used by selected tracks
			foreach (TreeNode nOde in treChannels.Nodes)
			{
				if (nOde.Checked)
				{
					utils.ChanInfo nodeTag = (utils.ChanInfo)nOde.Tag;
					if (nodeTag.tableType == tableType.track)  // Just a sanity check, all first level nodes should be tracks
					{
						track t = seq.tracks[nodeTag.objIndex];
						//int tgIdx = t.timingGridObjIndex;
						//for (int tg = 0; tg < seq.timingGrids.Count; tg++)
						//{
						//	if (seq.timingGrids[tg].saveID == tgIdx)
						//	{
						//		seq.timingGrids[tg].selected = true;
						//	}
						seq.timingGrids[t.timingGridObjIndex].selected = true;
						//}
					}
				}
			}

			CopyNodeSelectionsToSequence(treChannels.Nodes);

		} // end CopySelectionToSequence

		private void CopyNodeSelectionsToSequence(TreeNodeCollection nOdes)
		{
			utils.ChanInfo nodeTag;

			foreach (TreeNode nOde in nOdes)
			{
				if (nOde.Checked)
				{
					nodeTag = (utils.ChanInfo)nOde.Tag;
					if (nodeTag.tableType == tableType.track)
					{
						seq.tracks[nodeTag.objIndex].selected = nOde.Checked;
					}
					if (nodeTag.tableType == tableType.channel)
					{
						seq.channels[nodeTag.objIndex].selected = nOde.Checked;
					}
					if (nodeTag.tableType == tableType.rgbChannel)
					{
						seq.rgbChannels[nodeTag.objIndex].selected = nOde.Checked;
					}
					if (nodeTag.tableType == tableType.channelGroup)
					{
						seq.channelGroups[nodeTag.objIndex].selected = nOde.Checked;
					}
					if (nOde.Nodes.Count > 0)
					{
						CopyNodeSelectionsToSequence(nOde.Nodes);
					}
				} // loop thru nodes
			}
		} // end CopyNodeSelectionToSequence

		private void btnSave_Click(object sender, EventArgs e)
		{
			string newFileIn;
			string newFileOut;
			string ext = Path.GetExtension(seqFile).ToLower();
			if (ext == ".las")
			{
				dlgSaveFile.Filter = "Animated Sequences (*.las)|*.las";
			}
			if (ext == ".lms")
			{
				dlgSaveFile.Filter = "Musical Sequences (*.lms)|*.lms";
			}
			dlgSaveFile.FilterIndex = 1;
			//dlgSaveFile.FileName = Path.GetFullPath(seqFile) + Path.GetFileNameWithoutExtension(seqFile) + " Part " + part.ToString() + ext;
			dlgSaveFile.CheckPathExists = true;
			dlgSaveFile.InitialDirectory = Path.GetFullPath(seqFile);
			dlgSaveFile.DefaultExt = ext;
			dlgSaveFile.OverwritePrompt = true;
			dlgSaveFile.Title = "Save Partial Sequence As...";
			dlgSaveFile.SupportMultiDottedExtensions = true;
			dlgSaveFile.ValidateNames = true;
			newFileIn = Path.GetFileNameWithoutExtension(seqFile) + " Part " + part.ToString(); // + ext;
			//newFileIn = "Part " + part.ToString() + " of " + Path.GetFileNameWithoutExtension(seqFile);
			//newFileIn = "Part Mother Fucker!!";
			dlgSaveFile.FileName = newFileIn;
			DialogResult result = dlgSaveFile.ShowDialog(this);
			if (result == DialogResult.OK)
			{
				//this.Cursor = Cursors.WaitCursor;
				newFileOut = dlgSaveFile.FileName;
				//int pos = newFileOut.IndexOf("Part ");
				//if (pos < 0)
				//{
				//	string msg = "Dadgummit!";
				//	DialogResult r = MessageBox.Show(this, msg, "Failure!", MessageBoxButtons.OK, MessageBoxIcon.Stop, MessageBoxDefaultButton.Button1);
				//	int xxx = 1;
				//}
				//else
				//{

					//! For testing only...
					frmOptions options = new frmOptions();
					options.InitForm(false);
					DialogResult dr2 = options.ShowDialog(this);
					if (dr2 == DialogResult.OK)
					{
						this.Cursor = Cursors.WaitCursor;
						int saveFormat = options.saveFormat;
						CopySelectionsToSequence();
						if (saveFormat == frmOptions.SAVEmixedDisplay)
						{
							// normal default when not testing
							seq.WriteSequenceFileInDisplayOrder(newFileOut, true);
						}
						if (saveFormat == frmOptions.SAVEcrgDisplay)
						{
							seq.WriteSequenceFileInCRGDisplayOrder(newFileOut, true);
						}
						if (saveFormat == frmOptions.SAVEcrgAlpha)
						{
							seq.WriteSequenceFileInCRGAlphaOrder(newFileOut, true);
						}
						System.Media.SystemSounds.Beep.Play();
						part++;
						dirtySeq = false;
					}
				//}
				this.Cursor = Cursors.Default;
			}
		} // end Save File As

		private void cmdSaveMap_Click(object sender, EventArgs e)
		{
			dlgSaveFile.DefaultExt = "ChSel";
			dlgSaveFile.Filter = "Channel Selections|*.ChSel";
			dlgSaveFile.FilterIndex = 0;
			string initDir = Sequence.SequenceFolder + "Channel Maps\\";
			string initFile = "";
			if (mapFile.Length > 4)
			{
				string pth = Path.GetFullPath(mapFile);
				if (Directory.Exists(pth))
				{
					initDir = pth;
				}
				if (File.Exists(mapFile))
				{
					initFile = Path.GetFileName(mapFile);
				}
				else
				{
					if (File.Exists(seqFile))
					{
						initFile = Path.GetFileNameWithoutExtension(seqFile) +"Channel Selections";
					}
				}
			}
			dlgSaveFile.FileName = initFile;
			dlgSaveFile.InitialDirectory = initDir;
			dlgSaveFile.OverwritePrompt = true;
			dlgSaveFile.CheckPathExists = true;
			dlgSaveFile.DefaultExt = "ChSel";
			dlgSaveFile.SupportMultiDottedExtensions = true;
			dlgSaveFile.ValidateNames = true;
			dlgSaveFile.Title = "Save Channel Selections As...";

			DialogResult dr = dlgSaveFile.ShowDialog(this);
			if (dr == DialogResult.OK)
			{
				this.Cursor = Cursors.WaitCursor;
				string mapTemp = System.IO.Path.GetTempPath();
				mapTemp += Path.GetFileName(dlgSaveFile.FileName);
				int mapErr = SaveMap(mapTemp);
				if (mapErr == 0)
				{
					mapFile = dlgSaveFile.FileName;
					if (File.Exists(mapFile))
					{
						//TODO: Add Exception Catch
						File.Delete(mapFile);
					}
					File.Copy(mapTemp, mapFile);
					File.Delete(mapTemp);
					dirtyMap = false;
					//cmdSaveMap.Enabled = dirtyMap;
					SystemSounds.Beep.Play();
					this.Cursor = Cursors.Default;
				} // end no errors saving map
			}	// end dialog result = OK
		} // end SaveMapAs...

		private int SaveMap(string fileName)
		{
			int ret = 0;

			int lineCount = 0;
			StreamWriter writer = new StreamWriter(fileName);
			string lineOut = ""; // line to be written out, gets modified if necessary
													 //int pos1 = LOR.UNDEFINED; // positions of certain key text in the line

			SaveSelectionsToMap(writer, treChannels.Nodes);

			writer.Close();
			dirtyMap = false;
			return ret;
		} // end SaveMap

		private void SaveSelectionsToMap(StreamWriter writer, TreeNodeCollection nOdes)
		{
			string lineOut = "";
			utils.ChanInfo nodeTag;
			foreach (TreeNode nOde in nOdes)
			{
				if (nOde.Checked)
				{
					nodeTag = (utils.ChanInfo)nOde.Tag;
					tableType type;
					type = nodeTag.tableType;
					lineOut = nodeTag.tableType.ToString() + DELIM1;
					lineOut += nOde.Text + DELIM1;
					lineOut += nodeTag.savedIndex.ToString() + DELIM1;
					lineOut += nodeTag.objIndex.ToString() + DELIM1;
					if (type == tableType.channel)
					{
						lineOut += seq.channels[nodeTag.objIndex].output.ToString();
					}
					else
					{
						lineOut += "None" + DELIM4 + "-1" + DELIM4 + "-1" + DELIM4 + "-1"; // + DELIM2;
					}

					writer.WriteLine(lineOut);

					if (nOde.Nodes.Count > 0)
					{
						SaveSelectionsToMap(writer, nOde.Nodes);
					} // has children
				} // node checked
			} // loop thru nodes
		} // end SaveSelectionsToMap

		private void cmdBrowseMap_Click(object sender, EventArgs e)
		{
			dlgOpenFile.DefaultExt = "ChSel";
			dlgOpenFile.Filter = "Channel Selections|*.ChSel";
			dlgOpenFile.DefaultExt = "ChMap";
			dlgOpenFile.FilterIndex = 0;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.SupportMultiDottedExtensions = true;
			dlgOpenFile.ValidateNames = true;
			
			string initDir = Sequence.SequenceFolder + "Channel Maps\\";
			string initFile = "";
			if (mapFile.Length > 4)
			{
				string pth = Path.GetFullPath(mapFile);
				if (Directory.Exists(pth))
				{
					initDir = pth;
				}
				if (File.Exists(mapFile))
				{
					initFile = Path.GetFileName(mapFile);
				}
			}
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Title = "Load-Apply Channel Selections..";

			DialogResult dr = dlgOpenFile.ShowDialog(this);
			if (dr == DialogResult.OK)
			{
				frmOptions options = new frmOptions();
				options.useFuzzy = useFuzzy;
				options.preMatchScore = (int)(minPreMatchScore * 100);
				options.finalMatchScore = (int)(minFinalMatchScore * 100);
				options.InitForm(true);
				DialogResult dr2 = options.ShowDialog();
				if (dr2 == DialogResult.OK)
				{
					useFuzzy = options.useFuzzy;
					Properties.Settings.Default.useFuzzy = useFuzzy;
					if (useFuzzy)
					{
						minPreMatchScore = options.preMatchScore / 100;
						minFinalMatchScore = options.finalMatchScore / 100;
						Properties.Settings.Default.preMatchScore = minPreMatchScore;
						Properties.Settings.Default.finalMatchScore = minFinalMatchScore;
					}
					Properties.Settings.Default.Save();

					this.Cursor = Cursors.WaitCursor;
					mapFile = dlgOpenFile.FileName;
					txtMapFile.Text = Path.GetFileName(mapFile);
					Properties.Settings.Default.LastMap = mapFile;
					Properties.Settings.Default.Save();
					ReadApplyMap(dlgOpenFile.FileName, true);
					dirtyMap = false;
					//btnSaveMap.Enabled = dirtyMap;
					this.Cursor = Cursors.Default;
				}
			} // end dialog result = OK

		} // end cmdBrowseMap_Click

		private int ReadApplyMap(string mapFilename, bool fuzzy)
		{
			int lineCount = 0;
			string lineIn = ""; // line to be read in, gets parsed as requited
			StreamReader reader;

			//if (fuzzy)
			//{
				// get linecount for progress bar
				reader = new StreamReader(mapFilename);
				while ((lineIn = reader.ReadLine()) != null)
				{
					lineCount++;
				}
				reader.Close();
				pnlProgress.Maximum = lineCount;
				pnlProgress.Value = 0;
				pnlProgress.Visible = true;
				this.Cursor = Cursors.WaitCursor;
			//}


				//////////////////////////////////////////////
				// PART ONE -	build sorted arrays of names //
				////////////////////////////////////////////
			FillNameLists();
			seq.SortAllNames();
			//Array.Sort(trackNames, trackNums);
			//Array.Sort(channelGroupNames, channelGroupSIs);
			//Array.Sort(rgbChannelNames, rgbChannelSIs);
			//Array.Sort(channelNames, channelSIs);

			//////////////////////////////////////////////
			// PART TWO -	search sorted arrays of names //
			////////////////////////////////////////////
			int noFind = 0;
			int foundSI = LOR.UNDEFINED;
			int foundIdx = LOR.UNDEFINED;
			reader = new StreamReader(mapFilename);
			string[] parts = null;
			//string type = "";
			tableType objType = tableType.None;
			string objName = "";
			string output = "";
			string prevSelection = "";
			string[] childNodeNames = null;
			TreeNode foundNode = null;
			TreeNode prevNOde = null;
			string prevParentText = "";
			ClearSelections(treChannels.Nodes);

			while ((lineIn = reader.ReadLine()) != null)
			{
				if (lineIn.Length > 7)
				{
					parts = lineIn.Split(DELIM1);
					if (parts.Length == 5)
					{
						objType = (tableType) Enum.Parse(typeof(tableType), parts[0]);
						objName = parts[1];
						foundNode = null;
						foundIdx = LOR.UNDEFINED;
						if (objType == tableType.track)
						{
							foundNode = FindNodeByName(treChannels.Nodes, objName, tableType.track, fuzzy);
							prevNOde = foundNode;
						}
						else
						{
							// else not a track
							if (prevNOde != null)
							{
								if (prevNOde.Nodes.Count > 0)
								{
									// check the children of the previous node
									foundNode = FindNodeByName(prevNOde.Nodes, objName, objType, fuzzy);
								}
								if (foundNode == null)
								{
									// not a child of the previous node
									// check it's siblings
									TreeNode prevParent = prevNOde.Parent;
									while ((foundNode == null) && (prevParent != null))
									{
										if (prevParent.Text.CompareTo(prevParentText) == 0)
										{
											int xyz = 1;
										}
										prevParentText = prevParent.Text;
										#if DEBUG
											string dbgmsg = "Searching children of '" + prevParent.Text + "' for '" + objName + "'";
											Console.WriteLine(dbgmsg);
										#endif
										foundNode = FindNodeByName(prevParent.Nodes, objName, objType, fuzzy);
										if (foundNode == null)
										{
											//recurse backwards up the tree
											prevParent = prevParent.Parent;
										}
									}
								}
								if (foundNode != null)
								{
									prevNOde = foundNode;
								}
								else
								{
									//TODO: Log not found
									noFind++;
									#if DEBUG
									string foooo = objName;
										System.Diagnostics.Debugger.Break();
									#endif
								}
							} // previous node is not null
						} // end if channel
					} // line split into exactly 4 parts
				} // end if length > 7
				pnlProgress.Value = lineCount;
				staStatus.Refresh();
			} // end while more lines

			reader.Close();
			pnlProgress.Visible = false;
			this.Cursor = Cursors.Default;
			return noFind;

		} // end LoadApplyMap

		private TreeNode FindNodeByName(TreeNodeCollection nOdes, string name, tableType tableType, bool fuzzy)
		{


			TreeNode ret = null;
			int foundIdx = LOR.UNDEFINED;
			string[] childNodeNames = null;
			Array.Resize(ref childNodeNames, nOdes.Count);
			for (int n = 0; n < nOdes.Count; n++)
			{
				if (nOdes[n].Text.CompareTo(name) == 0)
				{
					utils.ChanInfo nodeTag = (utils.ChanInfo)nOdes[n].Tag;
					if (nodeTag.tableType == tableType)
					{
						foundIdx = n;
						nOdes[n].Checked = true;
						HighlightNodeBackground(nOdes[n], true);
						SelectChannel(nOdes[n], true);
						//prevNOde = treChannels.Nodes[n];
						ret = nOdes[n];
						n = nOdes.Count; // break out
					}
				}
				else
				{
					childNodeNames[n] = nOdes[n].Text;
				} // end found, or not
			} // end loop thru child nodes
			if (foundIdx == LOR.UNDEFINED)
			{
				if (fuzzy)
				{
					foundIdx = utils.FuzzyFindName(childNodeNames, name, minPreMatchScore, minFinalMatchScore);
					if (foundIdx > LOR.UNDEFINED)
					{
						utils.ChanInfo nodeTag = (utils.ChanInfo)nOdes[foundIdx].Tag;
						//utils.ChanInfo nodeTag = (utils.ChanInfo)siNodes[foundIdx];

						if (nodeTag.tableType == tableType)
						{
							nOdes[foundIdx].Checked = true;
							HighlightNodeBackground(nOdes[foundIdx], true);
							SelectChannel(nOdes[foundIdx], true);
							//prevNOde = nOdes[foundIdx];
						}
						else
						{
							foundIdx = LOR.UNDEFINED;
						}
					}
				} // end use Fuzzu
			} // exact match found
			if (foundIdx == LOR.UNDEFINED)
			{
				// STILL not found
				//prevNOde = null;
				//TODO Log Track Not Found
				int qq = 1;
			}
			return ret;
		}

		private void FillNameLists()
		{
			seq.SortAllNames();
		}

		private void ClearSelections(TreeNodeCollection nOdes)
		{
			foreach (TreeNode nOde in nOdes)
			{
				if (nOde.Checked)
				{
					nOde.Checked = false;
					nOde.ForeColor = SystemColors.WindowText;
					nOde.BackColor = SystemColors.Window;
					selectionCount--;
				}
				if (nOde.Nodes.Count > 0)
				{
					ClearSelections(nOde.Nodes);
				}
			} // end for each node
		} // end ClearSelections



		private void pnlAbout_Click(object sender, EventArgs e)
		{
			Form aboutBox = new frmAbout();
			//aboutBox.Icon = this.Icon;
			//aboutBox.InitForm();
			
			aboutBox.Show(this);

		}

		private void pnlHelp_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start(helpPage);
		}

		private void cmdClear_Click(object sender, EventArgs e)
		{
			ClearSelections(treChannels.Nodes);
			selectionCount = 0;

		}

		private void cmdAll_Click(object sender, EventArgs e)
		{
			foreach (TreeNode nOde in treChannels.Nodes)
			{
				nOde.Checked = true;
				HighlightNodeBackground(nOde, true);
				ColorNodeText(nOde, true);
				HighlightChildNodes(nOde.Nodes, true);
			}
		}

		private void lblSelectionCount_Click(object sender, EventArgs e)
		{

		}

		private void frmSplit_Paint(object sender, PaintEventArgs e)
		{
			if (!firstShown)
			{
				ReadApplyPreviousMap();
				firstShown = true;
			}
		}
	} // end frmSplit
} // end namespace SplitORama
