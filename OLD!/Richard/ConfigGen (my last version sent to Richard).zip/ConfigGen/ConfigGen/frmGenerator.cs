﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.Win32;
using LORUtils;

namespace ConfigGen
{
	public partial class frmGen : Form
	{
		private const int treeUniv1 = 21;
		private const int caneUniv1 = 13;
		private const int caneUniv2 = 15;
		private const int caneUniv3 = 17;
		private const int caneUniv4 = 19;
		private const int flakeUniv1 = 9;
		private const int flakeUniv2 = 11;
		private const int eaveUniv =1;
		private const int edgeUniv = 3;
		private const int edgeSize = 117; // # of pixels on left and right sides/edges of house
		private const int eaveSize = 369; // # of pixels along top eave
		private const int leftWinUniv = 79;
		private const int leftWinSideSize = 53;
		private const int leftWinTopSize = 79;
		private const int rightWinUniv = 81;
		private const int rightWinSideSize = 63;
		private const int rightWinTopSize = 79;
		private const string file_name = "\\2016 Richard - Master Channel Config v";
		private const decimal version = 1.4m;


		private const int centiseconds = 100;



		string sequenceFolder;

		int universe = 0;
		int circuit = 0;
		bool flakeMode = false;
		int pixelCount = 0;

		Sequence seq;
		track track_pixorder;
		track track_logical;
		channelGroup group_outlines_pixorder;

		public frmGen()
		{
			InitializeComponent();
		}

		private void frmGen_Load(object sender, EventArgs e)
		{
			LoadSettings();
		}

		private void LoadSettings()
		{
			this.Left = Properties.Settings.Default.Left;
			this.Top = Properties.Settings.Default.Top;
			sequenceFolder = getSequenceFolder();
		}

		private void frmGen_FormClosing(object sender, FormClosingEventArgs e)
		{
			SaveSettings();
		}

		private void SaveSettings()
		{
			Properties.Settings.Default.Left = this.Left;
			Properties.Settings.Default.Top = this.Top;
			Properties.Settings.Default.Save();
		}

		private void btnOK_Click(object sender, EventArgs e)
		{
			GenerateConfig();
		} // end btnOK_Click

		private void GenerateConfig()
		{
			btnOK.Enabled = false;
			this.Enabled = false;
			this.Cursor = Cursors.WaitCursor;
			prgStatus.Visible = true;
			lblCount.Visible = true;
			pixelCount = 0;

			GenerateSequence();
			GenerateTrees();
			GenerateCanes();
			GenerateFlakes();
			GenerateStrips();

			seq.AddTrack(track_logical);
			seq.AddTrack(track_pixorder);

			seq.WriteFileInDisplayOrder(sequenceFolder + file_name + version.ToString("##.##") + ".las");

			lblCount.Visible = false;
			prgStatus.Visible = false;
			pnlName.Text = "";
			pnlFixture.Text = "";
			pnlCol.Text = "";
			pnlRow.Text = "";
			pnlUniverse.Text = "";
			pnlChannel.Text = "";

			this.Cursor = Cursors.Default;
			this.Enabled = true;
			btnOK.Enabled = true;
			System.Media.SystemSounds.Beep.Play();
		} // end GenerateConfig

		private void GenerateSequence()
		{
			// Create a new sequence from scratch
			seq = new Sequence();
			seq.totalCentiseconds = centiseconds;
			seq.xmlInfo = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			string dt = DateTime.Now.ToString("MM / dd / yyyy h:mm:ss tt");
			seq.sequenceInfo = "<sequence saveFileVersion=\"14\" author=\"Richard F. Burna II\" createdAt=\"" + dt + "\" videoUsage=\"2\">";

			// It must have a timing grid, so make a simple fixed one
			timingGrid tg = new timingGrid();
			tg.type = timingGridType.fixedGrid;
			tg.name = "1/20 sec fixed";
			tg.spacing = 5;
			tg.saveID = 0;
			seq.AddTimingGrid(tg);

			// Make a track to hold each and every pixel, once, in physical universe/channel number order
			track_logical = new track();
			track_logical.name = "In Logical Order";
			track_logical.totalCentiseconds = centiseconds;
			track_logical.timingGridIndex = 0;
			track_logical.timingGridSaveID = 0;

			// Make a new track to hold each pixel, at least once, in a logical order for sequencing
			track_pixorder = new track();
			track_pixorder.name = "In Universe/Pixel Number Order";
			track_pixorder.totalCentiseconds = centiseconds;
			track_pixorder.timingGridIndex = 0;
			track_pixorder.timingGridSaveID = 0;


		} // end GenerateSequence

		void GenerateTrees()
		{ 
			universe = treeUniv1;
			circuit = 1;

			// Grouping prefered order of operations:
			//  1. create group
			//  2. fill group with items (channels, RGB channels, other groups)
			//  3. add the group to the sequence
			//  4. 

			channelGroup treesGroupLogical = new channelGroup();
			treesGroupLogical.name = MakeGroupName("Trees", -1, -1, -1, -1, -1, -1);
			treesGroupLogical.totalCentiSeconds = centiseconds;
			channelGroup treesGroupLogicalByCol = new channelGroup();
			treesGroupLogicalByCol.name = MakeGroupName("Trees by Column", -1, -1, -1, -1, -1, -1);
			treesGroupLogicalByCol.totalCentiSeconds = centiseconds;
			channelGroup treesGroupLogicalByRow = new channelGroup();
			treesGroupLogicalByRow.name = MakeGroupName("Trees by Row", -1, -1, -1, -1, -1, -1);
			treesGroupLogicalByCol.totalCentiSeconds = centiseconds;
			channelGroup treesGroupPixOrder = new channelGroup();
			treesGroupPixOrder.name = MakeGroupName("Trees", -1, -1, -1, -1, -1, -1);
			treesGroupPixOrder.totalCentiSeconds = centiseconds;

			// Frontmost objects are the trees (this year) so start with them
			// Loop thru trees, 1-8
			for (int fixture = 0; fixture < 8; fixture++)
			{
				// NOTE: do not confuse the TREE (single) group with the TREES (plural) groups
				channelGroup treeGroupLogicalByCol = new channelGroup();
				treeGroupLogicalByCol.name = MakeGroupName("Cane " + (fixture + 1).ToString() + " by Column", -1, -1, -1, -1, -1, -1);
				treeGroupLogicalByCol.totalCentiSeconds = centiseconds;
				channelGroup treeGroupLogicalByRow = new channelGroup();
				treeGroupLogicalByRow.name = MakeGroupName("Tree " + (fixture + 1).ToString() + " by Row", -1, -1, -1, -1, -1, -1);
				treeGroupLogicalByRow.totalCentiSeconds = centiseconds;
				channelGroup treeGroupPixOrder = new channelGroup();
				treeGroupPixOrder.name = MakeGroupName("Tree", fixture, -1, -1, -1, -1, -1);
				treeGroupPixOrder.totalCentiSeconds = centiseconds;

				switch (fixture)
				{
					case 2:
						universe++;
						circuit = 1;
						break;
					case 4:
						universe++;
						circuit = 1;
						break;
					case 6:
						universe++;
						circuit = 1;
						break;

				}

				channelGroup colGroupLogical = new channelGroup();
				for (int col = 0; col < 10; col++)
				{
					channelGroup colGroupPixOrder = new channelGroup();
					int c2 = circuit + 41;
					if (c2 > 510) c2 -= 510;
					colGroupPixOrder.name = MakeGroupName("Tree", fixture, col, -1, universe, circuit, c2);
					colGroupPixOrder.totalCentiSeconds = centiseconds;

					colGroupLogical = new channelGroup();
					colGroupLogical.name = MakeGroupName("Tree", fixture, col, -1, universe, circuit, c2);
					colGroupLogical.totalCentiSeconds = centiseconds;
					for (int pos = 0; pos < 14; pos++) // Row
					{
						// Account for zig-zag
						int row = pos;
						if (col % 2 > 0)
						{
							row = 13 - pos;
						} // end zig-zap compensation
						
						// Create new RGB Channel Group for pixel
						rgbChannel rgbch = GeneratePixel("Tree", fixture, col, row);
						// Add it to the Column Group in Pixel Order
						colGroupPixOrder.AddItem(rgbch.savedIndex);
					} // end row loop
						// Add the Column Group (Pixel Order) to the Tree Group (Pixel Order)
					seq.AddChannelGroup(colGroupPixOrder);
					treeGroupPixOrder.AddItem(colGroupPixOrder.savedIndex);

					// Now copy the pixels in that column from the pixelorder group to the logical order group
					for (int pos = 0; pos < 14; pos++) // Row
					{
						// Account for zig-zag
						int row = pos;
						if (col % 2 == 0)
						{
							// for odd numbered rows, copy in reverse order
							row = 13 - pos;
							//seq.AddChannelGroup(colGroupPixOrder);
							colGroupLogical.AddItem(colGroupPixOrder.itemSavedIndexes[row]);
						}
						else
						{
							// for even numbered rows, copy in regular order
							//seq.AddChannelGroup(colGroupPixOrder);
							colGroupLogical.AddItem(colGroupPixOrder.itemSavedIndexes[pos]);
						} // end zig-zap compensation
					} // end second row loop (copy to logical order
					seq.AddChannelGroup(colGroupLogical);
					treeGroupLogicalByCol.AddItem(colGroupLogical.savedIndex);
				} // end col loop
					//Done with columns, save column groups to tree group
				seq.AddChannelGroup(treeGroupPixOrder);
				treesGroupPixOrder.AddItem(treeGroupPixOrder.savedIndex);
				seq.AddChannelGroup(treeGroupLogicalByCol);
				treesGroupLogicalByCol.AddItem(treeGroupLogicalByCol.savedIndex);

				// Now Pivot the table by 90°  --
				// Copy the pixels into ByRow groups
				for (int pos = 0; pos < 14; pos++)
				{
					int row = 13 - pos;
					channelGroup rowGroupLogical = new channelGroup();
					rowGroupLogical.name = MakeGroupName("Tree", fixture, -1, row, universe, circuit, circuit);
					rowGroupLogical.totalCentiSeconds = centiseconds;
					for (int col = 0; col < 10; col++)
					{
						//seq.AddChannelGroup(colGroupLogical);
						//rowGroupLogical.AddItem(colGroupLogical.itemSavedIndexes[col]);
						// Get savedIndex of group for this logical column
						int sig = treeGroupLogicalByCol.itemSavedIndexes[col];
						// Find it's object index from the savedIndex
						int oig = seq.savedIndexes[sig].objIndex;
						// Get the group from the sequence based on it's object index
						channelGroup cg = seq.channelGroups[oig];
						// Get the savedIndex of the RGBchannel for this row from the group
						int sic = cg.itemSavedIndexes[pos];
						// Add the savedIndex to the Logical Row Group
						rowGroupLogical.AddItem(sic);


					} // end column loop
					seq.AddChannelGroup(rowGroupLogical);
					treeGroupLogicalByRow.AddItem(rowGroupLogical.savedIndex);
				} // end row loop
					// Done pivoting, save row group to tree group
				seq.AddChannelGroup(treeGroupLogicalByRow);
				treesGroupLogicalByRow.AddItem(treeGroupLogicalByRow.savedIndex);
			} // end fixture loop

			// Done with all 8 fixtures/trees
			// add groups to tracks

			seq.AddChannelGroup(treesGroupLogicalByCol);
			treesGroupLogical.AddItem(treesGroupLogicalByCol.savedIndex);
			seq.AddChannelGroup(treesGroupLogicalByRow);
			treesGroupLogical.AddItem(treesGroupLogicalByRow.savedIndex);

			seq.AddChannelGroup(treesGroupLogical);
			track_logical.AddItem(treesGroupLogical.savedIndex);
			seq.AddChannelGroup(treesGroupPixOrder);
			track_pixorder.AddItem(treesGroupPixOrder.savedIndex);


		} // end GenerateTrees()

		void GenerateCanes()
		{
			universe = caneUniv1;
			circuit = 1;

			// Grouping prefered order of operations:
			//  1. create group
			//  2. fill group with items (channels, RGB channels, other groups)
			//  3. add the group to the sequence
			//  4. 

			// Groups to hold all 8 cane fixtures
			channelGroup canesGroupLogical = new channelGroup();
			canesGroupLogical.name = MakeGroupName("Candy Canes", -1, -1, -1, -1, -1, -1);
			canesGroupLogical.totalCentiSeconds = centiseconds;
			channelGroup canesGroupLogicalByCol = new channelGroup();
			canesGroupLogicalByCol.name = MakeGroupName("Candy Canes by Column", -1, -1, -1, -1, -1, -1);
			canesGroupLogicalByCol.totalCentiSeconds = centiseconds;
			channelGroup canesGroupLogicalByRow = new channelGroup();
			canesGroupLogicalByRow.name = MakeGroupName("Candy Canes by Row", -1, -1, -1, -1, -1, -1);
			canesGroupLogicalByRow.totalCentiSeconds = centiseconds;
			channelGroup canesGroupPixOrder = new channelGroup();
			canesGroupPixOrder.name = MakeGroupName("Candy Canes", -1, -1, -1, -1, -1, -1);
			canesGroupPixOrder.totalCentiSeconds = centiseconds;
			channelGroup CanesByStripeL = new channelGroup();
			CanesByStripeL.name = "Candy Canes by Diag Sripe L";
			CanesByStripeL.totalCentiSeconds = centiseconds;
			channelGroup CanesByStripeR = new channelGroup();
			CanesByStripeR.name = "Candy Canes by Diag Sripe R";
			CanesByStripeR.totalCentiSeconds = centiseconds;

			// Frontmost objects are the Canes (this year) so start with them
			// Loop thru Canes, 1-8
			for (int fixture = 0; fixture < 8; fixture++)
			{
				// NOTE: do not confuse the CANE (single) group with the CANES (plural) groups
				// groups to hold individual cane fixtures
				channelGroup caneGroupLogicalByCol = new channelGroup();
				caneGroupLogicalByCol.name = MakeGroupName("Cane " + (fixture + 1).ToString() + " by Column", -1, -1, -1, -1, -1, -1);
				caneGroupLogicalByCol.totalCentiSeconds = centiseconds;
				channelGroup caneGroupLogicalByRow = new channelGroup();
				caneGroupLogicalByRow.name = MakeGroupName("Cane " + (fixture + 1).ToString() + " by Row", -1, -1, -1, -1, -1, -1);
				caneGroupLogicalByRow.totalCentiSeconds = centiseconds;
				channelGroup caneGroupPixOrder = new channelGroup();
				caneGroupPixOrder.name = MakeGroupName("Cane", fixture, -1, -1, -1, -1, -1);
				caneGroupPixOrder.totalCentiSeconds = centiseconds;

				switch (fixture)
				{
					case 2:
						universe = caneUniv2;
						circuit = 1;
						break;
					case 4:
						universe = caneUniv3;
						circuit = 1;
						break;
					case 6:
						universe = caneUniv4;
						circuit = 1;
						break;

				}

				channelGroup colGroupLogical = new channelGroup();
				for (int col = 0; col < 3; col++)
				{
					channelGroup colGroupPixOrder = new channelGroup();
					int c2 = circuit + 98;
					if (c2 > 510) c2 -= 510;
					colGroupPixOrder.name = MakeGroupName("Cane", fixture, col, -1, universe, circuit, c2);
					colGroupPixOrder.totalCentiSeconds = centiseconds;

					colGroupLogical = new channelGroup();
					colGroupLogical.name = MakeGroupName("Cane", fixture, col, -1, universe, circuit, c2);
					colGroupLogical.totalCentiSeconds = centiseconds;
					for (int pos = 0; pos < 33; pos++) // Row
					{
						// Account for zig-zag
						int row = pos;
						if (col % 2 > 0)
						{
							row = 32 - pos;
						} // end zig-zap compensation
						// Create new RGB Channel Group for pixel
						rgbChannel rgbch = GeneratePixel("Cane", fixture, col, row);
						// Add it to the Column Group in Pixel Order
						colGroupPixOrder.AddItem(rgbch.savedIndex);
					} // end row loop
					// Add the Column Group (Pixel Order) to the Cane Group (Pixel Order)
					seq.AddChannelGroup(colGroupPixOrder);
					caneGroupPixOrder.AddItem(colGroupPixOrder.savedIndex);

					// Now copy the pixels in that column from the pixelorder group to the logical order group
					for (int pos = 0; pos < 33; pos++) // Row
					{
						// Account for zig-zag
						int row = pos;
						if (col % 2 == 0)
						{
							// for odd numbered rows, copy in reverse order
							row = 32 - pos;
							//seq.AddChannelGroup(colGroupPixOrder);
							colGroupLogical.AddItem(colGroupPixOrder.itemSavedIndexes[row]);
						}
						else
						{
							// for even numbered rows, copy in regular order
							//seq.AddChannelGroup(colGroupPixOrder);
							colGroupLogical.AddItem(colGroupPixOrder.itemSavedIndexes[pos]);
						} // end zig-zap compensation
					} // end second row loop (copy to logical order
					seq.AddChannelGroup(colGroupLogical);
					caneGroupLogicalByCol.AddItem(colGroupLogical.savedIndex);
				} // end col loop
					//Done with columns, save column groups to Cane group
				seq.AddChannelGroup(caneGroupPixOrder);
				canesGroupPixOrder.AddItem(caneGroupPixOrder.savedIndex);
				seq.AddChannelGroup(caneGroupLogicalByCol);
				canesGroupLogicalByCol.AddItem(caneGroupLogicalByCol.savedIndex);

				// Now Pivot the table by 90°  --
				// Copy the pixels into ByRow groups
				for (int pos = 0; pos < 33; pos++)
				{
					int row = 32 - pos;
					channelGroup rowGroupLogical = new channelGroup();
					rowGroupLogical.name = MakeGroupName("Cane", fixture, -1, row, universe, circuit, circuit);
					rowGroupLogical.totalCentiSeconds = centiseconds;
					for (int col = 0; col < 3; col++)
					{
						//seq.AddChannelGroup(colGroupLogical);
						// Get savedIndex of group for this logical column
						int hsig = caneGroupLogicalByCol.itemSavedIndexes[col];
						// Find it's object index from the savedIndex
						int hoig = seq.savedIndexes[hsig].objIndex;
						// Get the group from the sequence based on it's object index
						channelGroup hcg = seq.channelGroups[hoig];
						// Get the savedIndex of the RGBchannel for this row from the group
						int hsic = hcg.itemSavedIndexes[pos];
						// Add the savedIndex to the Logical Row Group
						rowGroupLogical.AddItem(hsic);


					} // end column loop
					seq.AddChannelGroup(rowGroupLogical);
					caneGroupLogicalByRow.AddItem(rowGroupLogical.savedIndex);
				} // end row loop
					// Done pivoting, save row group to Cane group
				seq.AddChannelGroup(caneGroupLogicalByRow);
				canesGroupLogicalByRow.AddItem(caneGroupLogicalByRow.savedIndex);

				
				
				// Now Diagonal Stripes!
				// First in one direction (L)...
				channelGroup caneGroupByStripe = new channelGroup();
				caneGroupByStripe.name = "Cane " + (fixture + 1).ToString() + " by stripe L";
				caneGroupByStripe.totalCentiSeconds = centiseconds;
				channelGroup stripeGroup = new channelGroup();

				int stripe = 35;
				// Last stripe comes first
				// Last stripe is just 1 pixel, in the lower righ corner of the hook
				// which would be the top right pixel if the candy cane was straight
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 35L";
				stripeGroup.totalCentiSeconds = centiseconds;
				// Get savedIndex of group for first (bottom) row
				int ssig = caneGroupLogicalByRow.itemSavedIndexes[0];
				// Find it's object index from the savedIndex
				int soig = seq.savedIndexes[ssig].objIndex;
				// Get the group from the sequence based on it's object index
				channelGroup scg = seq.channelGroups[soig];
				// Get the savedIndex of the first (left) RGBchannel for this row from the group
				int ssic = scg.itemSavedIndexes[2];
				// Add the savedIndex to the Logical Row Group
				stripeGroup.AddItem(ssic);
				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				// next stripe is just 2 pixels, in the lower middle of the hook
				// and the second pixel up on the left of the hook
				stripe--;
				stripeGroup = new channelGroup();
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 34L";
				stripeGroup.totalCentiSeconds = centiseconds;
				// Get savedIndex of group for first (bottom) row
				ssig = caneGroupLogicalByRow.itemSavedIndexes[0];
				// Find it's object index from the savedIndex
				soig = seq.savedIndexes[ssig].objIndex;
				// Get the group from the sequence based on it's object index
				scg = seq.channelGroups[soig];
				// Get the savedIndex of the first (left) RGBchannel for this row from the group
				ssic = scg.itemSavedIndexes[1];
				// Add the savedIndex to the Logical Row Group
				stripeGroup.AddItem(ssic);
				// Get savedIndex of group for next to bottom row
				ssig = caneGroupLogicalByRow.itemSavedIndexes[1];
				// Find it's object index from the savedIndex
				soig = seq.savedIndexes[ssig].objIndex;
				// Get the group from the sequence based on it's object index
				scg = seq.channelGroups[soig];
				// Get the savedIndex of the first (left) RGBchannel for this row from the group
				ssic = scg.itemSavedIndexes[2];
				// Add the savedIndex to the Logical Row Group
				stripeGroup.AddItem(ssic);
				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				// next 31 stripes are 3 pixels, diagonal, starting in hook and going to the base
				while (stripe > 3)
				{
					stripe--;
					stripeGroup = new channelGroup();
					stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe " + stripe.ToString() + "L";
					stripeGroup.totalCentiSeconds = centiseconds;

					ssig = caneGroupLogicalByRow.itemSavedIndexes[33 - stripe];
					soig = seq.savedIndexes[ssig].objIndex;
					scg = seq.channelGroups[soig];
					ssic = scg.itemSavedIndexes[0];
					stripeGroup.AddItem(ssic);

					ssig = caneGroupLogicalByRow.itemSavedIndexes[34 - stripe];
					soig = seq.savedIndexes[ssig].objIndex;
					scg = seq.channelGroups[soig];
					ssic = scg.itemSavedIndexes[1];
					stripeGroup.AddItem(ssic);

					ssig = caneGroupLogicalByRow.itemSavedIndexes[35 - stripe];
					soig = seq.savedIndexes[ssig].objIndex;
					scg = seq.channelGroups[soig];
					ssic = scg.itemSavedIndexes[2];
					stripeGroup.AddItem(ssic);

					seq.AddChannelGroup(stripeGroup);
					caneGroupByStripe.AddItem(stripeGroup.savedIndex);
				}

				// finally, next to last stripe (#2) is 2 pixels
				stripe--;
				stripeGroup = new channelGroup();
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 2L";
				stripeGroup.totalCentiSeconds = centiseconds;

				ssig = caneGroupLogicalByRow.itemSavedIndexes[31];
				soig = seq.savedIndexes[ssig].objIndex;
				scg = seq.channelGroups[soig];
				ssic = scg.itemSavedIndexes[0];
				stripeGroup.AddItem(ssic);

				ssig = caneGroupLogicalByRow.itemSavedIndexes[32];
				soig = seq.savedIndexes[ssig].objIndex;
				scg = seq.channelGroups[soig];
				ssic = scg.itemSavedIndexes[1];
				stripeGroup.AddItem(ssic);

				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				//Very last stripe is just 1 pixel
				stripe--;
				stripeGroup = new channelGroup();
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 1L";
				stripeGroup.totalCentiSeconds = centiseconds;

				ssig = caneGroupLogicalByRow.itemSavedIndexes[32];
				soig = seq.savedIndexes[ssig].objIndex;
				scg = seq.channelGroups[soig];
				ssic = scg.itemSavedIndexes[0];
				stripeGroup.AddItem(ssic);

				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				seq.AddChannelGroup(caneGroupByStripe);
				CanesByStripeL.AddItem(caneGroupByStripe.savedIndex);



				// Now Diagonal Stripes in the other direction (R)...
				caneGroupByStripe = new channelGroup();
				caneGroupByStripe.name = "Cane " + (fixture + 1).ToString() + " by stripe R";
				caneGroupByStripe.totalCentiSeconds = centiseconds;
				stripeGroup = new channelGroup();

				stripe = 35;
				// Last stripe is just 1 pixel, in the lower right corner of the hook
				// which would be the top right pixel if the candy cane was straight
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 35R";
				stripeGroup.totalCentiSeconds = centiseconds;
				// Get savedIndex of group for first (bottom) row
				ssig = caneGroupLogicalByRow.itemSavedIndexes[0];
				// Find it's object index from the savedIndex
				soig = seq.savedIndexes[ssig].objIndex;
				// Get the group from the sequence based on it's object index
				scg = seq.channelGroups[soig];
				// Get the savedIndex of the first (left) RGBchannel for this row from the group
				ssic = scg.itemSavedIndexes[0];
				// Add the savedIndex to the Logical Row Group
				stripeGroup.AddItem(ssic);
				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				// next stripe is just 2 pixels, in the lower middle of the hook
				// and the second pixel up on the right of the hook
				stripe--;
				stripeGroup = new channelGroup();
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 34R";
				stripeGroup.totalCentiSeconds = centiseconds;
				// Get savedIndex of group for first (bottom) row
				ssig = caneGroupLogicalByRow.itemSavedIndexes[0];
				// Find it's object index from the savedIndex
				soig = seq.savedIndexes[ssig].objIndex;
				// Get the group from the sequence based on it's object index
				scg = seq.channelGroups[soig];
				// Get the savedIndex of the first (left) RGBchannel for this row from the group
				ssic = scg.itemSavedIndexes[1];
				// Add the savedIndex to the Logical Row Group
				stripeGroup.AddItem(ssic);
				// Get savedIndex of group for next to bottom row
				ssig = caneGroupLogicalByRow.itemSavedIndexes[1];
				// Find it's object index from the savedIndex
				soig = seq.savedIndexes[ssig].objIndex;
				// Get the group from the sequence based on it's object index
				scg = seq.channelGroups[soig];
				// Get the savedIndex of the first (left) RGBchannel for this row from the group
				ssic = scg.itemSavedIndexes[0];
				// Add the savedIndex to the Logical Row Group
				stripeGroup.AddItem(ssic);
				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				// next 31 stripes are 3 pixels, diagonal, starting in hook and going to the base
				while (stripe > 3)
				{
					stripe--;
					stripeGroup = new channelGroup();
					stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe " + stripe.ToString() + "R";
					stripeGroup.totalCentiSeconds = centiseconds;

					ssig = caneGroupLogicalByRow.itemSavedIndexes[33 - stripe];
					soig = seq.savedIndexes[ssig].objIndex;
					scg = seq.channelGroups[soig];
					ssic = scg.itemSavedIndexes[2];
					stripeGroup.AddItem(ssic);

					ssig = caneGroupLogicalByRow.itemSavedIndexes[34 - stripe];
					soig = seq.savedIndexes[ssig].objIndex;
					scg = seq.channelGroups[soig];
					ssic = scg.itemSavedIndexes[1];
					stripeGroup.AddItem(ssic);

					ssig = caneGroupLogicalByRow.itemSavedIndexes[35 - stripe];
					soig = seq.savedIndexes[ssig].objIndex;
					scg = seq.channelGroups[soig];
					ssic = scg.itemSavedIndexes[0];
					stripeGroup.AddItem(ssic);

					seq.AddChannelGroup(stripeGroup);
					caneGroupByStripe.AddItem(stripeGroup.savedIndex);
				}

				// finally, next to last stripe (#2) is 2 pixels
				stripe--;
				stripeGroup = new channelGroup();
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 2R";
				stripeGroup.totalCentiSeconds = centiseconds;

				ssig = caneGroupLogicalByRow.itemSavedIndexes[31];
				soig = seq.savedIndexes[ssig].objIndex;
				scg = seq.channelGroups[soig];
				ssic = scg.itemSavedIndexes[2];
				stripeGroup.AddItem(ssic);

				ssig = caneGroupLogicalByRow.itemSavedIndexes[32];
				soig = seq.savedIndexes[ssig].objIndex;
				scg = seq.channelGroups[soig];
				ssic = scg.itemSavedIndexes[1];
				stripeGroup.AddItem(ssic);

				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				//Very last stripe is just 1 pixel
				stripe--;
				stripeGroup = new channelGroup();
				stripeGroup.name = "Cane " + (fixture + 1).ToString() + " stripe 1R";
				stripeGroup.totalCentiSeconds = centiseconds;

				ssig = caneGroupLogicalByRow.itemSavedIndexes[32];
				soig = seq.savedIndexes[ssig].objIndex;
				scg = seq.channelGroups[soig];
				ssic = scg.itemSavedIndexes[2];
				stripeGroup.AddItem(ssic);

				seq.AddChannelGroup(stripeGroup);
				caneGroupByStripe.AddItem(stripeGroup.savedIndex);

				seq.AddChannelGroup(caneGroupByStripe);
				CanesByStripeR.AddItem(caneGroupByStripe.savedIndex);



			} // end fixture loop

			// Done with all 8 fixtures/Canes
			// add groups to tracks

			seq.AddChannelGroup(canesGroupLogicalByCol);
			canesGroupLogical.AddItem(canesGroupLogicalByCol.savedIndex);
			seq.AddChannelGroup(canesGroupLogicalByRow);
			canesGroupLogical.AddItem(canesGroupLogicalByRow.savedIndex);
			seq.AddChannelGroup(CanesByStripeL);
			canesGroupLogical.AddItem(CanesByStripeL.savedIndex);
			seq.AddChannelGroup(CanesByStripeR);
			canesGroupLogical.AddItem(CanesByStripeR.savedIndex);

			seq.AddChannelGroup(canesGroupLogical);
			track_logical.AddItem(canesGroupLogical.savedIndex);
			seq.AddChannelGroup(canesGroupPixOrder);
			track_pixorder.AddItem(canesGroupPixOrder.savedIndex);


		} // end GenerateCanes()

		private void GenerateFlakes()
		{
			flakeMode = true;
			universe = flakeUniv1;
			circuit = 1;
			int totLED = 0;
			int armLED = 0;

			// All 6 flakes
			channelGroup flakesGroupLogicalByArm = new channelGroup();
			flakesGroupLogicalByArm.name = MakeGroupName("Snowflakes", -1, -1, -1, -1, -1, -1);
			flakesGroupLogicalByArm.totalCentiSeconds = centiseconds;
			channelGroup flakesGroupPixOrder = new channelGroup();
			flakesGroupPixOrder.name = MakeGroupName("Snowflakes", -1, -1, -1, -1, -1, -1);
			flakesGroupPixOrder.totalCentiSeconds = centiseconds;

			// Loop thru flakes 1-6
			// First small snowflake
			for (int fixture = 0; fixture < 6; fixture++)
			{
				// NOTE: do not confuse the TREE (single) group with the TREES (plural) groups
				// Individual Flakes
				channelGroup flakeGroupLogicalByArm = new channelGroup();
				flakeGroupLogicalByArm.name = MakeGroupName("Flake " + (fixture + 1).ToString() + " by Arm", -1, -1, -1, -1, -1, -1);
				flakeGroupLogicalByArm.totalCentiSeconds = centiseconds;
				channelGroup flakeGroupPixOrder = new channelGroup();
				flakeGroupPixOrder.name = MakeGroupName("Flake", fixture, -1, -1, -1, -1, -1);
				flakeGroupPixOrder.totalCentiSeconds = centiseconds;
				channelGroup tmpFlakeGroupPixels = new channelGroup();
				tmpFlakeGroupPixels.name = "TEMP all pixels in flake in pix order";


				int armSize = 14;
				if ((fixture == 1) || (fixture == 4))
				{
					armSize = 20;
				}
				if (fixture == 3)
				{
					universe = flakeUniv2;
					circuit = 1;
				}
				channelGroup armGroupLogical = new channelGroup();
				for (int arm = 0; arm < 5; arm++)
				{
					channelGroup armGroupPixOrder = new channelGroup();
					int c2 = circuit + armSize * 3 - 1;
					if (c2 > 510) c2 -= 510;
					armGroupPixOrder.name = MakeGroupName("Flake", fixture, arm, -1, universe, circuit, c2);
					armGroupPixOrder.totalCentiSeconds = centiseconds;

					//armGroupLogical = new channelGroup();
					//armGroupLogical.name = MakeGroupName("Flake", fixture, arm, -1, universe, circuit, c2);
					//armGroupLogical.totalCentiSeconds = centiseconds;
					for (int pos = 0; pos < armSize; pos++)
					{
						totLED++;
						// Account for zig-zag
						int led = pos;
						if (arm % 2 < 0)
						{
							led = (armSize-1) - pos;
						} // end zig-zap compensation

						// Create new RGB Channel Group for pixel
						rgbChannel rgbch = GeneratePixel("Flake", fixture, arm, led);
						// Add it to the Column Group in Pixel Order
						armGroupPixOrder.AddItem(rgbch.savedIndex);
						tmpFlakeGroupPixels.AddItem(rgbch.savedIndex);

					} // end led loop
					// Add the Column Group (Pixel Order) to the Tree Group (Pixel Order)
					seq.AddChannelGroup(armGroupPixOrder);
					flakeGroupPixOrder.AddItem(armGroupPixOrder.savedIndex);

					if (arm == 3)
					{
						if ((fixture == 0) || (fixture == 2) || (fixture == 3) || (fixture == 5))
						{
							// On Small Flakes Only,
							// After the 4th arm, before the 5th arm
							// add the center pixel in pixel order
							armGroupPixOrder = new channelGroup();
							armGroupPixOrder.name = "Flake " + (fixture + 1).ToString() + " Center Pixel";
							armGroupPixOrder.totalCentiSeconds = centiseconds;
							rgbChannel rgbch = GeneratePixel("Flake", fixture, -1, 56);
							armGroupPixOrder.AddItem(rgbch.savedIndex);
							tmpFlakeGroupPixels.AddItem(rgbch.savedIndex);
							seq.AddChannelGroup(armGroupPixOrder);
							flakeGroupPixOrder.AddItem(armGroupPixOrder.savedIndex);
						}
					}


					// Now copy the pixels in that column from the pixelorder group to the logical order group
					//for (int pos = 0; pos < armSize; pos++) // Row
					//{
						// Account for zig-zag
					//	int led = pos;
					//	if (arm % 2 < 0)
					//	{
							// for odd numbered rows, copy in reverse order
					//		led = (armSize-1) - pos;
							//seq.AddChannelGroup(colGroupPixOrder);
					//		armGroupLogical.AddItem(armGroupPixOrder.itemSavedIndexes[led]);
					//	}
					//	else
					//	{
							// for even numbered rows, copy in regular order
							//seq.AddChannelGroup(colGroupPixOrder);
					//		armGroupLogical.AddItem(armGroupPixOrder.itemSavedIndexes[pos]);
					//	} // end zig-zap compensation
					//} // end second row loop (copy to logical order
					//seq.AddChannelGroup(armGroupLogical);
					//flakeGroupLogicalByArm.AddItem(armGroupLogical.savedIndex);

				} // end arm loop
					//Done with columns, save column groups to tree group
				seq.AddChannelGroup(flakeGroupPixOrder);
				flakesGroupPixOrder.AddItem(flakeGroupPixOrder.savedIndex);

				if ((fixture == 1) || (fixture == 4))
				{
					flakeGroupLogicalByArm = GenerateLargeFlakeLogical(fixture + 1, tmpFlakeGroupPixels);
				}
				else
				{
					flakeGroupLogicalByArm = GenerateSmallFlakeLogical(fixture + 1, tmpFlakeGroupPixels);
				}
				seq.AddChannelGroup(flakeGroupLogicalByArm);
				flakesGroupLogicalByArm.AddItem(flakeGroupLogicalByArm.savedIndex);


			} // end fixture loop
				// Done with all 6 fixtures/flakes
				// add groups to tracks

			seq.AddChannelGroup(flakesGroupLogicalByArm);
			track_logical.AddItem(flakesGroupLogicalByArm.savedIndex);
			seq.AddChannelGroup(flakesGroupPixOrder);
			track_pixorder.AddItem(flakesGroupPixOrder.savedIndex);


			flakeMode = false;
		} // end GenerateFlakes

		private channelGroup GenerateSmallFlakeLogical(int flakeNum, channelGroup groupPixelOrder)
		{
			// Overall Flake
			channelGroup groupLogical = new channelGroup();
			groupLogical.name = "Flake " + flakeNum.ToString();
			groupLogical.totalCentiseconds = centiseconds;

			channelGroup groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Center Pixel";
			groupArm.totalCentiseconds = centiseconds;
			groupArm.AddItem(groupPixelOrder.itemSavedIndexes[56]);
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Arm 1
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 1";
			groupArm.totalCentiseconds = centiseconds;

			channelGroup groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 1 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[0]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[1]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[2]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[3]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[9]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[8]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 1 SubFlake
			channelGroup groupSubFlake = new channelGroup();
			//groupSubArm = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 1 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			channelGroup groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 1 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[3]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 1, 9, 8, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 2, 6, 7, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 3, 4, 5, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 4, 2, 1, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 5, 12, 13, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 6, 11, 10, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Repeat for Arm 2
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 2";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 2 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[27]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[26]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[25]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[24]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[19]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[18]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 2 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 2 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 2 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[24]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 1, 19, 18, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 2, 16, 17, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 3, 15, 14, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 4, 25, 26, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 5, 23, 22, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 6, 21, 20, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Repeat for Arm 3
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 3";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 3 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[28]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[29]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[30]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[31]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[37]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[36]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 3 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 3 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 3 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[31]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 1, 37, 36, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 2, 34, 35, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 3, 32, 33, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 4, 30, 29, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 5, 40, 41, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 6, 39, 38, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Arm 4
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 4";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 4 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[55]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[54]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[53]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[52]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[47]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[46]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 4 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 4 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 4 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[52]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 1, 47, 46, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 2, 44, 45, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 3, 43, 42, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 4, 53, 54, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 5, 51, 50, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 6, 49, 48, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Repeat for Arm 5
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 5";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 5 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[57]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[58]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[59]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[60]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[66]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[65]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 2 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 5 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 5 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[60]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 1, 66, 65, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 2, 63, 64, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 3, 61, 62, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 4, 59, 58, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 5, 70, 69, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 6, 68, 67, -1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			return groupLogical;
		} // end GenerateSmallFlakeLogical

		private channelGroup GenerateLargeFlakeLogical(int flakeNum, channelGroup groupPixelOrder)
		{
			// Overall Flake
			channelGroup groupLogical = new channelGroup();
			groupLogical.name = "Flake " + flakeNum.ToString();
			groupLogical.totalCentiseconds = centiseconds;

			// Arm 1
			channelGroup groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 1";
			groupArm.totalCentiseconds = centiseconds;

			channelGroup groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 1 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[0]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[1]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[2]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[3]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[4]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[13]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[12]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[11]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 1 SubFlake
			channelGroup groupSubFlake = new channelGroup();
			//groupSubArm = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 1 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			channelGroup groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 1 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[5]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 1, 13, 12, 11);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 2, 8, 9, 10);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 3, 5, 6, 7);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 4, 3, 2, 1);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 5, 17, 18, 19);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 1, 6, 16, 15, 14);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Repeat for Arm 2
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 2";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 2 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[39]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[38]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[37]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[36]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[35]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[28]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[27]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[26]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 2 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 2 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 2 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[35]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 1, 28, 27, 26);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 2, 23, 24, 25);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 3, 22, 21, 20);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 4, 36, 37, 38);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 5, 34, 33, 32);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 2, 6, 31, 30, 29);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Repeat for Arm 3
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 3";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 3 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[40]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[41]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[42]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[43]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[44]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[53]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[52]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[51]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 3 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 3 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 3 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[44]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 1, 53, 52, 51);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 2, 48, 49, 50);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 3, 45, 46, 47);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 4, 43, 42, 41);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 5, 57, 58, 59);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 3, 6, 56, 55, 54);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Arm 4
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 4";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 4 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[79]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[78]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[77]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[76]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[75]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[68]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[67]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[66]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 4 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 4 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 4 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[75]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 1, 68, 67, 66);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 2, 63, 64, 65);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 3, 62, 61, 60);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 4, 76, 77, 78);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 5, 74, 73, 72);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 4, 6, 71, 70, 69);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			// Repeat for Arm 5
			groupArm = new channelGroup();
			groupArm.name = "Flake " + flakeNum.ToString() + " Arm 5";
			groupArm.totalCentiseconds = centiseconds;

			groupSubArm = new channelGroup();
			groupSubArm.name = "Flake " + flakeNum.ToString() + " Arm 5 Main Ray";
			groupSubArm.totalCentiseconds = centiseconds;
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[80]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[81]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[82]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[83]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[84]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[93]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[92]);
			groupSubArm.AddItem(groupPixelOrder.itemSavedIndexes[91]);
			seq.AddChannelGroup(groupSubArm);
			groupArm.AddItem(groupSubArm.savedIndex);

			// Arm 2 SubFlake
			groupSubFlake = new channelGroup();
			groupSubFlake.name = "Flake " + flakeNum.ToString() + " Arm 5 Sub Flake";
			groupSubFlake.totalCentiseconds = centiseconds;

			groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm 5 SubFlake Center Pixel";
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[84]);
			seq.AddChannelGroup(groupSubFlakeArm);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 1, 93, 92, 91);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 2, 88, 89, 90);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 3, 85, 86, 87);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 4, 83, 82, 81);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 5, 99, 98, 97);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);
			groupSubFlakeArm = GenerateSubFlakeArm(groupPixelOrder, flakeNum, 5, 6, 96, 95, 94);
			groupSubFlake.AddItem(groupSubFlakeArm.savedIndex);

			// Add SubFlake to Arm
			seq.AddChannelGroup(groupSubFlake);
			groupArm.AddItem(groupSubFlake.savedIndex);
			// Add Arm to Flake
			seq.AddChannelGroup(groupArm);
			groupLogical.AddItem(groupArm.savedIndex);

			return groupLogical;
		} // end GenerateLargeFlakeLogical


		channelGroup GenerateSubFlakeArm(channelGroup groupPixelOrder, int flakeNum, int armNum, int subArmNum, int pix1, int pix2, int pix3)
		{
			channelGroup groupSubFlakeArm = new channelGroup();
			groupSubFlakeArm.name = "Flake " + flakeNum.ToString() + " Arm " + armNum.ToString() + " SubFlake Arm " + subArmNum.ToString();
			groupSubFlakeArm.totalCentiseconds = centiseconds;
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[pix1]);
			groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[pix2]);
			if (pix3 >= 0)
			{
				groupSubFlakeArm.AddItem(groupPixelOrder.itemSavedIndexes[pix3]);
			}
			seq.AddChannelGroup(groupSubFlakeArm);
			return groupSubFlakeArm;
		}



		private void GenerateStrips()
		{
			// Note: do not confuse outlines (plural) group which is whole house eaves + edges + windows
			// with outline group (singular) which is just one element
			channelGroup outlinesGroup = new channelGroup();
			outlinesGroup.name = "House Outline (Eave/Sides)";
			outlinesGroup.totalCentiSeconds = centiseconds;
			group_outlines_pixorder = new channelGroup();
			group_outlines_pixorder.name = "House Outline (Eave/Sides)";
			group_outlines_pixorder.totalCentiSeconds = centiseconds;

			// Eave and Edges
			universe = eaveUniv;
			circuit = 1;
			channelGroup topGroup = GenerateSingleStrip("Top Eave", eaveSize, edgeSize, true, false);
			universe = edgeUniv;
			circuit = 1;
			channelGroup rightGroup = GenerateSingleStrip("Right Edge", edgeSize, eaveSize, false, true);
			channelGroup leftGroup = GenerateSingleStrip("Left Edge", edgeSize, 1, true, true);
			channelGroup outlineGroup = new channelGroup();
			outlineGroup.name = "House Outline (Eave/Sides)";
			outlineGroup.totalCentiSeconds = centiseconds;
			outlineGroup.AddItem(topGroup.savedIndex);
			outlineGroup.AddItem(leftGroup.savedIndex);
			outlineGroup.AddItem(rightGroup.savedIndex);
			seq.AddChannelGroup(outlineGroup);
			outlinesGroup.AddItem(outlineGroup.savedIndex);

			// Left Window
			universe = leftWinUniv;
			circuit = 1;
			//                                    name                 size            coord         reverse vertical
			rightGroup = GenerateSingleStrip("Left Win Right Side", leftWinSideSize, leftWinTopSize, false, true);
			topGroup = GenerateSingleStrip("Left Win Top", leftWinTopSize, leftWinTopSize, true, false);
			leftGroup = GenerateSingleStrip("Left Win Left Side", leftWinSideSize, 1, true, true);
			channelGroup botGroup = GenerateSingleStrip("Left Win Bottom", leftWinTopSize, 1, false, false);
			outlineGroup = new channelGroup();
			outlineGroup.name = "Left Window";
			outlineGroup.totalCentiSeconds = centiseconds;
			outlineGroup.AddItem(leftGroup.savedIndex);
			outlineGroup.AddItem(rightGroup.savedIndex);
			outlineGroup.AddItem(topGroup.savedIndex);
			outlineGroup.AddItem(botGroup.savedIndex);
			seq.AddChannelGroup(outlineGroup);
			outlinesGroup.AddItem(outlineGroup.savedIndex);

			// Right Window
			universe = rightWinUniv;
			circuit = 1;
			rightGroup = GenerateSingleStrip("Right Win Right Side", rightWinSideSize, rightWinTopSize, false, true);
			topGroup = GenerateSingleStrip("Right Win Top", rightWinTopSize, rightWinSideSize, true, false);
			leftGroup = GenerateSingleStrip("Right Win Left Side", rightWinSideSize, 1, true, true);
			botGroup = GenerateSingleStrip("Right Win Bottom", rightWinTopSize, 1, false, false);
			outlineGroup = new channelGroup();
			outlineGroup.name = "Right Window";
			outlineGroup.totalCentiSeconds = centiseconds;
			outlineGroup.AddItem(leftGroup.savedIndex);
			outlineGroup.AddItem(rightGroup.savedIndex);
			outlineGroup.AddItem(topGroup.savedIndex);
			outlineGroup.AddItem(botGroup.savedIndex);
			seq.AddChannelGroup(outlineGroup);
			outlinesGroup.AddItem(outlineGroup.savedIndex);

			seq.AddChannelGroup(outlinesGroup);
			track_logical.AddItem(outlinesGroup.savedIndex);
			seq.AddChannelGroup(group_outlines_pixorder);
			track_pixorder.AddItem(group_outlines_pixorder.savedIndex);
		}

		private channelGroup GenerateSingleStrip(string stripName, int size, int coord, bool reverse, bool vertical)
		// House outline, including eaves, sides, and windows
		{

			channelGroup stripGroupLogical = new channelGroup();
			stripGroupLogical.name = MakeGroupName(stripName, -1, -1, -1, -1, -1, -1);
			stripGroupLogical.totalCentiSeconds = centiseconds;
			channelGroup stripGroupPixOrder = new channelGroup();
			stripGroupPixOrder.name = MakeGroupName(stripName, -1, -1, -1, -1, -1, -1);
			stripGroupPixOrder.totalCentiSeconds = centiseconds;
			coord--;
			int revNo = size - 1;

			for (int pix = 0; pix < size; pix++)
			{
				// Create new RGB Channel Group for pixel
				rgbChannel rgbch;
				int pos = 1;
				if (reverse)
				{
					pos = pix;
				}
				else
				{
					pos = revNo - pix;
				}

				if (vertical)
				{
					rgbch = GeneratePixel(stripName, -1, coord, pos);
				}
				else
				{
					rgbch = GeneratePixel(stripName, -1, pos, coord);
				}
				// Add it to the Column Group in Pixel Order
				stripGroupPixOrder.AddItem(rgbch.savedIndex);

			} // end pix loop

			// Now copy the pixels in that column from the pixelorder group to the logical order group
			//if ((reverse) && (!vertical))
			if (reverse == vertical)
			{
				for (int pos = 0; pos < size; pos++)
				{
					stripGroupLogical.AddItem(stripGroupPixOrder.itemSavedIndexes[revNo - pos]);
				}
			}
			else
			{
				for (int pos = 0; pos < size; pos++)
				{
					stripGroupLogical.AddItem(stripGroupPixOrder.itemSavedIndexes[pos]);
				}
			}

			//Done with columns, save column groups to tree group
				// add groups to tracks

			seq.AddChannelGroup(stripGroupLogical);
			seq.AddChannelGroup(stripGroupPixOrder);
			//track_pixorder.AddItem(stripGroupPixOrder.savedIndex);
			group_outlines_pixorder.AddItem(stripGroupPixOrder.savedIndex);

			return stripGroupLogical;

		} // end GenerateStrips

		private rgbChannel GeneratePixel(string pixName, int fixture, int col, int row)
		{
			pnlName.Text = pixName;
			pnlFixture.Text = fixture.ToString();
			pnlCol.Text = col.ToString();
			pnlRow.Text = row.ToString();
			pnlUniverse.Text = universe.ToString();
			pnlChannel.Text = circuit.ToString();
			staInfo.Refresh();

			pixelCount++;
			prgStatus.Value = pixelCount;
			lblCount.Text = pixelCount.ToString();
			prgStatus.Refresh();
			lblCount.Refresh();
			
			// Create new RGB Channel Group for pixel
			rgbChannel rgbch = new rgbChannel();
			rgbch.name = MakeGroupName(pixName, fixture, col, row, universe, circuit, circuit + 2);
			rgbch.totalCentiseconds = centiseconds;

			// Create the Red Channel element
			channel rch = new channel();
			rch.name = MakeChannelName(pixName, "(R)", fixture, col, row, universe, circuit);
			rch.centiseconds = centiseconds;
			rch.color = 255;
			rch.deviceType = deviceType.DMX;
			rch.network = universe;
			rch.circuit = circuit;
			// Increment DMX channel #
			circuit++;
			// Add Red Channel to the Sequence and to the RGB Channel Group
			seq.AddChannel(rch);
			rgbch.redSavedIndex = rch.savedIndex;
			rgbch.redChannelIndex = seq.channelCount - 1;

			// Create the Green Channel element
			channel gch = new channel();
			gch.name = MakeChannelName(pixName, "(G)", fixture, col, row, universe, circuit);
			gch.centiseconds = centiseconds;
			gch.color = 65280;
			gch.deviceType = deviceType.DMX;
			gch.network = universe;
			gch.circuit = circuit;
			circuit++;
			// Add the Green Channel to the Sequence and to the RGB Channel Group
			seq.AddChannel(gch);
			rgbch.grnSavedIndex = gch.savedIndex;
			rgbch.grnChannelIndex = seq.channelCount - 1;

			// Now, one more time for the Blue Channel element
			channel bch = new channel();
			bch.name = MakeChannelName(pixName, "(B)", fixture, col, row, universe, circuit);
			bch.centiseconds = centiseconds;
			bch.color = 16711680;
			bch.deviceType = deviceType.DMX;
			bch.network = universe;
			bch.circuit = circuit;
			circuit++;

			seq.AddChannel(bch);
			rgbch.bluSavedIndex = gch.savedIndex;
			rgbch.bluChannelIndex = seq.channelCount - 1;

			// Add the RGB Channel Group to the Sequence
			seq.AddRGBChannel(rgbch);

			// Wrap around - 2 or more universes per output
			// first fixture per output uses only a portion of the available channels
			// the next fixture uses remainder of channels on that universe, then starts another
			if (circuit == 511)
			{
				universe++;
				circuit = 1;
			}

			return rgbch;
		} // end Generate Pixel


		private string MakeChannelName(string gadgetName, string color, int fixture, int col, int row, int universe, int channel)
		{
			// Richard: Feel free to tweak this naming convention to your own desires
			string ret = gadgetName + " ";
			if (fixture >= 0)
			{
				ret += (fixture + 1).ToString();
			}

			if (flakeMode)
			{
				ret += " arm " + (col + 1).ToString();
				ret += " led " + (row + 1).ToString();
			}
			else
			{
				ret += " col " + (col + 1).ToString();
				ret += " row " + (row + 1).ToString();
			}
			if (color.Length > 0)
			{
				ret += " " + color;
			}
			ret += " [";
			if (fixture >= 0)
			{
				ret += (fixture + 1).ToString() + ",";
			}
			ret += (col + 1).ToString();
			ret += "," + (row + 1).ToString() + "]";
			ret += " {U" + universe.ToString();
			ret += "." + channel.ToString() + "}";
			return ret;
		} // end MakeChannelName()

		private string MakeGroupName(string gadgetName, int fixture, int col, int row, int universe, int startChannel, int endChannel)
		{
			// Richard: Feel free to tweak this naming convention to your own desires
			string ret = gadgetName;
			if (fixture > -1)
			{
				ret += " " + (fixture + 1).ToString();
			}
			if (col > -1)
			{
				if (flakeMode)
				{
					ret += " arm " + (col + 1).ToString();
				}
				else
				{
					ret += " col " + (col + 1).ToString();
				}
			}
			if (row > -1)
			{
				if (flakeMode)
				{
					ret += " pix " + (row + 1).ToString();
				}
				else
				{
					ret += " row " + (row + 1).ToString();
				}
			}
			if ((col>-1) && (row>-1))
			{
				ret += " [";
				if (fixture > -1)
				{
					ret += (fixture + 1).ToString() + ",";
				}
				if (col>-1)
				{
					ret += (col + 1).ToString() + ",";
				}
				else
				{
					ret += "x,";
				}
				if (row > -1)
				{
					ret += (row + 1).ToString() + "]";
				}
				else
				{
					ret += "x]";
				}
			}

			if (endChannel > startChannel)
			{
				ret += " {U" + universe.ToString();
				ret += "." + startChannel.ToString();
				ret +="-" + endChannel.ToString() + "}";
			}
			return ret;
		} // end MakeGroupName()

		string getSequenceFolder()
		{
			const string keyName = "HKEY_CURRENT_USER\\SOFTWARE\\Light-O-Rama\\Shared";
			string userDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
			string fldr = (string)Registry.GetValue(keyName, "NonAudioPath", userDocs);
			return fldr;
		} // End getSequenceFolder

	} // end frmGenerator Class
} // end Namespace
