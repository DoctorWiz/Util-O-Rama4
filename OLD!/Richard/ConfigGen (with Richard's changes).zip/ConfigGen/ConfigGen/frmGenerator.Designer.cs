﻿namespace ConfigGen
{
	partial class frmGen
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGen));
			this.btnOK = new System.Windows.Forms.Button();
			this.staInfo = new System.Windows.Forms.StatusStrip();
			this.pnlName = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlFixture = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlCol = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlRow = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlUniverse = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlChannel = new System.Windows.Forms.ToolStripStatusLabel();
			this.prgStatus = new System.Windows.Forms.ProgressBar();
			this.lblCount = new System.Windows.Forms.Label();
			this.staInfo.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnOK.Location = new System.Drawing.Point(81, 91);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(119, 56);
			this.btnOK.TabIndex = 0;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			// 
			// staInfo
			// 
			this.staInfo.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pnlName,
            this.pnlFixture,
            this.pnlCol,
            this.pnlRow,
            this.pnlUniverse,
            this.pnlChannel});
			this.staInfo.Location = new System.Drawing.Point(0, 239);
			this.staInfo.Name = "staInfo";
			this.staInfo.Size = new System.Drawing.Size(284, 22);
			this.staInfo.TabIndex = 1;
			// 
			// pnlName
			// 
			this.pnlName.AutoSize = false;
			this.pnlName.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlName.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlName.Name = "pnlName";
			this.pnlName.Size = new System.Drawing.Size(120, 17);
			// 
			// pnlFixture
			// 
			this.pnlFixture.AutoSize = false;
			this.pnlFixture.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlFixture.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlFixture.Name = "pnlFixture";
			this.pnlFixture.Size = new System.Drawing.Size(20, 17);
			// 
			// pnlCol
			// 
			this.pnlCol.AutoSize = false;
			this.pnlCol.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlCol.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlCol.Name = "pnlCol";
			this.pnlCol.Size = new System.Drawing.Size(30, 17);
			// 
			// pnlRow
			// 
			this.pnlRow.AutoSize = false;
			this.pnlRow.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlRow.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlRow.Name = "pnlRow";
			this.pnlRow.Size = new System.Drawing.Size(30, 17);
			// 
			// pnlUniverse
			// 
			this.pnlUniverse.AutoSize = false;
			this.pnlUniverse.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlUniverse.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlUniverse.Name = "pnlUniverse";
			this.pnlUniverse.Size = new System.Drawing.Size(30, 17);
			// 
			// pnlChannel
			// 
			this.pnlChannel.AutoSize = false;
			this.pnlChannel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlChannel.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlChannel.Name = "pnlChannel";
			this.pnlChannel.Size = new System.Drawing.Size(30, 17);
			// 
			// prgStatus
			// 
			this.prgStatus.Location = new System.Drawing.Point(0, 193);
			this.prgStatus.Maximum = 3777;
			this.prgStatus.Name = "prgStatus";
			this.prgStatus.Size = new System.Drawing.Size(310, 23);
			this.prgStatus.TabIndex = 2;
			this.prgStatus.Visible = false;
			// 
			// lblCount
			// 
			this.lblCount.AutoSize = true;
			this.lblCount.Location = new System.Drawing.Point(132, 198);
			this.lblCount.Name = "lblCount";
			this.lblCount.Size = new System.Drawing.Size(13, 13);
			this.lblCount.TabIndex = 3;
			this.lblCount.Text = "0";
			this.lblCount.Visible = false;
			// 
			// frmGen
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(284, 261);
			this.Controls.Add(this.lblCount);
			this.Controls.Add(this.staInfo);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.prgStatus);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "frmGen";
			this.Text = "Configuration Generator";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmGen_FormClosing);
			this.Load += new System.EventHandler(this.frmGen_Load);
			this.staInfo.ResumeLayout(false);
			this.staInfo.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.StatusStrip staInfo;
		private System.Windows.Forms.ToolStripStatusLabel pnlName;
		private System.Windows.Forms.ToolStripStatusLabel pnlFixture;
		private System.Windows.Forms.ToolStripStatusLabel pnlCol;
		private System.Windows.Forms.ToolStripStatusLabel pnlRow;
		private System.Windows.Forms.ToolStripStatusLabel pnlUniverse;
		private System.Windows.Forms.ToolStripStatusLabel pnlChannel;
		private System.Windows.Forms.ProgressBar prgStatus;
		private System.Windows.Forms.Label lblCount;
	}
}

