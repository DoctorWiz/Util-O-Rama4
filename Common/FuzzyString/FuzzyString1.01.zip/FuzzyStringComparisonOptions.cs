﻿namespace FuzzyString
{
	/*
	public enum FuzzyRankOptions
	{
		UseJaccardDistance								= 0x0001,
		UseJaccardIndex										= 0x0002,
		UseJaroDistance										= 0x0004,
		UseJaroWinklerDistance						= 0x0008,
		UseLevenshteinDistance						= 0x0010,
		UseLongestCommonSubsequence				= 0x0020,
		UseLongestCommonSubstring					= 0x0040,
		UseNormalizedLevenshteinDistance	= 0x0080,
		UseRatcliffObershelpSimilarity		= 0x0100,
		UseSorensenDiceDistance						= 0x0200,
		UseSorensonDiceIndex							= 0x0400,
		UseTanimotoCoefficient						= 0x0800,
		UseOverlapCoefficient							= 0x1000,
		UseAllDistances										= 0x1BE9, // Jaccard + Jaro-Winkler + Normalized Levenshtein + Longest Subsequence + Longest Substring + Sorensen-Dice + Tanimoto + Overlap
		CaseInsensitive										= 0x8000
	}
	*/
}