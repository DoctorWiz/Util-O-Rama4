﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FuzzyString
{

	public static partial class FuzzyFunctions
	{
		public const int USE_CASEINSENSITIVE = 0X8000;

		public const int USE_LEVENSHTEIN = 0X0001;
		public const int USE_NORMALIZEDLEVENSHTEIN    = 0X0002;
		public const int USE_DAMERAULEVENSHTEIN       = 0X0004;
		public const int USE_HAMMING                  = 0X0008;
		public const int USE_JACCARDINDEX             = 0X0010;
		public const int USE_JARO                     = 0X0020;
		public const int USE_JAROWINKLER              = 0X0040;
		public const int USE_LONGESTCOMMONSUBSEQUENCE = 0X0080;
		public const int USE_LONGESTCOMMONSUBSTRING   = 0X0100;
		public const int USE_OVERLAPCOEFFICIENT       = 0X0200;
		public const int USE_RATCLIFFOBERSHELP        = 0X0400;
		public const int USE_SORENSENDICE             = 0X0800;
		public const int USE_TANIMOTOCOEFFICIENT      = 0X1000;


		//public const int USE_JACCARDDISTANCE = 0X0001;
		//public const int USE_SORENSENDICEDISTANCE = 0X0200;
		//public const int USE_RESERVED1 = 0X2000;
		//public const int USE_RESERVED2 = 0X4000;
		public const int USE_ALLDISTANCES = USE_LEVENSHTEIN |
																				USE_NORMALIZEDLEVENSHTEIN |
																				USE_DAMERAULEVENSHTEIN |
																				USE_HAMMING |
																				USE_JACCARDINDEX |
																				USE_JARO |
																				USE_JAROWINKLER |
																				USE_LONGESTCOMMONSUBSEQUENCE |
																				USE_LONGESTCOMMONSUBSTRING |
																				USE_OVERLAPCOEFFICIENT |
																				USE_RATCLIFFOBERSHELP |
																				USE_SORENSENDICE |
																				USE_TANIMOTOCOEFFICIENT;

		public static string AlgorithmNames(int algorithms)
		{
			string ret = "";

			if ((algorithms & USE_LEVENSHTEIN )== USE_LEVENSHTEIN)
			{
				ret += "Levenshtein Distance, ";
			}
			if ((algorithms & USE_NORMALIZEDLEVENSHTEIN )== USE_NORMALIZEDLEVENSHTEIN)
			{
				ret += "Normalized Levenshtein, ";
			}
			if ((algorithms & USE_DAMERAULEVENSHTEIN )== USE_DAMERAULEVENSHTEIN)
			{
				ret += "Damerau-Levenshtein, ";
			}
			//if ((algorithms & USE_YETILEVENSHTEIN )== USE_YETILEVENSHTEIN)
			//{
			//	ret += "Yeti-Levenshtein, ";
			//}
			if ((algorithms & USE_HAMMING )== USE_HAMMING)
			{
				ret += "Hamming Distance, ";
			}
			if ((algorithms & USE_JACCARDINDEX )== USE_JACCARDINDEX)
			{
				ret += "Jaccard Index, ";
			}
			if ((algorithms & USE_JARO )== USE_JARO)
			{
				ret += "Jaro Distance, ";
			}
			if ((algorithms & USE_JAROWINKLER )== USE_JAROWINKLER)
			{
				ret += "Jaro-Winkler, ";
			}
			if ((algorithms & USE_LONGESTCOMMONSUBSEQUENCE )== USE_LONGESTCOMMONSUBSEQUENCE)
			{
				ret += "Longest Common Subsequence, ";
			}
			if ((algorithms & USE_LONGESTCOMMONSUBSTRING )== USE_LONGESTCOMMONSUBSTRING)
			{
				ret += "Longest Common Substring, ";
			}
			if ((algorithms & USE_OVERLAPCOEFFICIENT )== USE_OVERLAPCOEFFICIENT)
			{
				ret += "Overlap Coefficient, ";
			}
			if ((algorithms & USE_RATCLIFFOBERSHELP )== USE_RATCLIFFOBERSHELP)
			{
				ret += "Ratcliff-Obershelp, ";
			}
			if ((algorithms & USE_SORENSENDICE )== USE_SORENSENDICE)
			{
				ret += "Sorensen-Dice, ";
			}
			if ((algorithms & USE_TANIMOTOCOEFFICIENT )== USE_TANIMOTOCOEFFICIENT)
			{
				ret += "Tanimoto Coefficent, ";
			}
			if ((algorithms & USE_TANIMOTOCOEFFICIENT) == USE_CASEINSENSITIVE)
			{
				ret += "and Case Insensitive, ";
			}

			if (ret.Length > 5)
			{
				ret = ret.Substring(0, ret.Length - 2);
			}




			return ret;
		}



		public static double RankEquality(this string source, string target)
		{
			return source.RankEquality(target, USE_ALLDISTANCES);
		}

		public static double RankEquality(this string source, string target, long FuzzyStringComparisonOptions)
		{
			int methodCount = 0;
			double runningTotal = 0;
			double ret = 0;
			List<double> comparisonResults = new List<double>();

			if ((FuzzyStringComparisonOptions & USE_CASEINSENSITIVE) > 0)
			{
				source = source.Capitalize();
				target = target.Capitalize();
			}

			if ((FuzzyStringComparisonOptions & USE_LEVENSHTEIN) > 0)
			{
				double li = source.LevenshteinIndex(target);
				runningTotal += li;
				methodCount++;
				//comparisonResults.Add(Convert.ToDouble(source.NormalizedLevenshteinDistance(target)) / Convert.ToDouble((Math.Max(source.Length, target.Length) - source.LevenshteinDistanceLowerBounds(target))));
			}
			if ((FuzzyStringComparisonOptions & USE_NORMALIZEDLEVENSHTEIN) > 0)
			{
				double nli = source.NormalizedLevenshteinIndex(target);
				runningTotal += nli;
				methodCount++;
				//comparisonResults.Add(Convert.ToDouble(source.NormalizedLevenshteinDistance(target)) / Convert.ToDouble((Math.Max(source.Length, target.Length) - source.LevenshteinDistanceLowerBounds(target))));
			}
			if ((FuzzyStringComparisonOptions & USE_DAMERAULEVENSHTEIN) > 0)
			{
				//int thr = (source.Length + target.Length) / 6;
				double dli = source.DamerauLevenshteinIndex(target);
				runningTotal += dli;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_JACCARDINDEX) > 0)
			{
				double ji = source.JaccardIndex(target);
				runningTotal += ji;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_JARO) > 0)
			{
				double ji = source.JaroSimilarity(target);
				runningTotal += ji;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_JAROWINKLER) > 0)
			{
				double jw = source.JaroWinklerSimilarity(target);
				runningTotal += jw;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_LONGESTCOMMONSUBSEQUENCE) > 0)
			{
				double lcs = source.LongestCommonSubsequenceIndex(target);
				runningTotal += lcs;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_LONGESTCOMMONSUBSTRING) > 0)
			{
				double lcs = source.LongestCommonSubstringIndex(target);
				runningTotal += lcs;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_OVERLAPCOEFFICIENT) > 0)
			{
				double oc = source.OverlapCoefficient(target);
				runningTotal += oc;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_RATCLIFFOBERSHELP) > 0)
			{
				double ro = source.RatcliffObershelpSimilarity(target);
				runningTotal += ro;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_SORENSENDICE) > 0)
			{
				double sdi = source.SorensenDiceIndex(target);
				runningTotal += sdi;
				methodCount++;
			}
			if ((FuzzyStringComparisonOptions & USE_TANIMOTOCOEFFICIENT) > 0)
			{
				double tc = source.TanimotoCoefficient(target);
				runningTotal += tc;
				methodCount++;
			}

			if (methodCount > 0)
			{
				ret = runningTotal / methodCount;
			}

			return ret;
		}

		public static double SimilarityFromDistance(this double distanceScore, int sourceLength, int targetLength)
		{
			double ret = 0;
			int mn = Math.Min(sourceLength, targetLength);
			if (distanceScore <= 0)
			{
				ret = 1;
			}
			else
			{
				if (mn > 0)
				{
					if (distanceScore < mn)
					{
						ret = 1 - (distanceScore / mn);
					}
				}
			}
			return ret;
		} // end Fuzzy Index Distance
	} // end partial class FuzzyFunctions
} //end namespace FuzzyString
