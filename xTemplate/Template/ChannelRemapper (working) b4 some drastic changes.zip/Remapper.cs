﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using LORUtils;

namespace ChannelRemapper
{
	public partial class frmRemapper : Form
	{
		int[] chMapTo;
		int[][] chsMapTo;
		int[] chsUnused;
		Sequence oldSeq = new Sequence();
		Sequence newSeq = new Sequence();
		string oldFile;
		string newFile;
		string basePath;
		string masterFile;
		TreeNode activeOldChannel;
		TreeNode activeNewChannel;
		int activeList = 0;
		private const int LIST_OLD = 1;
		private const int LIST_NEW = 2;
		public string statMsg = "Hello World!";

		private const char DELIM_Map = (char)164;  // ¤
		private const char DELIM_SID = (char)177;  // ±
		private const char DELIM_Name = (char)167;  // §
		private const char DELIM4 = (char)182;  // ¶

		private const string MSG_MapRegularToRegular = "Regular channels can only be mapped to other regular channels.";
		private const string MSG_MapRGBtoRGB	 = "RGB channels can only be mapped to other RGB channels.";
		private const string MSG_GroupToGroup	 = "Groups can only be mapped to other groups, and only if they have the same number of regular channels and RGB channels in the same order.";
		private const string MSG_GroupMatch = "Groups can only be mapped to other groups if they have the same number of regular channels, RGB channels, and subgroups in the same order.";
		private const string MSG_Tracks = "Tracks can not be mapped.";
		private const string MSG_OnlyOneOldToNew = "The selected new channel already has an old channel mapped to it.";
		private const string MSG_OnlyOneGroupToNew = "The selected new group already has an old group mapped to it.";

		
		private class ChanInfo
		{
			public tableType chType = tableType.None;
			public int chIndex = 0;
			public int savedIndex = 0;
			public int mapCount = 0;
			public int[] mapChIndexes;
			public int[] mapSavedIndexes;
		}
		

		public frmRemapper()
		{
			InitializeComponent();
		}

		private void btnBrowseOld_Click(object sender, EventArgs e)
		{


			dlgOpenFile.Filter = "Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lms";
			dlgOpenFile.InitialDirectory = basePath;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			DialogResult result = dlgOpenFile.ShowDialog();

			pnlAll.Enabled = false;
			if (result == DialogResult.OK)
			{
				oldFile = dlgOpenFile.FileName;
				//if (oldFile.Substring(1, 2) != ":\\")
				//{
				//	oldFile = basePath + "\\" + oldFile;
				//}

				FileInfo fi = new FileInfo(oldFile);
				Properties.Settings.Default.BasePath = fi.DirectoryName;
				Properties.Settings.Default.Save();

				//if (oldFile.Length > basePath.Length)
				//{
				//	if (oldFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
				//	{
				//		txtOldFile.Text = oldFile.Substring(basePath.Length);
				//		oldSeq.readFile(oldFile);
				//		FillOldChannels();
				//	}
				//	else
				//	{
						//txtOldFile.Text = oldFile;
						txtOldFile.Text = ShortenLongPath(oldFile, 80);
						oldSeq.readFile(oldFile);
						FillChannels(treOldChannels, oldSeq);
				//	} // End else (oldFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
				//} // end if (oldFile.Length > basePath.Length)
			} // end if (result = DialogResult.OK)
			pnlAll.Enabled = true;
			if (treNewChannels.Nodes.Count > 0)
			{
				btnSummary.Enabled = true;
			}

		}

		private void frmRemapper_Load(object sender, EventArgs e)
		{
		}

		private void FillChannels(TreeView tree, Sequence seq)
		{
			treOldChannels.Nodes.Clear();
			//ChanInfo tagInfo = new ChanInfo();
			string nodeText = "";
			string nodeTag = "";

			for (int t = 0; t < seq.trackCount; t++)
			{
				int tNo = t + 1;
				nodeText = "Track " + tNo.ToString() + ":" + seq.tracks[t].name;
				TreeNode trackNode = tree.Nodes.Add(nodeText);
				nodeTag = "t" + t.ToString() + "|0";
				trackNode.Tag = nodeTag;

				trackNode.ImageIndex = 0;
				trackNode.SelectedImageIndex = 0;

				for (int ti = 0; ti < seq.trackItemCount; ti++)
				{
					if (seq.trackItems[ti].trackIndex == t)
					{
						int si = seq.trackItems[ti].savedIndex;
						if (seq.savedIndexes[si].objType == tableType.channelGroupList)
						{
							TreeNode groupNode = AddGroup(seq, trackNode, seq.savedIndexes[si].objIndex);
						}
						if (seq.savedIndexes[si].objType == tableType.channel)
						{
							TreeNode groupNode = AddChannel(seq, trackNode, seq.savedIndexes[si].objIndex);
						}
						if (seq.savedIndexes[si].objType == tableType.rgbChannel)
						{
							TreeNode groupNode = AddRGBchannel(seq, trackNode, seq.savedIndexes[si].objIndex);
						}
					}

				}


			}

		} // end fillOldChannels

		private TreeNode AddGroup(Sequence seq, TreeNode parentNode, int groupIndex)
		{
			string nodeText = seq.channelGroups[groupIndex].name;
			TreeNode groupNode = parentNode.Nodes.Add(nodeText);
			string nodeTag = "g" + groupIndex.ToString() + DELIM_SID + seq.channelGroups[groupIndex].savedIndex.ToString();
			groupNode.Tag = nodeTag;
			groupNode.ImageIndex = 1;
			groupNode.SelectedImageIndex = 1;

			for (int gi = 0; gi < seq.groupItemCount; gi++)
			{
				if (seq.channelGroupItems[gi].channelGroupListIndex == groupIndex)
				{
					int si = seq.channelGroupItems[gi].channelGroupSavedIndex;
					if (seq.savedIndexes[si].objType == tableType.channelGroupList)
					{
						TreeNode subGroupNode = AddGroup(seq, groupNode, seq.savedIndexes[si].objIndex);
					}
					if (seq.savedIndexes[si].objType == tableType.channel)
					{
						TreeNode channelNode = AddChannel(seq, groupNode, seq.savedIndexes[si].objIndex);
					}
					if (seq.savedIndexes[si].objType == tableType.rgbChannel)
					{
						TreeNode RGBchannelNode = AddRGBchannel(seq, groupNode, seq.savedIndexes[si].objIndex);
					}
				}

			}


			return groupNode;
		}

		private TreeNode AddChannel(Sequence seq, TreeNode parentNode, int channelIndex)
		{
			string nodeText = seq.channels[channelIndex].name;
			TreeNode channelNode = parentNode.Nodes.Add(nodeText);
			string nodeTag = "c" + channelIndex.ToString() + DELIM_SID + seq.channels[channelIndex].savedIndex.ToString();
			channelNode.Tag = nodeTag;
			channelNode.ImageIndex = 3;
			channelNode.SelectedImageIndex = 3;

			return channelNode;
		}

		private TreeNode AddRGBchannel(Sequence seq, TreeNode parentNode, int RGBIndex)
		{
			string nodeText = seq.rgbChannels[RGBIndex].name;
			TreeNode channelNode = parentNode.Nodes.Add(nodeText);
			string nodeTag = "r" + RGBIndex.ToString() + DELIM_SID + seq.rgbChannels[RGBIndex].savedIndex.ToString();
			channelNode.Tag = "r" + RGBIndex.ToString();
			channelNode.ImageIndex = 2;
			channelNode.SelectedImageIndex = 2;

			int ci = seq.rgbChannels[RGBIndex].redChannelIndex;
			nodeText = seq.channels[ci].name;
			TreeNode colorNode = channelNode.Nodes.Add(nodeText);
			nodeTag = "c" + ci.ToString() + DELIM_SID + seq.channels[ci].savedIndex.ToString();
			colorNode.Tag = nodeTag;
			colorNode.ImageIndex = 4;
			colorNode.SelectedImageIndex = 4;

			ci = seq.rgbChannels[RGBIndex].grnChannelIndex;
			nodeText = seq.channels[ci].name;
			colorNode = channelNode.Nodes.Add(nodeText);
			nodeTag = "c" + ci.ToString() + DELIM_SID + seq.channels[ci].savedIndex.ToString();
			colorNode.Tag = nodeTag;
			colorNode.ImageIndex = 5;
			colorNode.SelectedImageIndex = 5;

			ci = seq.rgbChannels[RGBIndex].bluChannelIndex;
			nodeText = seq.channels[ci].name;
			colorNode = channelNode.Nodes.Add(nodeText);
			nodeTag = "c" + ci.ToString() + DELIM_SID + seq.channels[ci].savedIndex.ToString();
			colorNode.Tag = nodeTag;
			colorNode.ImageIndex = 6;
			colorNode.SelectedImageIndex = 6;


			return channelNode;
		}


		private string ShortenLongPath(string longPath, int maxLen)
		{
			string shortPath = longPath;
			// Can't realistically shorten a path and filename to much less than 18 characters, reliably
			if (maxLen > 18)
			{
				// Do even need to shorten it all?
				if (longPath.Length > maxLen)
				{
					// Split it into pieces, get count
					string[] splits = longPath.Split('\\');
					int parts = splits.Length;
					int h = maxLen / 2;
					// loop thru, look for excessively long single pieces
					for (int i = 0; i < parts; i++)
					{
						if (splits[i].Length > h)
						{
							// Is it the filename itself that's too long?
							if (i == (parts - 1))
							{
								// if filename is too long, shorten it, but not as agressively as a folder
								if (splits[i].Length > (maxLen * .7))
								{
									// shorten filename to "xxxxx…xxxx" (10 characters)
									// which should inlude .ext assuming a 3 char extension
									splits[i] = splits[i].Substring(0, 5) + "…" + splits[i].Substring(splits[i].Length - 4, 4);
								}
							}
							else
							{
								// shorten folder to "xxx…xxx" (7 characters)
								splits[i] = splits[i].Substring(0, 3) + "…" + splits[i].Substring(splits[i].Length - 3, 3);
							}
						}
					}

					// at minimum, we want the filename, lets start with that
					shortPath = splits[parts - 1];
					// figure out what drive it is on
					string drive = "";
					byte b = 0;
					if (splits[0].Length == 2)
					{
						// Regular drive letter like C:
						drive = splits[0] + "\\";
						b = 1;
					}
					if (splits[0].Length + splits[1].Length == 0)
					{
						// UNC path like //server/share
						drive = "\\\\" + splits[0] + "\\" + splits[1] + "\\";
						b = 2;
					}
					// if drive + filename is still short enough, change to that
					if ((shortPath.Length + drive.Length + 2) <= maxLen)
					{
						shortPath = drive + "…\\" + shortPath;
					}
					// if drive + last folder + filename is still short enough, change to that
					if ((shortPath.Length + splits[parts - 2].Length + 1) <= maxLen)
					{
						shortPath = drive + "…\\" + splits[parts - 2] + "\\" + splits[parts - 1];
					}
					// if drive + first folder + last folder + filename is still short enough, change to that
					if ((shortPath.Length + splits[1].Length + 1) <= maxLen)
					{
						shortPath = drive + splits[1] + "\\…\\" + splits[parts - 2] + "\\" + splits[parts - 1];
					}
				} // end if (longPath.Length > maxLen)
			} // end if (maxLen > 18)
				// whatever we ended up with, return it
			return shortPath;
		} // end ShortenLongPath(string longPath, int maxLen)

		public string JustName(string fileName)
		{
			// Returns just the name portion of a filename
			// without the path, without any /'s
			// and without the extension and it's associated .
			string nameOnly = "";
			int i = fileName.IndexOf("\\");
			if (i < 0)
			{
				nameOnly = fileName;
			}
			else
			{
				string[] parts = fileName.Split('\\');
				nameOnly = parts[parts.Length - 1];
			}
			i = nameOnly.LastIndexOf(".");
			if (i > 0)
			{
				nameOnly = nameOnly.Substring(0, i - 1);
			}


			return nameOnly;
		} // end JustName function

		private void label5_Click(object sender, EventArgs e)
		{

		}

		private void btnBrowseMaster_Click(object sender, EventArgs e)
		{

			dlgOpenFile.Filter = "Channel Configs (*.lcc)|*.lcc|Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lee";
			dlgOpenFile.InitialDirectory = basePath;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			DialogResult result = dlgOpenFile.ShowDialog();

			pnlAll.Enabled = false;
			if (result == DialogResult.OK)
			{
				masterFile = dlgOpenFile.FileName;

				FileInfo fi = new FileInfo(masterFile);
				Properties.Settings.Default.MasterFile = masterFile;
				Properties.Settings.Default.Save();

				txtMasterFile.Text = ShortenLongPath(masterFile, 80);
				newSeq.readFile(masterFile);
				FillChannels(treNewChannels, newSeq);
			} // end if (result = DialogResult.OK)
			pnlAll.Enabled = true;
			if (treOldChannels.Nodes.Count > 0)
			{
				btnSummary.Enabled = true;
			}

		}

		private void InitForm()
		{
			basePath = Properties.Settings.Default.BasePath;
			masterFile = Properties.Settings.Default.MasterFile;
			if (File.Exists(masterFile))
			{
				txtMasterFile.Text = ShortenLongPath(masterFile, 80);
				newSeq.readFile(masterFile);
				FillChannels(treNewChannels, newSeq);
			}
			else
			{
				masterFile = "";
			}

		} // end InitForm

		private void treOldChannels_AfterSelect(object sender, TreeViewEventArgs e)
		{
			bool enM = false;    // Default enabled state for the map button will be false
			TreeNode oldCh = e.Node;
			activeOldChannel = e.Node;
			activeList = LIST_OLD;

			// Unhighlight any previous selections
			UnHighlightAllNodes(treOldChannels.Nodes);
			// and highlight this one
			HighlightNode(oldCh, true);

			string oldTag = oldCh.Tag.ToString();
			int iPos = oldTag.IndexOf(DELIM_Map);
			if (iPos > 0)
			{
				// this old Channel has been mapped
				UnHighlightAllNodes(treNewChannels.Nodes);
				string[] mappings = oldTag.Split(DELIM_Map);
				int mapCount = mappings.Length - 1;
				for (int m = 1; m <= mapCount; m++)
				{
					TreeNode hiNode = FindNode(treNewChannels.Nodes, mappings[m]);
					HighlightNode(hiNode, true);
				}
				btnUnmap.Enabled = true;
			}
			else
			{
				// This old Channel has NOT been mapped
				btnUnmap.Enabled = false;

				if (activeNewChannel != null)
				{
					TreeNode newCh = activeNewChannel;
					string newTag = newCh.Tag.ToString();
					// Is the new one unmapped?
					//if (newTag.IndexOf(DELIM_Map) >= 0)
					//{
					//	StatusMessage(MSG_OnlyOneOldToNew);
					//}
					//else
					//{
						string newType = newTag.Substring(0, 1);
						string oldType = oldTag.Substring(0, 1);

						enM = IsMappable(oldType, newType);

					//} // end new channel is already mapped (or not)
				} // end new channel selected
			} // end old channel is mapped (or not)
			btnMap.Enabled = enM;
		} // end treOldChannels_AfterSelect

		bool IsMappable(string oldType, string newType)
		{
			bool enM = false;
			// Are they both regular channels?
			if (oldType.CompareTo("c") == 0)
			{
				if (newType.CompareTo("c") == 0)
				{
					enM = true;
				}
				else
				{
					StatusMessage(MSG_MapRegularToRegular);
				}
			} // end old type is regular ch
				// Are they both RGB channels?
			if (oldType.CompareTo("r") == 0)
			{
				if (newType.CompareTo("r") == 0)
				{
					enM = true;
				}
				else
				{
					StatusMessage(MSG_MapRGBtoRGB);
				}
			} // end old type is RGB
				// Are they both groups?
			if (oldType.CompareTo("g") == 0)
			{
				if (newType.CompareTo("g") == 0)
				{
					// are they similar enough?
					TreeNode oldCh = treOldChannels.SelectedNode;
					TreeNode newCh = treNewChannels.SelectedNode;
					enM = CompareGroups(oldCh, newCh);
					if (!enM)
					{
						StatusMessage(MSG_GroupMatch);
					}
				}
				else
				{
					StatusMessage(MSG_GroupToGroup);
				}
			} // end old type is group
			if (newType.CompareTo("t") == 0)
			{
				StatusMessage(MSG_Tracks);
			}
			if (oldType.CompareTo("t") == 0)
			{
				StatusMessage(MSG_Tracks);
			}
			return enM;
		} // end IsMappable


		bool CompareGroups(TreeNode oldGroup, TreeNode newGroup)
		{
			//TODO: Need to write this!
			// For now, default to false
			bool ret = false;
			return ret;
		}

		private TreeNode FindNode(TreeNodeCollection treeNodes, string tag)
		{
			int tl = tag.Length;
			string st = "";
			TreeNode ret = new TreeNode("NOT FOUND");
			bool found = false;
			foreach (TreeNode nOde in treeNodes)
			{
				if (!found)
				{
					if (nOde.Tag.ToString().Length >= tag.Length)
					{
						st = nOde.Tag.ToString().Substring(0, tl);
						if (tag.CompareTo(st) == 0)
						{
							ret = nOde;
							found = true;
							break;
						}
					}
					if (!found)
					{
						if (nOde.Nodes.Count > 0)
						{
							ret = FindNode(nOde.Nodes, tag);
							if (ret.Text.CompareTo("NOT FOUND") != 0)
							{
								found = true;
							}
						}
					}
				}
			}
			return ret;
		}

		/*
		private int HighlightNode(TreeView tree, string tag)
		{
			int tl = tag.Length;
			int found = 0;
			foreach (TreeNode nOde in tree.Nodes)
			{
				// Reset any previous selections
				//HighlightNode(nOde, false);

				// If node is mapped, it's tag will include the node it is mapped to, and thus the tag length
				// will be longer than just it's own tag info
				int iPos = nOde.Tag.ToString().IndexOf(DELIM_Map);
				if (iPos > 0)
				{
					string mappedTag = nOde.Tag.ToString().Substring(iPos + 1);
					if (mappedTag.CompareTo(oldTag) == 0)
					{
						// The old channel is mapped to this one
						nOde.EnsureVisible();
						HighlightNode(nOde, true);
						if (found == 0)
						{
							treNewChannels.SelectedNode = nOde;
						}
						found++;

					}
				} // end long tag
			} // end foreach
			return found;
		} // end HighlightNewNodes
		*/

		private int HighlightOldNode(string tag)
		{
			int tl = tag.Length;
			int found = 0;
			foreach (TreeNode nOde in treOldChannels.Nodes)
			{
				// Reset any previous selections
				HighlightNode(nOde, false);

				// If node is mapped, it's tag will include the node it is mapped to, and thus the tag length
				// will be longer than just it's own tag info
				if (nOde.Tag.ToString().Length > tl)
				{
					string myTag = nOde.Tag.ToString().Substring(0, tl);
					if (tag.CompareTo(myTag) == 0)
					{
						// The old channel is mapped to this one
						nOde.EnsureVisible();
						HighlightNode(nOde, true);
						treOldChannels.SelectedNode = nOde;
						found++;

					}
				} // end long tag
			} // end foreach
			return found;
		} // end HighlightNewNodes

		private void UnHighlightAllNodes(TreeNodeCollection treeNodes)
		{
			foreach (TreeNode nOde in treeNodes)
			{
				// Reset any previous selections
				HighlightNode(nOde, false);
				if (nOde.Nodes.Count > 0)
				{
					UnHighlightAllNodes(nOde.Nodes);
				}
			} // end foreach
		}

		private void treNewChannels_AfterSelect(object sender, TreeViewEventArgs e)
		{
			bool enM = false;    // Default enabled state for the map button will be false
			TreeNode newCh = e.Node;
			activeNewChannel = e.Node;
			activeList = LIST_NEW;

			// Unhighlight any previous selections
			UnHighlightAllNodes(treNewChannels.Nodes);
			// and highlight this one
			HighlightNode(newCh, true);

			string newTag = newCh.Tag.ToString();
			newCh.BackColor = SystemColors.Highlight;
			newCh.ForeColor = SystemColors.HighlightText;
			int iPos = newTag.IndexOf(DELIM_Map);
			if (iPos > 0)
			{
				// this new Channel has been mapped
				UnHighlightAllNodes(treOldChannels.Nodes);
				string mapping = newTag.Substring(iPos);
				TreeNode nOde = FindNode(treOldChannels.Nodes, mapping);
				HighlightNode(nOde, true);
				btnUnmap.Enabled = true;
			}
			else
			{
				// This new Channel has NOT been mapped
				btnUnmap.Enabled = false;
				TreeNode oldCh = activeOldChannel;
				if (oldCh != null)
				{
					string oldTag = oldCh.Tag.ToString();
					string newType = newTag.Substring(0, 1);
					string oldType = oldTag.Substring(0, 1);

					enM = IsMappable(oldType, newType);
				} // end old channel selected
			} // end old channel is mapped (or not)
			btnMap.Enabled = enM;
		} // end treNewChannel_Click

		private void btnMap_Click(object sender, EventArgs e)
		{
			// The button should not have even been enabled if the 2 channels are not eligible to be mapped ... but--
			// Verify it anyway!

			// Is a node selected on each side?
			if (activeOldChannel != null)
			{
				TreeNode oldCh = activeOldChannel;
				string oldTag = oldCh.Tag.ToString();
				if (activeNewChannel != null)
				{
					TreeNode newCh = activeNewChannel;
					string newTag = newCh.Tag.ToString();

					string newType = newTag.Substring(0, 1);
					string oldType = oldTag.Substring(0, 1);

					// Types match?
					if (oldType.CompareTo("c") == 0)
					{
						if (newType.CompareTo("c") == 0)
						{
							MapChannel(oldCh, newCh, true);
						}
						else
						{
							StatusMessage(MSG_MapRegularToRegular);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (oldType.CompareTo("r") == 0)
					{
						if (newType.CompareTo("r") == 0)
						{
							MapChannel(oldCh, newCh, true);
						}
						else
						{
							StatusMessage(MSG_MapRGBtoRGB);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (oldType.CompareTo("g") == 0)
					{
						if (newType.CompareTo("g") == 0)
						{
							MapChannel(oldCh, newCh, true);
						}
						else
						{
							StatusMessage(MSG_GroupToGroup);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (oldType.CompareTo("t") == 0)
					{
						StatusMessage(MSG_Tracks);
						System.Media.SystemSounds.Beep.Play();
					}
					if (newType.CompareTo("t") == 0)
					{
						StatusMessage(MSG_Tracks);
						System.Media.SystemSounds.Beep.Play();
					}
				}
				else
				{
					System.Media.SystemSounds.Beep.Play();
				}
			}
			else
			{
				System.Media.SystemSounds.Beep.Play();
			}
		} // end btnMap_Click

		private void HighlightNode(TreeNode nOde, bool highlight)
		{
			if (highlight)
			{
				nOde.BackColor = SystemColors.Highlight;
				nOde.ForeColor = SystemColors.HighlightText;
			}
			else
			{
				nOde.BackColor = SystemColors.Window;
				nOde.ForeColor = SystemColors.WindowText;
			}
		}

		private void BoldNode(TreeNode nOde, bool map)
		{
			if (map)
			{
				nOde.NodeFont = new Font(treOldChannels.Font, FontStyle.Bold);
			}
			else
			{
				nOde.NodeFont = new Font(treOldChannels.Font, FontStyle.Regular);
			}
			nOde.Checked = map;
		}

		private void MapChannel(TreeNode oldCh, TreeNode newCh, bool map)
		{
			// Is a node selected on each side?
			if (oldCh != null)
			{
				string oldTag = oldCh.Tag.ToString();
				if (newCh != null)
				{
					string newTag = newCh.Tag.ToString();

					string newType = newTag.Substring(0, 1);
					string oldType = oldTag.Substring(0, 1);

					// Are we mapping or unmapping?
					if (map)
					{
						// Is the new channel already mapped?
						int iPos = newTag.IndexOf(DELIM_Map);
						if (iPos > 0)
						{
							// If so, we need to remove it's existing mapping
							string mappedTo = newTag.Substring(iPos);
							TreeNode preMap = FindNode(treOldChannels.Nodes, mappedTo);
							MapChannel(preMap, newCh, false);
						} // end was mapped, remove old map

						// Types match?
						if (oldType.CompareTo("c") == 0)
						{
							if (newType.CompareTo("c") == 0)
							{
								oldTag += DELIM_Map + newTag;
								oldCh.Tag = oldTag;
								BoldNode(oldCh, true);

								newTag += DELIM_Map + oldTag;
								newCh.Tag = newTag;
								BoldNode(newCh, true);

								btnMap.Enabled = false;
								btnUnmap.Enabled = true;
							}
							else // new type doesn't match
							{
								LogMessage(MSG_MapRegularToRegular);
								LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
							} // end newCh is regular channel
						} // end oldCh is regular channel
						if (oldType.CompareTo("r") == 0)
						{
							if (newType.CompareTo("r") == 0)
							{
								oldTag += DELIM_Map + newTag;
								oldCh.Tag = oldTag;
								BoldNode(oldCh, true);

								newTag += DELIM_Map + oldTag;
								newCh.Tag = newTag;
								BoldNode(newCh, true);

								btnMap.Enabled = false;
								btnUnmap.Enabled = true;

								// now do it for the child nodes, regular channels (R) (G) and (B)
								TreeNode oldRGBnode = oldCh.FirstNode;
								TreeNode newRGBnode = newCh.FirstNode;
								while (oldRGBnode != null)
								{
									MapChannel(oldRGBnode, newRGBnode, true);
									oldRGBnode = oldRGBnode.NextNode;
									newRGBnode = newRGBnode.NextNode;
								} // end while
							}
							else // new type is NOT RGB
							{
								LogMessage(MSG_MapRGBtoRGB);
								LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
							} // end newCh is NOT RGB
						} // end oldCh is RGB
						if (oldType.CompareTo("g") == 0)
						{
							if (newType.CompareTo("g") == 0)
							{
								bool compatible = CompareGroups(oldCh, newCh);
								if (compatible)
								{
									oldTag += DELIM_Map + newTag;
									oldCh.Tag = oldTag;
									BoldNode(oldCh, true);

									newTag += DELIM_Map + oldTag;
									newCh.Tag = newTag;
									BoldNode(newCh, true);

									btnMap.Enabled = false;
									btnUnmap.Enabled = true;

									// now do it for the GroupItems (child nodes) including subgroups (recursive)
									TreeNode oldRGBnode = oldCh.FirstNode;
									TreeNode newRGBnode = newCh.FirstNode;
									while (oldRGBnode != null)
									{
										MapChannel(oldRGBnode, newRGBnode, true);
										oldRGBnode = oldRGBnode.NextNode;
										newRGBnode = newRGBnode.NextNode;
									} // end while
								}
								else // groups are NOT compatible
								{
									LogMessage(MSG_GroupMatch);
									LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
								} // end groups compatible
							}
							else // newType is NOT a group
							{
								LogMessage(MSG_GroupToGroup);
								LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
							} // end newType is a group
						} // end oldtype is group
						if (oldType.CompareTo("t") == 0)
						{
							LogMessage(MSG_Tracks);
							LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
						}
						if (newType.CompareTo("t") == 0)
						{
							LogMessage(MSG_Tracks);
							LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
						}
					} // end Map channels (map = true)
					else // Lets UNMap these channels
					{
						// Are they indeed mapped to each other already?
						int iPos1 = oldTag.IndexOf(DELIM_Map);
						string oldItem = oldTag.Substring(0, iPos1);
						int iPos2 = newTag.IndexOf(DELIM_Map + oldItem);
						if (iPos2 > 0)
						{
							string newItem = newTag.Substring(0, iPos2);
							int iPos3 = oldTag.IndexOf(DELIM_Map + oldItem);
							if (iPos3 > 0)
							{
								// remove mapping from new node (easy)
								newTag = newItem;
								newCh.Tag = newTag;
								BoldNode(newCh, false);

								btnMap.Enabled = true;
								btnUnmap.Enabled = false;

								// remove mapping from old node
								string[] mappings = newTag.Split(DELIM_Map);
								if (mappings.Length > 2)
								{
									// More than one
									oldTag = oldItem;
									for (int m = 1; m < mappings.Length; m++)
									{
										if (mappings[m].CompareTo(newItem) != 0)
										{
											oldTag = oldTag + DELIM_Map + mappings[m];
										}
										oldCh.Tag = oldTag;
									}
								}
								else
								{
									// only one
									oldTag = oldItem;
									oldCh.Tag = oldTag;
									BoldNode(oldCh, false);

								} // how many new channels mapped to this old channel (more than one?)

								// Is it an RGB channel with children?
								if (oldType.CompareTo("r") == 0)
								{
									// now do it for the Red, Green, and Blue child channels
									TreeNode oldRGBnode = oldCh.FirstNode;
									TreeNode newRGBnode = newCh.FirstNode;
									while (oldRGBnode != null)
									{
										MapChannel(oldRGBnode, newRGBnode, true);
										oldRGBnode = oldRGBnode.NextNode;
										newRGBnode = newRGBnode.NextNode;
									} // end while
								}
								// Is it an channel Group with children?
								if (oldType.CompareTo("g") == 0)
								{
									// now do it for the GroupItems (child nodes) including subgroups (recursive)
									TreeNode oldRGBnode = oldCh.FirstNode;
									TreeNode newRGBnode = newCh.FirstNode;
									while (oldRGBnode != null)
									{
										MapChannel(oldRGBnode, newRGBnode, true);
										oldRGBnode = oldRGBnode.NextNode;
										newRGBnode = newRGBnode.NextNode;
									} // end while
								}
							} // end old channel was mapped to the new channel
							else // new channel was mapped to old, but old wasn't mapped to new?
							{
								LogMessage("Error: Old Channel mapped to New Channel, but not vise-versa.");
								LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
							} // end and old channel was mapped to the new channel
						}
						else
						{
							LogMessage("Error: Old Channel not mapped to New Channel.");
							LogMessage(oldCh.Name + DELIM_Name + oldCh.Tag + " to " + newCh.Name + DELIM_Name + newCh.Tag);
						} // end new channel was mapped to the old channel
					} // end map or unmap
				} // end newChannel Node isn't null
			} // end oldChannel Node isn't null
		} // end btnMap_Click
	
		private void btnUnmap_Click(object sender, EventArgs e)
		{

		}

		private void addMap(string oldChTag, string newChTag)
		{
		}

		private void removeMap(string oldChTag, string newChTag)
		{
		
		}

		private void StatusMessage(string message)
		{
			// For now at least... I think I'm gonna use this just to show WHY the 'Map' button is not enabled
			

			lblStatus.Text = message;
			lblStatus.Visible = (message.Length > 0);
			lblStatus.Left = (this.Width - lblStatus.ClientSize.Width) / 2;

		}

		private void LogMessage(string message)
		{
			//TODO: This
		}

		private void frmRemapper_Shown(object sender, EventArgs e)
		{
			InitForm();
		}

		private void btnSummary_Click(object sender, EventArgs e)
		{
			frmMapList dlgList = new frmMapList();
			dlgList.oldTree = this.treOldChannels;
			dlgList.newTree = this.treNewChannels;
			dlgList.BuildList();

			DialogResult result = dlgList.ShowDialog();
		}
	} // end class frmRemapper
} // end namespace ChannelRemapper
