﻿using System.Reflection;

[assembly: AssemblyCompany("Matt Johnson")]
[assembly: AssemblyProduct("Time Zone Names")]
[assembly: AssemblyCopyright("Copyright © Matt Johnson")]

[assembly: AssemblyVersion("2.1.0.*")]
[assembly: AssemblyInformationalVersion("2.1.0")]
