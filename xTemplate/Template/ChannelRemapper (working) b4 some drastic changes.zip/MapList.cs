﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChannelRemapper
{
	public partial class frmMapList : Form
	{
		public bool sortByOld = true;
		public bool sortAlpha = false;
		public TreeView oldTree;
		public TreeView newTree;
		private const char DELIM_Map = (char)164;  // ¤
		private const string NOTMAPPED = "(Not Mapped)";

		public frmMapList()
		{
			InitializeComponent();
		}

		private void frmMapList_Load(object sender, EventArgs e)
		{
			lstMap.Columns[0].TextAlign = HorizontalAlignment.Right;
		}

		public void BuildList()
		{
			lstMap.Items.Clear();
			if (sortByOld)
			{
				if (sortAlpha)
				{

				}
				else // NOT sort Alpha
				{
					// Sort by display order
					foreach (TreeNode nOde in oldTree.Nodes)
					{
						addNode(nOde);
					} // end foreach node
					if (chkUnmapped.Checked)
					{
						foreach (TreeNode nOde in newTree.Nodes)
						{
							string newTag = nOde.Tag.ToString();
							if (newTag.Substring(0, 1).CompareTo("t") != 0)
							{
								int iPos = newTag.IndexOf(DELIM_Map);
								if (iPos < 0)
								{
									//newItem.Text = NOTMAPPED;
									//newItem.SubItems[0].Font = new Font(lstMap.Font, FontStyle.Italic);
									//newItem.SubItems[1].Text = nOde.Text;
								}
							}
						} // end foreach node
					} // end UnMapped.Checked
				} // end Sort by Alpha
			}
			else // NOT sort by Old
			{
				// Sort by New

			}




		}

		private  void addNode(TreeNode nOde)
		{
			string oldTag = nOde.Tag.ToString();
			if (oldTag.Substring(0, 1).CompareTo("t") != 0)
			{
				ListViewItem newItem = new ListViewItem("");
				newItem.SubItems.Add("");
				int iPos = oldTag.IndexOf(DELIM_Map);
				if (iPos > 0)
				{
					string[] mappings = oldTag.Split(DELIM_Map);
					for (int m = 1; m < mappings.Length; m++)
					{
						newItem.Text = nOde.Text;
						TreeNode mappedNode = FindNode(oldTree.Nodes, mappings[m]);
						newItem.SubItems[1].Text = mappedNode.Text;
						lstMap.Items.Add(newItem);
					}
				}
				else
				{
					if (chkUnmapped.Checked)
					{
						newItem.Text = nOde.Text;
						newItem.SubItems[1].Text = NOTMAPPED;
						newItem.SubItems[1].Font = new Font(lstMap.Font, FontStyle.Italic);
						lstMap.Items.Add(newItem);
					}
				} // end mapped or not
			} // end node is not a track
			if (nOde.Nodes.Count > 0)
			{
				foreach (TreeNode child in nOde.Nodes)
				{
					addNode(child);
				}
			}
		}


		private TreeNode FindNode(TreeNodeCollection treeNodes, string tag)
		{
			int tl = tag.Length;
			string st = "";
			TreeNode ret = new TreeNode("NOT FOUND");
			bool found = false;
			foreach (TreeNode nOde in treeNodes)
			{
				if (!found)
				{
					if (nOde.Tag.ToString().Length >= tag.Length)
					{
						st = nOde.Tag.ToString().Substring(0, tl);
						if (tag.CompareTo(st) == 0)
						{
							ret = nOde;
							found = true;
							break;
						}
					}
					if (!found)
					{
						if (nOde.Nodes.Count > 0)
						{
							ret = FindNode(nOde.Nodes, tag);
							if (ret.Text.CompareTo("NOT FOUND") != 0)
							{
								found = true;
							}
						}
					}
				}
			}
			return ret;
		}


	}
}
