﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Microsoft.Win32;
using LORUtils;
using FuzzyString;

namespace MapORama
{


	public partial class frmRemapper : Form
	{
		private const int LIST_OLD = 1;
		private const int LIST_NEW = 2;
		private bool dirtyMap = false;
		private bool dirtyDest = false;

		private const string CRLF = "\r\n";
		private const string helpPage = "http://wizlights.com/utilorama/maporama";

		private string applicationName = "Map-O-Rama";
		private string thisEXE = "map-o-rama.exe";
		private string tempPath = "C:\\Windows\\Temp\\";  // Gets overwritten with X:\\Username\\AppData\\Roaming\\Util-O-Rama\\Split-O-Rama\\
		private string[] commandArgs;
		private bool batchMode = false;
		private int batch_fileCount = 0;
		private int batch_fileNumber = 0;
		private string[] batch_fileList = null;
		private string cmdSelectionsFile = "";
		private const int BATCHnone = 0;
		private const int BATCHmaster = 1;
		private const int BATCHmap = 2;
		private const int BATCHsources = 4;
		private const int BATCHall = 7;
		private int batchTypes = BATCHnone;
		private bool processDrop = false;
		private bool sourceOnRight = false;


		private const string MSG_MapRegularToRegular = "Regular Channels can only be mapped to other regular Channels.";
		private const string MSG_MapRGBtoRGB = "RGB Channels can only be mapped to other RGB Channels.";
		private const string MSG_GroupToGroup = "Groups can only be mapped to other groups, and only if they have the same number of regular Channels and RGB Channels in the same order.";
		private const string MSG_GroupMatch = "Groups can only be mapped to other groups if they have the same number of regular Channels, RGB Channels, and subgroups in the same order.";
		private const string MSG_Tracks = "Tracks can not be mapped.";
		private const string MSG_OnlyOneOldToNew = "The Selected source channel already has a template channel mapped to it.";
		private const string MSG_OnlyOneGroupToNew = "The Selected source group already has a template group mapped to it.";

		private const double MINSCORE = 0.85D;
		private const double MINMATCH = 0.92D;
		private Color COLOR_BK_SELECTED = Color.FromName("DarkBlue");
		private Color COLOR_BK_SELCHILD = Color.FromName("LightBlue");
		private Color COLOR_BK_MATCHED = Color.FromName("DarkGreen");
		private Color COLOR_BK_MATCHCHILD = Color.FromName("LightGreen");
		private Color COLOR_BK_BOTH = Color.FromName("DarkCyan");
		private Color COLOR_BK_NONE = Color.FromName("White");
		private Color COLOR_FR_SELECTED = Color.FromName("White");
		private Color COLOR_FR_NONE = Color.FromName("Black");

		private bool firstShown = false;

		// These are used by MapList so need to be public
		public Sequence4 seqSource = new Sequence4();
		public Sequence4 seqMaster = new Sequence4();
		public int[] MtoS = null;  // Array indexed by Master.SavedIndex, elements contain Source.SaveIndex
		public List<int>[] StoM = null; // Array indexed by Source.SavedIindex, elements are Lists of Master.SavedIndex-es
		public int mappingCount = 0;
		public List<List<TreeNode>> sourceNodesSI = new List<List<TreeNode>>();
		public List<List<TreeNode>> masterNodesSI = new List<List<TreeNode>>();
		public string masterFile = "";
		public string sourceFile = "";
		public string mapFile = "";
		private int mapFileLineCount = 0;
		private string saveFile = "";



		private string basePath = "";
		private string SeqFolder = "";
		private TreeNode sourceNode = null;
		private TreeNode masterNode = null;
		private SeqPart sourceID = null;
		private SeqPart masterID = null;
		private int sourceSI = utils.UNDEFINED;
		private int masterSI = utils.UNDEFINED;
		// int activeList = 0;
		public string statMsg = "Hello World!";
		//private Assembly assy = this.GetType().Assembly;
		//ResourceManager resources = new ResourceManager("Resources.Strings", assy);


		// Used only at load time to restore previous size/position
		//private int miLoadHeight = 400;
		//private int miLoadWidth = 620;
		//private int miLoadLeft = 0;
		//private int miLoadTop = 0;

			/*
		private class ChanInfo
		{
			public TableType chType = TableType.None;
			public int chIndex = 0;
			public int SavedIndex = utils.UNDEFINED;
			public int mapCount = 0;
			//public int[] mapChIndexes;
			//public int[] mapSavedIndexes;
			public int nodeIndex = utils.UNDEFINED;
		}
		*/

		private int nodeIndex = utils.UNDEFINED;
		// Note Master->Source mappings are a 1:Many relationship.
		// A Master channel can map to only one Source channel
		// But a Source channel may map to more than one Master channel

		private StreamWriter logWriter1 = null;
		private StreamWriter logWriter2 = null;
		private StreamWriter logWriter3 = null;
		private string logFile1 = "";
		private string logFile2 = "";
		private string logFile3 = "";
		private bool log1Open = false;
		private bool log2Open = false;
		private bool log3Open = false;
		private string logHomeDir = ""; // Gets set during InitForm to "C:\\Users\\Wizard\\AppData\\Local\\UtilORama\\MapORama\\" (sustitute your name)
		private string logMsg = "";


		const string xmlInfo = "<?xml version=\"1.0\" encoding=\"UTF - 8\" standalone=\"no\"?>";
		const string TABLEchMap = "channelMap";
		const string TABLEfiles = "files";
		const string FIELDmasterFile = "masterFile";
		const string FIELDsourceFile = "sourceFile";
		const string TABLEchannels = "channels";
		const string FIELDmasterChannel = "masterChannel";
		const string FIELDsourceChannel = "sourceChannel";
		const string TABLEmappings = "mappings";



		private struct match
		{
			public double score;
			public int savedIdx;
			public int itemIdx;
			public TableType type;
		}



		public frmRemapper()
		{
			InitializeComponent();
		}

		private void btnBrowseSource_Click(object sender, EventArgs e)
		{
			BrowseSourceFile();
		}

		private void BrowseSourceFile()
		{ 
			string initDir = utils.DefaultSequencesPath;
			string initFile = "";
			if (sourceFile.Length > 4)
			{
				string ldir = Path.GetFullPath(sourceFile);
				if (Directory.Exists(ldir))
				{
					initDir = ldir;
					if (File.Exists(sourceFile))
					{
						initFile = Path.GetFileName(sourceFile);
					}
				}
			}


			dlgOpenFile.Filter = "Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lms";
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			dlgOpenFile.Title = "Open Sequence...";
			DialogResult result = dlgOpenFile.ShowDialog();

			pnlAll.Enabled = false;
			if (result == DialogResult.OK)
			{
				int err = LoadSourceFile(dlgOpenFile.FileName);
			} // end if (result = DialogResult.OK)
			pnlAll.Enabled = true;
			btnSummary.Enabled = (mappingCount > 0);
			mnuSummary.Enabled = btnSummary.Enabled;

		}

		public int LoadSourceFile(string sourceChannelFile)
		{
			ImBusy(true);
			int err = seqSource.ReadSequenceFile(sourceChannelFile);
			if (err < 100)
			{
				sourceFile = sourceChannelFile;
				txtSourceFile.Text = utils.ShortenLongPath(sourceFile, 80);
				this.Text = "Map-O-Rama - " + Path.GetFileName(sourceFile);
				FileInfo fi = new FileInfo(sourceChannelFile);
				Properties.Settings.Default.BasePath = fi.DirectoryName;
				Properties.Settings.Default.LastSourceFile = sourceFile;
				Properties.Settings.Default.Save();
				utils.FillChannels(treeSource, seqSource, sourceNodesSI, false, false);
				// Erase any existing mappings, and create a new blank one of proper size
				MtoS = null;
				StoM = null;
				mappingCount = 0;
				Array.Resize(ref StoM, seqSource.Children.allCount);
				for (int i = 0; i < StoM.Length; i++)
				{
					StoM[i] = new List<int>();
				}
				if (seqMaster.Channels.Count > 0)
				{
					Array.Resize(ref MtoS, seqMaster.Children.allCount);
					for (int i = 0; i < MtoS.Length; i++)
					{
						MtoS[i] = utils.UNDEFINED;
					}

				}
			}
			ImBusy(false);
			return err;
		}

		private void btnBrowseMaster_Click(object sender, EventArgs e)
		{
			BrowseMasterFile();
		}

		private void BrowseMasterFile()
		{ 

			string initDir = utils.DefaultSequencesPath;
			string initFile = "";
			if (masterFile.Length > 4)
			{
				string ldir = Path.GetFullPath(masterFile);
				if (Directory.Exists(ldir))
				{
					initDir = ldir;
					if (File.Exists(masterFile))
					{
						initFile = Path.GetFileName(masterFile);
					}
				}
			}


			dlgOpenFile.Filter = "Channel Configs (*.lcc)|*.lcc|Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lee";
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			dlgOpenFile.Title = "Select Master Channel Config File...";
			DialogResult result = dlgOpenFile.ShowDialog();

			//pnlAll.Enabled = false;
			if (result == DialogResult.OK)
			{
				//masterFile = dlgOpenFile.FileName;

				int err = LoadMasterFile(dlgOpenFile.FileName);

			} // end if (result = DialogResult.OK)
			//pnlAll.Enabled = true;
			if (treeSource.Nodes.Count > 0)
			{
				//btnSummary.Enabled = true;
			}

		}

		private int LoadMasterFile(string masterChannelFile)
		{
			ImBusy(true);
			int err = seqMaster.ReadSequenceFile(masterChannelFile);
			if (err < 100)  // Error numbers below 100 are warnings, above 100 are fatal
			{
				for (int w = 0; w < seqMaster.Children.byName.Count; w++)
				{
					//Console.WriteLine(seqMaster.Children.byName[w].Name);
				}





				masterFile = masterChannelFile;
				FileInfo fi = new FileInfo(masterFile);
				Properties.Settings.Default.LastMasterFile = masterFile;
				Properties.Settings.Default.Save();

				txtMasterFile.Text = utils.ShortenLongPath(masterFile, 80);



				utils.FillChannels(treeMaster, seqMaster, masterNodesSI, false, false);

				// Erase any existing mappings, and create a new blank one of proper size
				// Erase any existing mappings, and create a new blank one of proper size
				MtoS = null;
				StoM = null;
				mappingCount = 0;
				if (seqSource.Channels.Count > 0)
				{
					Array.Resize(ref StoM, seqSource.Children.allCount);
					for (int i = 0; i < StoM.Length; i++)
					{
						StoM[i] = new List<int>();
					}
				}
				Array.Resize(ref MtoS, seqMaster.Children.allCount);
				for (int i = 0; i < MtoS.Length; i++)
				{
					MtoS[i] = utils.UNDEFINED;
				}
				AskToMap();

			}


			ImBusy(false);
			return err;
		}

		public int SaveNewMappedSequence(string newSeqFileName)
		{
			Sequence4 seqNew = seqMaster;

			seqNew.info = seqSource.info;
			seqNew.info.filename = newSeqFileName;
			seqNew.sequenceType = seqSource.sequenceType;
			seqNew.Centiseconds = seqSource.Centiseconds;
			seqNew.animation = seqSource.animation;
			seqNew.videoUsage = seqSource.videoUsage;

			seqNew.ClearAllEffects();
			for (int i = 0; i < MtoS.Length; i++)
			{
				if (MtoS[i] > utils.UNDEFINED)
				{
					int msi = i;
					SeqPart mid = seqNew.Children.bySavedIndex[msi];
					if (mid.TableType == TableType.Channel)
					{
						int ssi = MtoS[i];
						SeqPart sid = seqSource.Children.bySavedIndex[ssi];
						if (sid.TableType == TableType.Channel)
						{
							Channel sch = (Channel)sid;
							if (sch.effects.Count > 0)
							{
								Channel mch = (Channel)mid;
								mch.CopyEffects(sch.effects, false);
								mch.Centiseconds = sch.Centiseconds;
							} // end if effects.Count
						} // end if source obj is channel
					}
					else // master obj is NOT a channel
					{
						if (mid.TableType == TableType.RGBchannel)
						{
							int ssi = MtoS[i];
							SeqPart sid = seqSource.Children.bySavedIndex[ssi];
							if (sid.TableType == TableType.RGBchannel)
							{
								RGBchannel srgb = (RGBchannel)sid;
								RGBchannel mrgb = (RGBchannel)mid;
								mrgb.Centiseconds = srgb.Centiseconds;
								Channel sch = srgb.redChannel;
								Channel mch;
								if (sch.effects.Count > 0)
								{
									mch = mrgb.redChannel;
									mch.CopyEffects(sch.effects, false);
								} // end if effects.Count
								sch = srgb.grnChannel;
								if (sch.effects.Count > 0)
								{
									mch = mrgb.grnChannel;
									mch.CopyEffects(sch.effects, false);
								} // end if effects.Count
								sch = srgb.bluChannel;
								if (sch.effects.Count > 0)
								{
									mch = mrgb.bluChannel;
									mch.CopyEffects(sch.effects, false);
								} // end if effects.Count
								
							} // end if source obj is RGB channel
						}
						else // master obj is NOT an RGBchannel
						{
							// Channel Group = do nothing (?)
							// Track = do nothing (?)
							// Timing Grid = do nothing (?)
						} // end if master obj is an RGBchannel (or not)
					} // end if master obj is channel (or not)
				} // end if mapping is undefined
			} // loop thru master Channels

			foreach (Channel ch in seqMaster.Channels)
			{
				ch.Centiseconds = seqSource.Centiseconds;
			}
			foreach (RGBchannel rc in seqMaster.RGBchannels)
			{
				rc.Centiseconds = seqSource.Centiseconds;
			}
			foreach (ChannelGroup cg in seqMaster.ChannelGroups)
			{
				cg.Centiseconds = seqSource.Centiseconds;
			}
			foreach (Track tr in seqMaster.Tracks)
			{
				tr.Centiseconds = seqSource.Centiseconds;
			}

			seqNew.TimingGrids = new List<TimingGrid>();
			foreach(TimingGrid tg in seqSource.TimingGrids)
			{
				TimingGrid ntg = seqNew.ParseTimingGrid(tg.LineOut());
				ntg.CopyTimings(tg);
			}

			int err = seqNew.WriteSequenceFile_DisplayOrder(newSeqFileName);
			seqNew.ClearAllEffects();
			return err;
		}


		private void ImBusy(bool workingHard)
		{
			pnlAll.Enabled = !workingHard;
			if (workingHard)
			{
				this.Cursor = Cursors.WaitCursor;
			}
			else
			{
				this.Cursor = Cursors.Default;
			}

		}


		private void InitForm()
		{
			SeqFolder = utils.DefaultSequencesPath;
			logHomeDir = utils.GetAppTempFolder();
			
			masterFile = Properties.Settings.Default.LastMasterFile;
			if (!File.Exists(masterFile))
			{ 
				masterFile = "";
				Properties.Settings.Default.LastMasterFile = masterFile;
			}
			sourceFile = Properties.Settings.Default.LastSourceFile;
			if (!File.Exists(sourceFile))
			{
				sourceFile = "";
				Properties.Settings.Default.LastSourceFile = sourceFile;
			}

			mapFile = Properties.Settings.Default.LastMapFile;
			if (!File.Exists(mapFile))
			{
				mapFile = "";
			}

			sourceOnRight = Properties.Settings.Default.SourceOnRight;
			ArrangePanes(sourceOnRight);

			Properties.Settings.Default.BasePath = basePath;
			Properties.Settings.Default.Save();

			RestoreFormPosition();

		} // end InitForm


		private void SaveFormPosition()
		{
			// Called with form is closed
			for(int i = 0; i < Screen.AllScreens.Length; i++)
			{
				if (Screen.AllScreens[i].DeviceName == Screen.FromControl(this).DeviceName)
				{
					Properties.Settings.Default.Screen = i;
				}
			}

			if (WindowState == FormWindowState.Normal)
			{
				Properties.Settings.Default.Location = Location;
				Properties.Settings.Default.Size = Size;
				Properties.Settings.Default.Minimized = false;
			}
			else
			{
				Properties.Settings.Default.Location = RestoreBounds.Location;
				Properties.Settings.Default.Size = RestoreBounds.Size;
				Properties.Settings.Default.Minimized = true;
			}
			Properties.Settings.Default.Save();

		} // End SaveFormPosition


		bool IsMappable(TableType sourceType, TableType masterType)
		{
			bool enM = false;
			// Are they both regular Channels?
			if (sourceType == TableType.Channel)
			{
				if (masterType == TableType.Channel)
				{
					enM = true;
				}
				else
				{
					StatusMessage(MSG_MapRegularToRegular);
				}
			} // end old type is regular ch
				// Are they both RGB Channels?
			if (sourceType == TableType.RGBchannel)
			{
				if (masterType == TableType.RGBchannel)
				{
					enM = true;
				}
				else
				{
					StatusMessage(MSG_MapRGBtoRGB);
				}
			} // end old type is RGB
				// Are they both groups?
			if (sourceType == TableType.ChannelGroup)
			{
				if (masterType == TableType.ChannelGroup)
				{
					// are they similar enough?
					TreeNode sourceNode = treeSource.SelectedNode;
					SeqPart sourceID = (SeqPart)sourceNode.Tag;
					int sourceSI = sourceID.SavedIndex;
					TreeNode masterNode = treeMaster.SelectedNode;
					SeqPart masterID = (SeqPart)masterNode.Tag;
					int masterSI = masterID.SavedIndex;
					enM = IsCompatible(sourceSI, masterSI);
					if (!enM)
					{
						StatusMessage(MSG_GroupMatch);
					}
				}
				else
				{
					StatusMessage(MSG_GroupToGroup);
				}
			} // end old type is group
			if (masterType == TableType.Track)
			{
				StatusMessage(MSG_Tracks);
			}
			if (sourceType == TableType.Track)
			{
				StatusMessage(MSG_Tracks);
			}
			return enM;
		} // end IsMappable


		bool IsCompatible(int sourceThingSI, int masterThingSI)
		// not necessarily groups, called recursively
		{
			bool ret = true;
			if ((sourceThingSI < 0) || (masterThingSI < 0))
			{
				ret = false;
			}
			else
			{
				TableType sourceType = seqSource.Children.bySavedIndex[sourceThingSI].TableType;

				if (sourceType != seqMaster.Children.bySavedIndex[masterThingSI].TableType)
				{
					ret = false;
				}
				else
				{
					if (sourceType == TableType.Channel)
					{
						ret = true;
					}
					else
					{
						if (sourceType == TableType.RGBchannel)
						{
							ret = true;
						}
						else
						{
							if (sourceType == TableType.Track)
							{
								ret = false;
								Track sourceTrk = (Track)seqSource.Children.bySavedIndex[sourceThingSI];
								Track masterTrk = (Track)seqMaster.Children.bySavedIndex[masterThingSI];
								//if ((sourceTrk.itemSavedIndexes[0] < 0) || (masterTrk.itemSavedIndexes[0] < 0))
								if ((sourceTrk.Children.Items.Count<1) || (masterTrk.Children.Items.Count<1))
								{
									ret = false;
								}
								else
								{
									if (sourceTrk.Children.Items.Count != masterTrk.Children.Items.Count)
									{
										ret = false;
									}
									else
									{
										//foreach (int srcSI in sourceTrk.itemSavedIndexes)
										for (int itm = 0; itm < sourceTrk.Children.Items.Count; itm++)
										{
											if (ret)
											{
												ret = IsCompatible(sourceTrk.Children.Items[itm].SavedIndex, masterTrk.Children.Items[itm].SavedIndex);
											} // if last item still OK
										} // end loop thru item saved indexes
									} // end else counts match
								} // end else first elements < 0
							}
							else
							{
								if (sourceType == TableType.ChannelGroup)
								{
									ChannelGroup sourceGrp = (ChannelGroup)seqSource.Children.bySavedIndex[sourceThingSI]; // seqSource.ChannelGroups[seqSource.savedIndexes[sourceThingSI].objIndex];
									ChannelGroup masterGrp = (ChannelGroup)seqMaster.Children.bySavedIndex[masterThingSI]; // seqMaster.ChannelGroups[seqMaster.savedIndexes[masterThingSI].objIndex];
									//if ((sourceGrp.itemSavedIndexes[0] < 0) || (masterGrp.itemSavedIndexes[0] < 0))
									if ((sourceGrp.Children.Items.Count < 1) || (masterGrp.Children.Items.Count <1))
									{
										ret = false;
									}
									else
									{
										if (sourceGrp.Children.Items.Count != masterGrp.Children.Items.Count)
										{
											ret = false;
										}
										else
										{
											//foreach (int srcSI in sourceGrp.itemSavedIndexes)
											for (int itm = 0; itm < sourceGrp.Children.Items.Count; itm++)
											{
												if (ret)
												{
													ret = IsCompatible(sourceGrp.Children.Items[itm].SavedIndex, masterGrp.Children.Items[itm].SavedIndex);
												} // if last item still OK
											} // end loop thru item saved indexes
										} // end else counts match
									} // end else first elements < 0
								} // end if group
							} // end if not track
						} // is an RGB Channel
					} // is a channel
				} // end if types match
			} // end SIs aren't undefined
			return ret;
		} // end IsCompatible

		private TreeNode FindNode(TreeNodeCollection treeNodes, string tag)
		{
			int tl = tag.Length;
			string st = "";
			TreeNode ret = new TreeNode("NOT FOUND");
			bool found = false;
			foreach (TreeNode nOde in treeNodes)
			{
				if (!found)
				{
					if (nOde.Tag.ToString().Length >= tag.Length)
					{
						st = nOde.Tag.ToString().Substring(0, tl);
						if (tag.CompareTo(st) == 0)
						{
							ret = nOde;
							found = true;
							break;
						}
					}
					if (!found)
					{
						if (nOde.Nodes.Count > 0)
						{
							ret = FindNode(nOde.Nodes, tag);
							if (ret.Text.CompareTo("NOT FOUND") != 0)
							{
								found = true;
							}
						}
					}
				}
			}
			return ret;
		}

		/*
		private int HighlightNode(TreeView tree, string tag)
		{
			int tl = tag.Length;
			int found = 0;
			foreach (TreeNode nOde in tree.Nodes)
			{
				// Reset any previous selections
				//HighlightNode(nOde, false);

				// If node is mapped, it's tag will include the node it is mapped to, and thus the tag length
				// will be longer than just it's own tag info
				int iPos = nOde.Tag.ToString().IndexOf(DELIM_Map);
				if (iPos > 0)
				{
					string mappedTag = nOde.Tag.ToString().Substring(iPos + 1);
					if (mappedTag.CompareTo(oldTag) == 0)
					{
						// The old channel is mapped to this one
						nOde.EnsureVisible();
						HighlightNode(nOde, true);
						if (found == 0)
						{
							treeMaster.SelectedNode = nOde;
						}
						found++;

					}
				} // end long tag
			} // end foreach
			return found;
		} // end HighlightNewNodes
		*/

		private int HighlightSourceNode(string tag)
		{
			int tl = tag.Length;
			int found = 0;
			foreach (TreeNode nOde in treeSource.Nodes)
			{
				// Reset any previous selections
				HighlightNode(nOde, false);

				// If node is mapped, it's tag will include the node it is mapped to, and thus the tag length
				// will be longer than just it's own tag info
				if (nOde.Tag.ToString().Length > tl)
				{
					string myTag = nOde.Tag.ToString().Substring(0, tl);
					if (tag.CompareTo(myTag) == 0)
					{
						// The old channel is mapped to this one
						nOde.EnsureVisible();
						HighlightNode(nOde, true);
						treeSource.SelectedNode = nOde;
						found++;

					}
				} // end long tag
			} // end foreach
			return found;
		} // end HighlightNewNodes

		private void UnHighlightAllNodes(TreeNodeCollection treeNodes)
		{
			foreach (TreeNode nOde in treeNodes)
			{
				// Reset any previous selections
				HighlightNode(nOde, false);
				if (nOde.Nodes.Count > 0)
				{
					UnHighlightAllNodes(nOde.Nodes);
				}
			} // end foreach
		}

		private void treeSource_AfterSelect(object sender, TreeViewEventArgs e)
		{
			TreeNode sn = e.Node;
			if (sn != null)
			{
				SeqPart sid = (SeqPart)sn.Tag;
				//int sourceSI = sid.SavedIndex;
				// Did the selection change?
				if (sid.SavedIndex != sourceSI)
				{
					sourceNode = sn;
					sourceID = sid;
					sourceSI = sid.SavedIndex;
					// Unselect any previous selections
					UnSelectAllNodes(treeSource.Nodes);
					// and highlight this one (and any others in this tree with a matching SavedIndex)
					SelectNodes(treeSource.Nodes, sourceSI, true);

					// Is it matched?
					if (StoM[sourceSI].Count > 0)
					{
						UnSelectAllNodes(treeMaster.Nodes);
						foreach (int msi in StoM[sourceSI])
						{
							SelectNodes(treeMaster.Nodes, msi, true);
							masterSI = msi;
							masterID = seqMaster.Children.bySavedIndex[msi];

						}
						btnMap.Enabled = false;
						mnuMap.Enabled = false;
						if (StoM[sourceSI].Count == 1)
						{
							btnUnmap.Enabled = true;
							mnuUnmap.Enabled = true;
						}
						else
						{
							btnUnmap.Enabled = false;
							mnuUnmap.Enabled = false;
						}
					}
					else // not matched
					{
						btnUnmap.Enabled = false;
						mnuUnmap.Enabled = false;
						bool mappable = IsCompatible(sourceSI, masterSI);
						btnMap.Enabled = mappable;
						mnuMap.Enabled = mappable;

					}
				}
			}
		} // end treeSource_AfterSelect

		private void treeMaster_AfterSelect(object sender, TreeViewEventArgs e)
		{
			TreeNode mn = e.Node;
			if (mn != null)
			{
				SeqPart mid = (SeqPart)mn.Tag;
				// Did the selection change?
				if (mid.SavedIndex != masterSI)
				{
					masterNode = mn;
					masterID = mid;
					masterSI = mid.SavedIndex;
					// Unselect any previous selections
					UnSelectAllNodes(treeMaster.Nodes);
					// and highlight this one (and any others in this tree with a matching SavedIndex)
					SelectNodes(treeMaster.Nodes, masterSI, true);

					// Is it matched?
					if (MtoS[masterSI] > utils.UNDEFINED)
					{
						UnSelectAllNodes(treeSource.Nodes);
						SelectNodes(treeSource.Nodes, MtoS[masterSI], true);
						btnMap.Enabled = false;
						mnuMap.Enabled = false;
						btnUnmap.Enabled = true;
						mnuUnmap.Enabled = true;
						sourceSI = MtoS[masterSI];
						sourceID = seqSource.Children.bySavedIndex[sourceSI];
					}
					else // not matched
					{
						btnUnmap.Enabled = false;
						mnuUnmap.Enabled = false;
						bool mappable = IsCompatible(sourceSI, masterSI);
						btnMap.Enabled = mappable;
						mnuMap.Enabled = mappable;
					}
				}
			}
		} // end treNewChannel_Click

		private void btnMap_Click(object sender, EventArgs e)
		{
			// The button should not have even been enabled if the 2 Channels are not eligible to be mapped ... but--
			// Verify it anyway!

			// Is a node Selected on each side?
			if (sourceNode != null)
			{
				if (masterNode != null)
				{
					// Types match?

					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.Channel)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.Channel)
						{
							MapChannels(masterSI, sourceSI, true, true);
							dirtyMap = true;
							btnSaveMap.Enabled = dirtyMap;
							mnuSaveNewMap.Enabled = dirtyMap;
						}
						else
						{
							statMsg = Resources.MSG_MapRegularToRegular;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.RGBchannel)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.RGBchannel)
						{
							MapChannels(masterSI, sourceSI, true, true);
							dirtyMap = true;
							btnSaveMap.Enabled = dirtyMap;
							mnuSaveNewMap.Enabled = dirtyMap;
						}
						else
						{
							statMsg = Resources.MSG_MapRGBtoRGB;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.ChannelGroup)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.ChannelGroup)
						{
							MapChannels(masterSI, sourceSI, true, true);
							dirtyMap = true;
							btnSaveMap.Enabled = dirtyMap;
							mnuSaveNewMap.Enabled = dirtyMap;
						}
						else
						{
							statMsg = Resources.MSG_GroupToGroup;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.Track)
					{
						statMsg = Resources.MSG_Tracks;
						StatusMessage(statMsg);
						System.Media.SystemSounds.Beep.Play();
					}
					if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.Track)
					{
						statMsg = Resources.MSG_Tracks;
						StatusMessage(statMsg);
						System.Media.SystemSounds.Beep.Play();
					}
				}
				else
				{
					System.Media.SystemSounds.Beep.Play();
				}
			}
			else
			{
				System.Media.SystemSounds.Beep.Play();
			}
		} // end btnMap_Click

		private void HighlightNode(TreeNode nOde, bool highlight)
		{
			if (highlight)
			{
				if (nOde.BackColor == COLOR_BK_SELECTED)
				{
					nOde.BackColor = COLOR_BK_BOTH;
				}
				else
				{
					nOde.BackColor = COLOR_BK_MATCHED;
				}
				nOde.ForeColor = COLOR_FR_SELECTED;
			}
			else
			{
				if (nOde.BackColor == COLOR_BK_BOTH)
				{
					nOde.BackColor = COLOR_BK_SELECTED;
				}
				else
				{
					nOde.BackColor = COLOR_BK_NONE;
					nOde.ForeColor = COLOR_FR_NONE;
				}
			}
		}

		private void SelectNode(TreeNode nOde, bool select)
		// BEWARE: Procedure name is a bit misleading
		// This procedure sets the appearance of a node to the 'Selected' appearance
		// (As opposed to the 'Matched' appearance (see HighlightNode procedure above)
		{
			if (select)
			{
				if (nOde.BackColor == COLOR_BK_MATCHED)
				{
					nOde.BackColor = COLOR_BK_BOTH;
				}
				else
				{
					nOde.BackColor = COLOR_BK_SELECTED;
				}
				nOde.ForeColor = COLOR_FR_SELECTED;
			}
			else
			{
				if (nOde.BackColor == COLOR_BK_BOTH)
				{
					nOde.BackColor = COLOR_BK_MATCHED;
				}
				else
				{
					nOde.BackColor = COLOR_BK_NONE;
					nOde.ForeColor = COLOR_FR_NONE;
				}
			}
		}

		private void SelectNodes(TreeNodeCollection nOdes, int SavedIndex, bool select)
		{
			//string nTag = "";
			SeqPart nID = null;
			foreach (TreeNode nOde in nOdes)
			{
				nID = (SeqPart)nOde.Tag;
				if (nID.SavedIndex == SavedIndex)
				{
					SelectNode(nOde, select);
				}
				if (nOde.Nodes.Count > 0)
				{
					// Recurse if child nodes
					SelectNodes(nOde.Nodes, SavedIndex, select);
				}
			}
		}

		private void UnSelectAllNodes(TreeNodeCollection nOdes)
		{
			foreach (TreeNode nOde in nOdes)
			{
				if (nOde.BackColor == COLOR_BK_BOTH)
				{
					nOde.BackColor = COLOR_BK_MATCHED;
				}
				else
				{
					nOde.BackColor = COLOR_BK_NONE;
					nOde.ForeColor = COLOR_FR_NONE;
				}
				if (nOde.Nodes.Count > 0)
				{
					// Recurse if child nodes
					UnSelectAllNodes(nOde.Nodes);
				}
			}
		}

		private void HighlightNodes(TreeNodeCollection nOdes, int SavedIndex, bool highlight)
		{
			//string nTag = "";
			SeqPart nID = null;
			foreach (TreeNode nOde in nOdes)
			{
				nID = (SeqPart)nOde.Tag;
				if (nID.SavedIndex == SavedIndex)
				{
					HighlightNode(nOde, highlight);
				}
				if (nOde.Nodes.Count > 0)
				{
					// Recurse if child nodes
					HighlightNodes(nOde.Nodes, SavedIndex, highlight);
				}
			}
		}

			private void UnhighlightAllNodes(TreeNodeCollection nOdes)
		{
			foreach (TreeNode nOde in nOdes)
			{
				if (nOde.BackColor == COLOR_BK_BOTH)
				{
					nOde.BackColor = COLOR_BK_SELECTED;
				}
				else
				{
					nOde.BackColor = COLOR_BK_NONE;
					nOde.ForeColor = COLOR_FR_NONE;
				}
				if (nOde.Nodes.Count > 0)
				{
					// Recurse if child nodes
					UnhighlightAllNodes(nOde.Nodes);
				}
			}
		}

		private void BoldNodes(List<TreeNode> nodeList, bool emBolden)
		{
			//string nTag = "";


			foreach (TreeNode thenOde in nodeList)
			{
					if (emBolden)
					{
						thenOde.NodeFont = new Font(treeSource.Font, FontStyle.Bold);
					}
					else
					{
						thenOde.NodeFont = new Font(treeSource.Font, FontStyle.Regular);
					}
					thenOde.Checked = emBolden;
			}
		}

		private void MapNodes(bool foo, TreeNode theSourceNode, TreeNode theMasterNode, bool map)
		{
			// Is a node Selected on each side?
			if (theSourceNode != null)
			{
				SeqPart sid = (SeqPart)sourceNode.Tag;
				if (masterNode != null)
				{
					SeqPart mid = (SeqPart)masterNode.Tag;
					MapChannels(mid.SavedIndex, sid.SavedIndex, map, true);
				} // end masterNodeannel Node isn't null
			} // end sourceNodeannel Node isn't null
		} // end btnMap_Click

		private void MapChannels(int theMasterSI, int theSourceSI, bool map, bool andChildren)
		{
			// Are we mapping or unmapping?
			if (map)
			{
				// Is the master channel already mapped to a different source?
				//   Note: A source can map to multiple masters.
				//     A master cannot map to more than one source.
				//       Therefore, mappings list is indexed by the Master SavedIndex
				if (MtoS[theMasterSI] != theSourceSI)
				{
					if (StoM[theSourceSI].Count > 0)
					{
						for (int i = 0; i < StoM[theSourceSI].Count; i++)
						{
							if (StoM[theSourceSI][i] == theMasterSI)
							{
								StoM[theSourceSI].RemoveAt(i);
								mappingCount--;
							}
						}
						if (StoM[theSourceSI].Count == 0)
						{
							BoldNodes(sourceNodesSI[theSourceSI], false);
						}
					}
					MtoS[theMasterSI] = theSourceSI;
					SeqPart mid = seqMaster.Children.bySavedIndex[theMasterSI];
					mid.AltSavedIndex = theSourceSI;
					StoM[theSourceSI].Add(theMasterSI);
					mappingCount++;
					BoldNodes(sourceNodesSI[theSourceSI], true);
					BoldNodes(masterNodesSI[theMasterSI], true);

					if (seqSource.Children.bySavedIndex[theSourceSI].TableType == TableType.ChannelGroup)
					{
						if (andChildren)
						{
							ChannelGroup scg = (ChannelGroup)seqSource.Children.bySavedIndex[theSourceSI];
							ChannelGroup mcg = (ChannelGroup)seqMaster.Children.bySavedIndex[theMasterSI];
							if (scg.Children.Items.Count == mcg.Children.Items.Count)
							{
								for (int i = 0; i < scg.Children.Items.Count; i++)
								{
									int sgsi = scg.Children.Items[i].SavedIndex;
									int mgsi = mcg.Children.Items[i].SavedIndex;
									MapChannels(mgsi, sgsi, map, andChildren);
								}
							}
						}
					}
					if (seqSource.Children.bySavedIndex[theSourceSI].TableType == TableType.Track)
					{
						if (andChildren)
						{
							Track str = (Track)seqSource.Children.bySavedIndex[theSourceSI];
							Track mtr = (Track)seqMaster.Children.bySavedIndex[theMasterSI];
							if (str.Children.Items.Count == mtr.Children.Items.Count)
							{
								for (int i = 0; i < str.Children.Items.Count; i++)
								{
									MapChannels(mtr.Children.Items[i].SavedIndex, str.Children.Items[i].SavedIndex, map, andChildren);
								}
							}
						}
					}
					if (seqSource.Children.bySavedIndex[theSourceSI].TableType == TableType.RGBchannel)
					{
						RGBchannel srgb = (RGBchannel)seqSource.Children.bySavedIndex[theSourceSI];
						RGBchannel mrgb = (RGBchannel)seqMaster.Children.bySavedIndex[theMasterSI];
						MapChannels(mrgb.redChannel.SavedIndex, srgb.redChannel.SavedIndex, map, true);
						MapChannels(mrgb.grnChannel.SavedIndex, srgb.grnChannel.SavedIndex, map, true);
						MapChannels(mrgb.bluChannel.SavedIndex, srgb.bluChannel.SavedIndex, map, true);
					}
					btnMap.Enabled = !map;
					mnuMap.Enabled = !map;
					btnUnmap.Enabled = map;
					btnUnmap.Enabled = map;
				} // end not already mapped
			} // end if map

			else //! UnMap
			{
				if (MtoS[theMasterSI] == theSourceSI)
				{
					if (StoM[theSourceSI].Count > 0)
					{
						for (int i = 0; i < StoM[theSourceSI].Count; i++)
						{
							if (StoM[theSourceSI][i] == theMasterSI)
							{
								StoM[theSourceSI].RemoveAt(i);
								masterID.AltSavedIndex = utils.UNDEFINED;
								MtoS[theMasterSI] = utils.UNDEFINED;
								BoldNodes(masterNodesSI[theMasterSI], false);
								mappingCount--;
							}
						}
					}
					if (seqSource.Children.bySavedIndex[theSourceSI].TableType == TableType.ChannelGroup)
					{
						if (andChildren)
						{
							ChannelGroup scg = (ChannelGroup)seqSource.Children.bySavedIndex[theSourceSI];
							ChannelGroup mcg = (ChannelGroup)seqMaster.Children.bySavedIndex[theMasterSI];
							if (scg.Children.Items.Count == mcg.Children.Items.Count)
							{
								for (int i = 0; i < scg.Children.Items.Count; i++)
								{
									MapChannels(mcg.Children.Items[i].SavedIndex, scg.Children.Items[i].SavedIndex, map, andChildren);
								}
							}

						}
					}
					if (seqSource.Children.bySavedIndex[theSourceSI].TableType == TableType.Track)
					{
						if (andChildren)
						{
							Track str = (Track)seqSource.Children.bySavedIndex[theSourceSI];
							Track mtr = (Track)seqMaster.Children.bySavedIndex[theMasterSI];
							if (str.Children.Items.Count == mtr.Children.Items.Count)
							{
								for (int i = 0; i < str.Children.Items.Count; i++)
								{
									MapChannels(mtr.Children.Items[i].SavedIndex, str.Children.Items[i].SavedIndex, map, andChildren);
								}
							}
						}
					}
					if (seqSource.Children.bySavedIndex[theSourceSI].TableType == TableType.RGBchannel)
					{
						RGBchannel srgb = (RGBchannel)seqSource.Children.bySavedIndex[theSourceSI];
						RGBchannel mrgb = (RGBchannel)seqMaster.Children.bySavedIndex[theMasterSI];
						MapChannels(mrgb.redChannel.SavedIndex, srgb.redChannel.SavedIndex, map, true);
						MapChannels(mrgb.grnChannel.SavedIndex, srgb.grnChannel.SavedIndex, map, true);
						MapChannels(mrgb.bluChannel.SavedIndex, srgb.bluChannel.SavedIndex, map, true);
					}

					if (StoM[theSourceSI].Count == 0)
					{
						BoldNodes(sourceNodesSI[theSourceSI], false);
					}
					btnMap.Enabled = !map;
					mnuMap.Enabled = !map;
					btnUnmap.Enabled = map;
					mnuUnmap.Enabled = map;
				} // end they are mapped
			} // end map or unmap
			bool e = false;
			if (mappingCount > 0) e = true;
			btnSummary.Enabled = e;
			mnuSummary.Enabled = e;
			btnSaveMap.Enabled = e;
			mnuSaveNewMap.Enabled = e;
			btnSaveNewSeq.Enabled = e;
			mnuSaveNewSequence.Enabled = e;

		}

		private int addElement(ref int[] numbers)
		{
			int newIdx = utils.UNDEFINED;

			if (numbers == null)
			{
				Array.Resize(ref numbers, 1);
				newIdx = 0;
			}
			else
			{
				int l = numbers.Length;
				Array.Resize(ref numbers, l + 1);
				newIdx = l;
			}

			return newIdx;
		}

		private int removeElement(ref int[] numbers, int index)
		{
			int l = numbers.Length;
			if (index < l)
			{
				l--;
				if (index < (l))
				{
					for (int i = index; i < l; i++)
					{
						numbers[i] = numbers[i + 1];
					}
				}
			}
			if (l == 0)
			{
				numbers = null;
			}
			else
			{
				Array.Resize(ref numbers, l);
			}

			return l;
		}

		private int FindElement(ref int[] numbers, int SID)
		{
			int found = utils.UNDEFINED;
			for (int i = 0; i < numbers.Length; i++)
			{
				if (numbers[i] == SID)
				{
					found = i;
					break;
				}
			}
			return found;
		}



		private void HighlightNodes(bool master, int SID)
		{
			if (master)
			{
				foreach(TreeNode nOde in masterNodesSI[SID])
				{
					HighlightNode(nOde, true);
				}
			}
			else
			{
				foreach(TreeNode nOde in sourceNodesSI[SID])
				{
					HighlightNode(nOde, true);
				}
			}
		}

		private void btnUnmap_Click(object sender, EventArgs e)
		{
			// The button should not have even been enabled if the 2 Channels are not alreaDY mapped ... but--
			// Verify it anyway!

			// Is a node Selected on each side?
			if (sourceNode != null)
			{
				if (masterNode != null)
				{
					// Types match?

					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.Channel)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.Channel)
						{
							MapChannels(masterSI, sourceSI, false, true);
							dirtyMap = true;
							btnSaveMap.Enabled = dirtyMap;
							mnuSaveNewMap.Enabled = dirtyMap;
						}
						else
						{
							statMsg = Resources.MSG_MapRegularToRegular;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.RGBchannel)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.RGBchannel)
						{
							MapChannels(masterSI, sourceSI, false, true);
							dirtyMap = true;
							btnSaveMap.Enabled = dirtyMap;
							mnuSaveNewMap.Enabled = dirtyMap;
						}
						else
						{
							statMsg = Resources.MSG_MapRGBtoRGB;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.ChannelGroup)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.ChannelGroup)
						{
							MapChannels(masterSI, sourceSI, false, true);
							dirtyMap = true;
							btnSaveMap.Enabled = dirtyMap;
							mnuSaveNewMap.Enabled = dirtyMap;
						}
						else
						{
							statMsg = Resources.MSG_GroupToGroup;
							StatusMessage(statMsg);
							System.Media.SystemSounds.Beep.Play();
						}
					}
					if (seqSource.Children.bySavedIndex[sourceSI].TableType == TableType.Track)
					{
						statMsg = Resources.MSG_Tracks;
						StatusMessage(statMsg);
						System.Media.SystemSounds.Beep.Play();
					}
					if (seqMaster.Children.bySavedIndex[masterSI].TableType == TableType.Track)
					{
						statMsg = Resources.MSG_Tracks;
						StatusMessage(statMsg);
						System.Media.SystemSounds.Beep.Play();
					}
				}
				else
				{
					System.Media.SystemSounds.Beep.Play();
				}
			}
			else
			{
				System.Media.SystemSounds.Beep.Play();
			}

		}


		private void StatusMessage(string message)
		{
			// For now at least... I think I'm gonna use this just to show WHY the 'Map' button is not enabled


			lblMessage.Text = message;
			lblMessage.Visible = (message.Length > 0);
			lblMessage.Left = (this.Width - lblMessage.ClientSize.Width) / 2;

		}

		private void LogMessage(string message)
		{
			//TODO: This
		}

		private void frmRemapper_Shown(object sender, EventArgs e)
		{ }

		private void FirstShow()
		{
			string msg;
			DialogResult dr;

			ProcessCommandLine();
			if (batch_fileCount < 1)
			{
				if (File.Exists(masterFile))
				{
					msg = "Load last Master Channel Config file: '" + Path.GetFileName(masterFile) + "'?";
					dr = MessageBox.Show(this, msg, "Load Last Channel Config?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
					//dr = DialogResult.Yes; //! For Testing
					if (dr == DialogResult.Yes)
					{
						LoadMasterFile(masterFile);
					}
				}
				if (File.Exists(sourceFile))
				{
					msg = "Load last used sequence: '" + Path.GetFileName(sourceFile) + "'?";
					dr = MessageBox.Show(this, msg, "Load Last File?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
					//dr = DialogResult.Yes; //! For Testing
					if (dr == DialogResult.Yes)
					{
						//seqSource.ReadSequenceFile(sourceFile);
						LoadSourceFile(sourceFile);
						utils.FillChannels(treeSource, seqSource, sourceNodesSI, false, false);
						// Is a master also already loaded?
					}
				} // end last sequence file exists
					//! Remarked for Testing
				AskToMap();
			}
		} // end form shown event

		private void AskToMap()
		{
			string msg = "";
			DialogResult dr;

			if (seqMaster.Channels.Count > 0)
			{
				if (seqSource.Channels.Count > 0)
				{
					if (File.Exists(mapFile))
					{
						mapFileLineCount = GetMapFileLineCount(mapFile);
						if (mapFileLineCount > 2)
						{
							msg = "Load and Apply last Map file: '" + Path.GetFileName(mapFile) + "'?";
							dr = MessageBox.Show(this, msg, "Load & Apply last Map?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
							if (dr == DialogResult.Yes)
							{
								ReadApplyMapV2(mapFile);
							} // end load/apply last map
						} // end map file line count
					} // end map file exists
	
					if (mappingCount < 1)
					{
						msg = "Perform an Auto Map?";
						dr = MessageBox.Show(this, msg, "Perform Auto Map?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
						if (dr == DialogResult.Yes)
						{
							AutoMap();
						} // end automap
					} // end mappings exists
				} // end source is loaded
			} // end master is loaded
		} // end AskToMap

		private void btnSummary_Click(object sender, EventArgs e)
		{
			ImBusy(true);
			frmMapList dlgList = new frmMapList(seqSource, seqMaster, StoM, MtoS, imlTreeIcons);
			//dlgList.Left = this.Left + 4;
			//dlgList.Top = this.Top + 25;
			Point l = new Point(4, 25);
			dlgList.Location = l;

			dlgList.ShowDialog(this);
			//DialogResult result = dlgList.ShowDialog();
			ImBusy(false);
		}

		private void frmRemapper_FormClosing(object sender, FormClosingEventArgs e)
		{
			SaveFormPosition();
		}

		private void btnSaveMap_Click(object sender, EventArgs e)
		{
			SaveMap();
		}


		private void SaveMap()
		{
			dlgSaveFile.DefaultExt = "ChMap";
			dlgSaveFile.Filter = "Channel Maps|*.ChMap|All Files|*.*";
			dlgSaveFile.FilterIndex = 0;
			string initDir = SeqFolder + "Channel Maps\\";
			string initFile = "";
			if (mapFile.Length > 4)
			{
				string pth = Path.GetFullPath(mapFile);
				if (Directory.Exists(pth))
				{
					initDir = pth;
				}
				if (File.Exists(mapFile))
				{
					initFile = Path.GetFileName(mapFile);
				}
			}
			dlgSaveFile.FileName = initFile;
			dlgSaveFile.InitialDirectory = initDir;
			dlgSaveFile.OverwritePrompt = true;
			dlgSaveFile.CheckPathExists = true;
			dlgSaveFile.Title = "Save Channel Map As...";

			DialogResult dr = dlgSaveFile.ShowDialog();
			if (dr == DialogResult.OK)
			{

				string mapTemp = System.IO.Path.GetTempPath();
				mapTemp += Path.GetFileName(dlgSaveFile.FileName);
				int mapErr = SaveMapV2(mapTemp);
				if (mapErr == 0)
				{
					mapFile = dlgSaveFile.FileName;
					if (File.Exists(mapFile))
					{
						//TODO: Add Exception Catch
						File.Delete(mapFile);
					}
					File.Copy(mapTemp, mapFile);
					File.Delete(mapTemp);
					dirtyMap = false;
					//btnSaveMap.Enabled = dirtyMap;
					txtMappingFile.Text = Path.GetFileName(mapFile);
				} // end no errors saving map
			} // end dialog result = OK
		} // end btnSaveMap Click event
		private void btnLoadMap_Click(object sender, EventArgs e)
		{
			BrowseForMap();
		}

		private void BrowseForMap()
		{ 
			dlgOpenFile.DefaultExt = "ChMap";
			dlgOpenFile.Filter = "Channel Maps|*.ChMap";
			dlgOpenFile.FilterIndex = 0;
			string initDir = SeqFolder + "Channel Maps\\";
			string initFile = "";
			if (mapFile.Length > 4)
			{
				string pth = Path.GetFullPath(mapFile);
				if (Directory.Exists(pth))
				{
					initDir = pth;
				}
				if (File.Exists(mapFile))
				{
					initFile = Path.GetFileName(mapFile);
				}
			}
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Title = "Load-Apply Channel Map..";

			DialogResult dr = dlgOpenFile.ShowDialog();
			if (dr == DialogResult.OK)
			{
				mapFile = dlgOpenFile.FileName;
				txtMappingFile.Text = Path.GetFileName(mapFile);
				Properties.Settings.Default.LastMapFile = mapFile;
				Properties.Settings.Default.Save();
				if (seqMaster.Children.Items.Count > 1)
				{
					if (seqSource.Children.Items.Count > 1)
					{
						ReadApplyMapV2(dlgOpenFile.FileName);
					}
				}
				dirtyMap = false;
				btnSaveMap.Enabled = dirtyMap;
				mnuSaveNewMap.Enabled = dirtyMap;
			} // end dialog result = OK
		} // end btnLoadMap Click event

		private int SaveMapV1(string fileName)
		{
			int ret = 0;

			int lineCount = 0;
			StreamWriter writer = new StreamWriter(fileName);
			string lineOut = ""; // line to be written out, gets modified if necessary
													 //int pos1 = utils.UNDEFINED; // positions of certain key text in the line

			lineOut = masterFile;
			writer.WriteLine(lineOut);
			lineOut = sourceFile;
			writer.WriteLine(lineOut);

			for (int i=0; i<MtoS.Length; i++)
			{
				if (MtoS[i] > utils.UNDEFINED)
				{
					SeqPart mid = seqMaster.Children.bySavedIndex[i];
					SeqPart sid = seqSource.Children.bySavedIndex[MtoS[i]];
					lineOut = MapLine(mid) + utils.DELIM2;
					lineOut += MapLine(sid);
					writer.WriteLine(lineOut);
				}
			}
			writer.Close();
			return ret;
		} // end SaveMap

		private int SaveMapV2(string fileName)
		{




			int ret = 0;
			string nowtime = DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt");
			int lineCount = 0;
			StreamWriter writer = new StreamWriter(fileName);
			string lineOut = ""; // line to be written out, gets modified if necessary
													 //int pos1 = utils.UNDEFINED; // positions of certain key text in the line

			lineOut = xmlInfo;
			writer.WriteLine(lineOut);
			lineOut = utils.STTBL + TABLEchMap;
			lineOut += Info.FIELDsaveFileVersion + utils.FIELDEQ + seqMaster.info.saveFileVersion + utils.ENDQT;
			lineOut += Info.FIELDcreatedAt + utils.FIELDEQ + nowtime + utils.ENDQT + utils.ENDTBL;
			writer.WriteLine(lineOut);

			lineOut = utils.LEVEL1 + utils.STTBL + TABLEfiles + utils.ENDTBL;
			writer.WriteLine(lineOut);
			lineOut = utils.LEVEL2 + utils.STFLD + FIELDmasterFile;
			lineOut += utils.FIELDname + utils.FIELDEQ + seqMaster.info.filename + utils.ENDQT + utils.ENDFLD;
			writer.WriteLine(lineOut);
			lineOut = utils.LEVEL2 + utils.STFLD + FIELDsourceFile;
			lineOut += utils.FIELDname + utils.FIELDEQ + seqSource.info.filename + utils.ENDQT + utils.ENDFLD;
			writer.WriteLine(lineOut);
			lineOut = utils.LEVEL1 + utils.FINTBL + TABLEfiles + utils.ENDTBL;
			writer.WriteLine(lineOut);

			lineOut = utils.LEVEL1 + utils.STTBL + TABLEmappings + utils.ENDTBL;
			writer.WriteLine(lineOut);

			for (int i = 0; i < MtoS.Length; i++)
			{
				if (MtoS[i] > utils.UNDEFINED)
				{
					SeqPart mid = seqMaster.Children.bySavedIndex[i];
					SeqPart sid = seqSource.Children.bySavedIndex[MtoS[i]];

					lineOut = utils.LEVEL2 + utils.STTBL + TABLEchannels + utils.ENDTBL;
					writer.WriteLine(lineOut);

					lineOut = utils.LEVEL3 + utils.STTBL + FIELDmasterChannel;
					lineOut += utils.FIELDname + utils.FIELDEQ + utils.dirtyName(mid.Name) + utils.ENDQT;
					lineOut += utils.FIELDtype + utils.FIELDEQ + SeqEnums.TableTypeName(mid.TableType) + utils.ENDQT;
					lineOut += utils.FIELDsavedIndex + utils.FIELDEQ + mid.SavedIndex + utils.ENDQT + utils.ENDFLD;
					writer.WriteLine(lineOut);

					lineOut = utils.LEVEL3 + utils.STTBL + FIELDsourceChannel;
					lineOut += utils.FIELDname + utils.FIELDEQ + utils.dirtyName(sid.Name) + utils.ENDQT;
					lineOut += utils.FIELDtype + utils.FIELDEQ + SeqEnums.TableTypeName(sid.TableType) + utils.ENDQT;
					lineOut += utils.FIELDsavedIndex + utils.FIELDEQ + sid.SavedIndex + utils.ENDQT + utils.ENDFLD;
					writer.WriteLine(lineOut);

					lineOut = utils.LEVEL2 + utils.FINTBL + TABLEchannels + utils.ENDTBL;
					writer.WriteLine(lineOut);
				}
			}
			lineOut = utils.LEVEL1 + utils.FINTBL + TABLEmappings + utils.ENDTBL;
			writer.WriteLine(lineOut);

			lineOut = utils.FINTBL + TABLEchMap + utils.ENDTBL;
			writer.WriteLine(lineOut);

			writer.Close();
			return ret;
		} // end SaveMap

		private string MapLine(SeqPart part)
		{
			string ret = part.Name + utils.DELIM1;
			ret += part.SavedIndex.ToString() + utils.DELIM1;
			ret += SeqEnums.TableTypeName(part.TableType);
			return ret;
		}


		private string ReadApplyMapV1(string fileName)
		{
			ImBusy(true);
			//int w = pnlStatus.Width;
			//pnlProgress.Width = w;
			//pnlProgress.Size = new Size(w, pnlProgress.Height);
			//pnlStatus.Visible = false;
			//pnlProgress.Visible = true;
			//staStatus.Refresh();
			if (batchMode)
			{
				ShowProgressBars(2);
			}
			else
			{
				ShowProgressBars(1);
			}
			//int mq = seqMaster.Tracks.Count + seqMaster.ChannelGroups.Count + seqMaster.Channels.Count;
			//mq -= seqMaster.RGBchannels.Count * 2;
			//int sq = seqSource.Tracks.Count + seqSource.ChannelGroups.Count + seqSource.Channels.Count;
			//sq -= seqSource.RGBchannels.Count * 2;
			//int qq = mq + sq;
			//pnlProgress.Maximum = qq + 1;
			//int pp = 0;
			int lineCount = 0;
			int lineNum = 0;

			string errMsgs = "";
			string lineIn;
			string[] mapData;
			string[] sides;
			string sourceName = "";
			string masterName = "";
			string temp = "";
			//int tempNum;
			int[] foundChannels;
			int sourceSI = utils.UNDEFINED;
			int masterSI = utils.UNDEFINED;
			TableType sourceType = TableType.None;
			TableType masterType = TableType.None;
			SeqPart masterID = null;
			SeqPart sourceID = null;
			SeqPart foundID = null;
			string mfile = "";
			string sfile = "";
			long finalAlgorithms = Properties.Settings.Default.FuzzyFinalAlgorithms;
			double minPreMatch = Properties.Settings.Default.FuzzyMinPrematch;
			double minFinalMatch = Properties.Settings.Default.FuzzyMinFinal;
			long preAlgorithm = Properties.Settings.Default.FuzzyPrematchAlgorithm;


			logFile1 = logHomeDir + "Apply" + batch_fileNumber.ToString() + ".log";
			logWriter1 = new StreamWriter(logFile1);
			log1Open = true;
			logMsg = "Master File: " + seqMaster.info.filename;
			logWriter1.WriteLine(logMsg);
			logMsg = "Source File: " + seqSource.info.filename;
			logWriter1.WriteLine(logMsg);
			logMsg = "Map File: " + fileName;
			logWriter1.WriteLine(logMsg);



			// First Pass, just get line count so we can update the progress bar accordingly
			StreamReader reader = new StreamReader(fileName);
			while ((lineIn = reader.ReadLine()) != null)
			{
				lineCount++;
			}
			reader.Close();
			//pnlProgress.Maximum = lineCount;
			prgBarInner.Maximum = lineCount * 10;
			if (batchMode)
			{
				prgBarOuter.Maximum = lineCount * 10 * batch_fileCount;
			}


			// Second Pass, look for EXACT matches only
			mappingCount = 0;
			reader = new StreamReader(fileName);

			if (!reader.EndOfStream)
			{
				mfile = reader.ReadLine();
			}
			if (!reader.EndOfStream)
			{
				sfile = reader.ReadLine();
			}

			while ((lineIn = reader.ReadLine()) != null)
			{
			
				sides = lineIn.Split(utils.DELIM2);

				mapData = sides[0].Split(utils.DELIM1);
				if (mapData.Length == 3)
				{
					masterName = mapData[0];
					lblMessage.Text = "Map \"" + masterName + "\" to...";
					pnlMessage.Refresh();
					masterSI = Int32.Parse(mapData[1]);
					masterType = SeqEnums.enumTableType(mapData[2]);

					if (seqMaster.Children.bySavedIndex[masterSI].TableType == masterType)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].Name.CompareTo(masterName) == 0)
						{
							// Got it!
							masterID = seqMaster.Children.bySavedIndex[masterSI];
						}
						else
						{
							// Not it!
							masterSI = utils.UNDEFINED;
						}
					}
					else
					{
						// Not it!
						masterSI = utils.UNDEFINED;
					}

					// Got it?
					if (masterSI < 0)
					{
						// Search for it by name, exact matches only, no fuzzy find
						foundID = seqMaster.Children.FindByName(masterName, masterType);
						if (foundID != null)
						{
							masterSI = foundID.SavedIndex;
						}
					}
					if (masterSI < 0)
					{
						logMsg = masterName + " not found in Master.";
						Console.WriteLine(logMsg);
						logWriter1.WriteLine(logMsg);
					}

					// Got it yet?
					if (masterSI > utils.UNDEFINED)
					{
						mapData = sides[1].Split(utils.DELIM1);
						if (mapData.Length == 3)
						{
							sourceName = mapData[0];
							lblMessage.Text = masterName + " to " + sourceName;
							prgBarInner.CustomText = lblMessage.Text;
							pnlMessage.Refresh();
							sourceSI = Int32.Parse(mapData[1]);
							sourceType = SeqEnums.enumTableType(mapData[2]);

							if (seqSource.Children.bySavedIndex[sourceSI].TableType == sourceType)
							{
								if (seqSource.Children.bySavedIndex[sourceSI].Name.CompareTo(sourceName) == 0)
								{
									// Got it!
									sourceID = seqSource.Children.bySavedIndex[sourceSI];
								}
								else
								{
									// Not it!
									sourceSI = utils.UNDEFINED;
								}
							}
							else
							{
								// Not it!
								sourceSI = utils.UNDEFINED;
							}

							// Got it?
							if (sourceSI < 0)
							{
								//try to find exact match name
								foundID = seqSource.Children.FindByName(sourceName, sourceType);
								if (foundID != null)
								{
									sourceSI = foundID.SavedIndex;
								}
							}
							if (sourceSI < 0)
							{
								logMsg = sourceName + " not found in Source.";
								Console.WriteLine(logMsg);
								logWriter1.WriteLine(logMsg);
							}

							// Got it yet?
							if (sourceSI > utils.UNDEFINED)
							{
								logMsg = "Exact Matched " + masterName + " to " + sourceName;
								Console.WriteLine(logMsg);
								logWriter1.WriteLine(logMsg);
								MapChannels(masterSI, sourceSI, true, false);
								seqMaster.Children.bySavedIndex[masterSI].Selected = true;
								seqSource.Children.bySavedIndex[sourceSI].Selected = true;
							}
						}
					}
				} // if line split into 3 elements
				lineNum++;
				//pnlProgress.Value = lineNum;
				prgBarInner.Value = lineNum;
				//staStatus.Refresh();
				prgBarInner.Refresh();
				if (batchMode)
				{
					int v = batch_fileNumber * lineCount * 10;
					v += lineNum;
					prgBarOuter.Value = v;
					prgBarOuter.Refresh();
				}
			} // while line read
			reader.Close();

			// Third pass, attempt to fuzzy find anything not already matched
			reader = new StreamReader(fileName);

			if (!reader.EndOfStream)
			{
				mfile = reader.ReadLine();
			}
			if (!reader.EndOfStream)
			{
				sfile = reader.ReadLine();
			}

			lineNum = 0;
			while ((lineIn = reader.ReadLine()) != null)
			{

				sides = lineIn.Split(utils.DELIM2);

				mapData = sides[0].Split(utils.DELIM1);
				if (mapData.Length == 3)
				{
					masterName = mapData[0];
					lblMessage.Text = "Map \"" + masterName + "\" to...";
					pnlMessage.Refresh();
					masterSI = Int32.Parse(mapData[1]);
					masterType = SeqEnums.enumTableType(mapData[2]);

					if (!seqMaster.Children.bySavedIndex[masterSI].Selected)
					{
						if (seqMaster.Children.bySavedIndex[masterSI].TableType == masterType)
						{
							// Search for it again by name, this time use fuzzy find
							logMsg = "Fuzzy searching Master for ";
							logMsg += sourceName;
							Console.WriteLine(logMsg);
							logWriter1.WriteLine(logMsg);
							
							foundID = seqMaster.Children.FindByName(masterName, masterType, preAlgorithm, minPreMatch, finalAlgorithms, minFinalMatch, true);
							if (foundID != null)
							{
								masterSI = foundID.SavedIndex;
								masterName = foundID.Name;
							}

							// Got it yet?
							if (masterSI > utils.UNDEFINED)
							{
								mapData = sides[1].Split(utils.DELIM1);
								if (mapData.Length == 3)
								{
									sourceName = mapData[0];
									lblMessage.Text = masterName + " to " + sourceName;
									prgBarInner.CustomText = lblMessage.Text;
									pnlMessage.Refresh();
									sourceSI = Int32.Parse(mapData[1]);
									sourceType = SeqEnums.enumTableType(mapData[2]);

									if (seqSource.Children.bySavedIndex[sourceSI].TableType == sourceType)
									{
										if (!seqSource.Children.bySavedIndex[sourceSI].Selected)
										{
											//try to find it again by name and this time use fuzzy matching
											logMsg = "Fuzzy searching Source for ";
											logMsg += sourceName;
											Console.WriteLine(logMsg);
											logWriter1.WriteLine(logMsg);
											foundID = seqSource.Children.FindByName(sourceName, sourceType, preAlgorithm, minPreMatch, finalAlgorithms, minFinalMatch, true);
											if (foundID != null)
											{
												sourceSI = foundID.SavedIndex;
											}
										} // if not Selected

										// Got it yet?
										if (sourceSI > utils.UNDEFINED)
										{
											logMsg = "Fuzzy Matched " + masterName + " to " + sourceName;
											Console.WriteLine(logMsg);
											logWriter1.WriteLine(logMsg);
											MapChannels(masterSI, sourceSI, true, false);
											seqMaster.Children.bySavedIndex[masterSI].Selected = true;
											seqSource.Children.bySavedIndex[sourceSI].Selected = true;
										}
									} // if source type matchies
								} // if source section split into 3 elements
							} // if master was suzzy found
						} // if master SI not Selected
					} // if master type matches
				} // if master section split into 3 elements

				lineNum++;
				//pnlProgress.Value = lineNum;
				prgBarInner.Value = lineCount + lineNum * 9;
				//staStatus.Refresh();
				prgBarInner.Refresh();
				if (batchMode)
				{
					int v = batch_fileNumber * lineCount * 10;
					v += (lineCount + lineNum * 9);
					prgBarOuter.Value = v;
					prgBarOuter.Refresh();
				}

			} // while line read
			reader.Close();
			// end third pass



			//pnlProgress.Visible = false;
			//pnlStatus.Visible = true;

			if (!batchMode)
			{
				ShowProgressBars(0);
				ImBusy(false);
			}

			logWriter1.Close();
			System.Diagnostics.Process.Start(logFile1);



			return errMsgs;
		} // end ReadApplyMap

		private string ReadApplyMapV2(string fileName)
		{
			ImBusy(true);
			//int w = pnlStatus.Width;
			//pnlProgress.Width = w;
			//pnlProgress.Size = new Size(w, pnlProgress.Height);
			//pnlStatus.Visible = false;
			//pnlProgress.Visible = true;
			//staStatus.Refresh();
			if (batchMode)
			{
				ShowProgressBars(2);
			}
			else
			{
				ShowProgressBars(1);
			}
			//int mq = seqMaster.Tracks.Count + seqMaster.ChannelGroups.Count + seqMaster.Channels.Count;
			//mq -= seqMaster.RGBchannels.Count * 2;
			//int sq = seqSource.Tracks.Count + seqSource.ChannelGroups.Count + seqSource.Channels.Count;
			//sq -= seqSource.RGBchannels.Count * 2;
			//int qq = mq + sq;
			//pnlProgress.Maximum = qq + 1;
			//int pp = 0;
			int lineCount = 0;
			int lineNum = 0;

			string errMsgs = "";
			string lineIn;
			string[] mapData;
			string[] sides;
			string sourceName = "";
			string masterName = "";
			string temp = "";
			//int tempNum;
			int[] foundChannels;
			int sourceSI = utils.UNDEFINED;
			int masterSI = utils.UNDEFINED;
			TableType sourceType = TableType.None;
			TableType masterType = TableType.None;
			SeqPart masterID = null;
			SeqPart sourceID = null;
			SeqPart foundID = null;
			string mfile = "";
			string sfile = "";
			long finalAlgorithms = Properties.Settings.Default.FuzzyFinalAlgorithms;
			double minPreMatch = Properties.Settings.Default.FuzzyMinPrematch;
			double minFinalMatch = Properties.Settings.Default.FuzzyMinFinal;
			long preAlgorithm = Properties.Settings.Default.FuzzyPrematchAlgorithm;


			logFile1 = logHomeDir + "Apply" + batch_fileNumber.ToString() + ".log";
			logWriter1 = new StreamWriter(logFile1);
			log1Open = true;
			logMsg = "Master File: " + seqMaster.info.filename;
			logWriter1.WriteLine(logMsg);
			logMsg = "Source File: " + seqSource.info.filename;
			logWriter1.WriteLine(logMsg);
			logMsg = "Map File: " + fileName;
			logWriter1.WriteLine(logMsg);

			mappingCount = 0;
			int li = 0;
			int errorStatus = 0;


			// First Pass, just make sure it's valid and get line count so we can update the progress bar accordingly
			StreamReader reader = new StreamReader(fileName);
			if (!reader.EndOfStream)
			{
				lineIn = reader.ReadLine();

				// Sanity Check #2, is it an XML file?
				li = lineIn.Substring(0, 6).CompareTo("<?xml ");
				if (li != 0)
				{
					errorStatus = 101;
				}
				else
				{
					//xmlInfo = lineIn;
					// Sanity Check #1B, does it have at least 2 lines?
					if (!reader.EndOfStream)
					{
						lineIn = reader.ReadLine();
						// Sanity Check #3, is it a sequence?
						li = lineIn.IndexOf(TABLEchMap);
						if (li != 1)
						{
							errorStatus = 102;
						}
						else
						{
							int sfv = utils.getKeyValue(lineIn, Info.FIELDsaveFileVersion);
									// Sanity Checks #4A and 4B, does it have a 'SaveFileVersion' and is it '14'
									//   (SaveFileVersion="14" means it cane from LOR Sequence Editor ver 4.x)
							if (sfv != 14)
							{
								errorStatus = 114;
							}
							else
							{
								lineCount = 2;
								while ((lineIn = reader.ReadLine()) != null)
								{
									lineCount++;
								} // end while lines remain, counting them
							} // saveVersion = 14
						} // Its a channelMap
					} // It has at least 2 lines
				} //its in XML format
			} // it has at least 1 line
			reader.Close();

			if ((errorStatus == 0) && ( lineCount> 12))
			{
				// All sanity checks passed

				//pnlProgress.Maximum = lineCount;
				prgBarInner.Maximum = lineCount * 10;
				if (batchMode)
				{
					prgBarOuter.Maximum = lineCount * 10 * batch_fileCount;
				}


				// Second Pass, look for EXACT matches only
				reader = new StreamReader(fileName);
				// Read in and then ignore the first 8 lines
				//   xml, channelMap, files, mappings...
				for (int n=0; n<7;  n++)
				{
					lineIn = reader.ReadLine();
				}
				lineNum = 7;

				// * PARSE LINES
				while ((lineIn = reader.ReadLine()) != null)
				{
					lineNum++;
					// Line just read should be "    <channels>"
					li = lineIn.IndexOf(utils.STTBL + TABLEchannels + utils.ENDTBL);
					if (li > 0)
					{
						if (!reader.EndOfStream)
						{
							// Next line is the Master Channel
							lineIn = reader.ReadLine();
							lineNum++;
							li = lineIn.IndexOf(FIELDmasterChannel);
							if (li > 0)
							{
								masterName = utils.cleanName(utils.getKeyWord(lineIn, utils.FIELDname));
								lblMessage.Text = "Map \"" + masterName + "\" to...";
								pnlMessage.Refresh();
								masterSI = utils.getKeyValue(lineIn, utils.FIELDsavedIndex);
								masterType = SeqEnums.enumTableType(utils.getKeyWord(lineIn, utils.FIELDtype));

								if (seqMaster.Children.bySavedIndex[masterSI].TableType == masterType)
								{
									if (seqMaster.Children.bySavedIndex[masterSI].Name.CompareTo(masterName) == 0)
									{
										// Got it!
										masterID = seqMaster.Children.bySavedIndex[masterSI];
									}
									else
									{
										// Not it!
										masterSI = utils.UNDEFINED;
									}
								}
								else
								{
									// Not it!
									masterSI = utils.UNDEFINED;
								}

								// Got it?
								if (masterSI < 0)
								{
									// Search for it by name, exact matches only, no fuzzy find
									foundID = seqMaster.Children.FindByName(masterName, masterType);
									if (foundID != null)
									{
										masterSI = foundID.SavedIndex;
									}
								}
								if (masterSI < 0)
								{
									logMsg = masterName + " not found in Master.";
									Console.WriteLine(logMsg);
									logWriter1.WriteLine(logMsg);
								}

								// Got it yet?
								if (masterSI > utils.UNDEFINED)
								{
									// Next line (let's assume its there) is the Source Channel
									if (!reader.EndOfStream)
									{
										// Next line is the Source Channel
										lineIn = reader.ReadLine();
										lineNum++;
										li = lineIn.IndexOf(FIELDsourceChannel);
										if (li > 0)
										{
											sourceName = utils.cleanName(utils.getKeyWord(lineIn, utils.FIELDname));
											lblMessage.Text = masterName + " to " + sourceName;
											prgBarInner.CustomText = lblMessage.Text;
											pnlMessage.Refresh();
											sourceSI = utils.getKeyValue(lineIn, utils.FIELDsavedIndex);
											sourceType = SeqEnums.enumTableType(utils.getKeyWord(lineIn, utils.FIELDtype));

											if (seqSource.Children.bySavedIndex[sourceSI].TableType == sourceType)
											{
												if (seqSource.Children.bySavedIndex[sourceSI].Name.CompareTo(sourceName) == 0)
												{
													// Got it!
													sourceID = seqSource.Children.bySavedIndex[sourceSI];
												}
												else
												{
													// Not it!
													sourceSI = utils.UNDEFINED;
												}
											}
											else
											{
												// Not it!
												sourceSI = utils.UNDEFINED;
											}

											// Got it?
											if (sourceSI < 0)
											{
												//try to find exact match name
												foundID = seqSource.Children.FindByName(sourceName, sourceType);
												if (foundID != null)
												{
													sourceSI = foundID.SavedIndex;
												}
											}
											if (sourceSI < 0)
											{
												logMsg = sourceName + " not found in Source.";
												Console.WriteLine(logMsg);
												logWriter1.WriteLine(logMsg);
											}

											// Got it yet?
											if (sourceSI > utils.UNDEFINED)
											{
												logMsg = "Exact Matched " + masterName + " to " + sourceName;
												Console.WriteLine(logMsg);
												logWriter1.WriteLine(logMsg);
												MapChannels(masterSI, sourceSI, true, false);
												seqMaster.Children.bySavedIndex[masterSI].Selected = true;
												seqSource.Children.bySavedIndex[sourceSI].Selected = true;
											} // If we still didn't get it
											//pnlProgress.Value = lineNum;
										} // if this is the source line
									} // if another line waiting
								} // if got the Master Channel
							} // if this is the Master line
						} // if another line waiting
					} // it channels table
					prgBarInner.Value = lineNum;
					//staStatus.Refresh();
					prgBarInner.Refresh();
					if (batchMode)
					{
						int v = batch_fileNumber * lineCount * 10;
						v += lineNum;
						prgBarOuter.Value = v;
						prgBarOuter.Refresh();
					}
				} // while lines remain
				reader.Close();

				// Third pass, attempt to fuzzy find anything not already matched
				reader = new StreamReader(fileName);
				// Read in and then ignore the first 8 lines
				//   xml, channelMap, files, mappings...
				for (int n = 0; n < 7; n++)
				{
					lineIn = reader.ReadLine();
				}
				lineNum = 7;

				// * PARSE LINES
				while ((lineIn = reader.ReadLine()) != null)
				{
					lineNum++;
					// Line just read should be "    <channels>"
					li = lineIn.IndexOf(utils.STTBL + TABLEchannels + utils.ENDTBL);
					if (li > 0)
					{
						if (!reader.EndOfStream)
						{
							// Next line is the Master Channel
							lineIn = reader.ReadLine();
							lineNum++;
							li = lineIn.IndexOf(FIELDmasterChannel);
							if (li > 0)
							{
								masterName = utils.cleanName(utils.getKeyWord(lineIn, utils.FIELDname));
								lblMessage.Text = "Map \"" + masterName + "\" to...";
								pnlMessage.Refresh();
								masterSI = utils.getKeyValue(lineIn, utils.FIELDsavedIndex);
								masterType = SeqEnums.enumTableType(utils.getKeyWord(lineIn, utils.FIELDtype));

								if (!seqMaster.Children.bySavedIndex[masterSI].Selected)
								{
									if (seqMaster.Children.bySavedIndex[masterSI].TableType == masterType)
									{
										// Search for it again by name, this time use fuzzy find
										logMsg = "Fuzzy searching Master for ";
										logMsg += sourceName;
										Console.WriteLine(logMsg);
										logWriter1.WriteLine(logMsg);

										foundID = seqMaster.Children.FindByName(masterName, masterType, preAlgorithm, minPreMatch, finalAlgorithms, minFinalMatch, true);
										if (foundID != null)
										{
											masterSI = foundID.SavedIndex;
											masterName = foundID.Name;
										}

										// Got it yet?
										if (masterSI > utils.UNDEFINED)
										{
											// Next line (let's assume its there) is the Source Channel
											if (!reader.EndOfStream)
											{
												// Next line is the Source Channel
												lineIn = reader.ReadLine();
												lineNum++;
												li = lineIn.IndexOf(FIELDsourceChannel);
												if (li > 0)
												{
													sourceName = utils.cleanName(utils.getKeyWord(lineIn, utils.FIELDname));
													lblMessage.Text = masterName + " to " + sourceName;
													prgBarInner.CustomText = lblMessage.Text;
													pnlMessage.Refresh();
													sourceSI = utils.getKeyValue(lineIn, utils.FIELDsavedIndex);
													sourceType = SeqEnums.enumTableType(utils.getKeyWord(lineIn, utils.FIELDtype));

													if (seqSource.Children.bySavedIndex[sourceSI].TableType == sourceType)
													{
														if (!seqSource.Children.bySavedIndex[sourceSI].Selected)
														{
															//try to find it again by name and this time use fuzzy matching
															logMsg = "Fuzzy searching Source for ";
															logMsg += sourceName;
															Console.WriteLine(logMsg);
															logWriter1.WriteLine(logMsg);
															foundID = seqSource.Children.FindByName(sourceName, sourceType, preAlgorithm, minPreMatch, finalAlgorithms, minFinalMatch, true);
															if (foundID != null)
															{
																sourceSI = foundID.SavedIndex;
															}
														} // if not Selected

														// Got it yet?
														if (sourceSI > utils.UNDEFINED)
														{
															logMsg = "Fuzzy Matched " + masterName + " to " + sourceName;
															Console.WriteLine(logMsg);
															logWriter1.WriteLine(logMsg);
															MapChannels(masterSI, sourceSI, true, false);
															seqMaster.Children.bySavedIndex[masterSI].Selected = true;
															seqSource.Children.bySavedIndex[sourceSI].Selected = true;
														}
													} // if source type matchies
												} // if source section line
											} // if lines remain
										} // if got a smaster channel
									} // if master type matches
								} // if master SI not Selected
							} // if line is a master channel
						} // if lines left
					} // if a channel section
						//pnlProgress.Value = lineNum;
					prgBarInner.Value = lineCount + lineNum * 9;
					//staStatus.Refresh();
					prgBarInner.Refresh();
					if (batchMode)
					{
						int v = batch_fileNumber * lineCount * 10;
						v += (lineCount + lineNum * 9);
						prgBarOuter.Value = v;
						prgBarOuter.Refresh();
					}
				} // if lines remain
				reader.Close();
			// end third pass
			} // no error on the first pass

			//pnlProgress.Visible = false;
			//pnlStatus.Visible = true;

			if (!batchMode)
			{
				ShowProgressBars(0);
				ImBusy(false);
			}

			logWriter1.Close();
			System.Diagnostics.Process.Start(logFile1);

			return errMsgs;
		} // end ReadApplyMap

		private TableType xxxxxGetTableType(string tableName)
		{
			TableType ret = TableType.None;
			if (tableName.CompareTo("channel") == 0)
			{
				ret = TableType.Channel;
			}
			else
			{
				if (tableName.CompareTo("rgbChannel") == 0)
				{
					ret = TableType.RGBchannel;
				}
				else
				{
					if (tableName.CompareTo("channelGroup") == 0)
					{
						ret = TableType.ChannelGroup;
					}
					else
					{
						if (tableName.CompareTo("track") == 0)
						{
							ret = TableType.Track;
						}
						else
						{
							if (tableName.CompareTo("timingGrid") == 0)
							{
								ret = TableType.TimingGrid;
							}
						}
					}
				}
			}
			return ret;
		}

		private int[] FindChannelNames(Sequence4 seq, string theName, TableType type)
		// Not just regular Channels, but RGB Channels and Channel Groups too
		// Returns an array of Saved Indexes
		// If one or more exact matches are found, it returns a list of those, and no fuzzy find is performed
		// If no exact matches are found, then perform a fuzzy find and return closest match
		{
			int[] ret = null;
			match[] matches = null;
			int matchCount = 0;

			// Pass 1, look for exact matches
			if (type == TableType.ChannelGroup)
			{
				foreach (ChannelGroup grp in seq.ChannelGroups)
				{
					if (theName.CompareTo(grp.Name) == 0)
					{
						Array.Resize(ref matches, matchCount + 1);
						matches[matchCount].savedIdx = grp.SavedIndex;
						matches[matchCount].type = TableType.ChannelGroup;
						matches[matchCount].itemIdx = grp.Index;
						matches[matchCount].score = 1;
						matchCount++;
					} // match
				} // loop thru Channel Groups
			} // end if type is Channel Group

			if (type == TableType.RGBchannel)
			{
				foreach (RGBchannel rgb in seq.RGBchannels)
				{
					if (theName.CompareTo(rgb.Name) == 0)
					{
						Array.Resize(ref matches, matchCount + 1);
						matches[matchCount].savedIdx = rgb.SavedIndex;
						matches[matchCount].type = TableType.RGBchannel;
						matches[matchCount].itemIdx = rgb.Index;
						matches[matchCount].score = 1;
						matchCount++;
					} // match
				} // loop thru RGB Channels
			} // end if type is RGB Channel

			if (type == TableType.Channel)
			{
				foreach (Channel ch in seq.Channels)
				{
					if (theName.CompareTo(ch.Name) == 0)
					{
						Array.Resize(ref matches, matchCount + 1);
						matches[matchCount].savedIdx = ch.SavedIndex;
						matches[matchCount].type = TableType.Channel;
						matches[matchCount].itemIdx = ch.Index;
						matches[matchCount].score = 1;
						matchCount++;
					} // match
				} // End first pass channel loop
			} // type is regular channel

			// Found any exact matches?
			if (matchCount >0)
			{
				Array.Resize(ref ret, matchCount);
				for (int m = 0; m< matchCount; m++)
				{
					ret[m] = matches[m].savedIdx;
				}
			}
			else
			{
				// No exact match(es) found, perform a fuzzy find
				// Pass 2, for the sake of speed, prequalify matches with a quick simple fuzzy algorithm
				// then run full algorithms later only on those that prequalify
				double score = 0;
				if (type == TableType.ChannelGroup)
				{
					foreach(ChannelGroup grp in seq.ChannelGroups)
					{
						score = theName.LevenshteinDistance(grp.Name);
						if (score > MINSCORE)
						{
							Array.Resize(ref matches, matchCount + 1);
							matches[matchCount].savedIdx = grp.SavedIndex;
							matches[matchCount].type = TableType.ChannelGroup;
							matches[matchCount].itemIdx = grp.Index;
							matches[matchCount].score = score;
							matchCount++;
						}
					}
				} // end if type is Channel Group

				if (type == TableType.RGBchannel)
				{
					foreach (Channel ch in seq.Channels)
					{
						score = theName.LevenshteinDistance(ch.Name);
						if (score > MINSCORE)
						{
							Array.Resize(ref matches, matchCount + 1);
							matches[matchCount].savedIdx = ch.SavedIndex;
							matches[matchCount].type = TableType.Channel;
							matches[matchCount].itemIdx = ch.Index;
							matches[matchCount].score = score;
							matchCount++;
						}
					}
				} // end if type is RGB Channel

				if (type == TableType.Channel)
				{
					foreach (RGBchannel rgb in seq.RGBchannels)
					{
						score = theName.LevenshteinDistance(rgb.Name);
						if (score > MINSCORE)
						{
							Array.Resize(ref matches, matchCount + 1);
							matches[matchCount].savedIdx = rgb.SavedIndex;
							matches[matchCount].type = TableType.RGBchannel;
							matches[matchCount].itemIdx = rgb.Index;
							matches[matchCount].score = score;
							matchCount++;
						}
					}
				} // end if type is regular channel



				// Did we get ANY prequalified fuzzy matches?
				if (matchCount > 0)
				{
					for (int q = 0; q < matchCount; q++)
					{
						string myName = "";
						if (matches[q].type == TableType.Channel)
						{
							myName = seq.Channels[matches[q].itemIdx].Name;
						}
						if (matches[q].type == TableType.RGBchannel)
						{
							myName = seq.RGBchannels[matches[q].itemIdx].Name;
						}
						if (matches[q].type == TableType.ChannelGroup)
						{
							myName = seq.ChannelGroups[matches[q].itemIdx].Name;
						}
						// update the score using a FULL fuzzy match
						matches[q].score = theName.RankEquality(myName);
					}

					SortByScore(matches);
					// Is the first one past the minimum
					// NOTE: Minimum score for prequalification, and minimum score for final matching are NOT the same
					if (matches[0].score >= MINMATCH)
					{ 
						for (int q = 0; q < matchCount; q++)
						{
							if (matches[q].score >= MINMATCH)
							{
								Array.Resize(ref ret, q);
								ret[q] = matches[q].savedIdx;
							}
						} // end loop
					} // end any past minimum score
				} // end any prequalified fuzzies
			} // end single exact match
			return ret;
		} // end FindChannelNames


		private void SortByScore(match[] matches)
		{
			SortMatches(matches, 0, matches.Length);
		}

		private void SortMatches(match[] matches, int left, int right)
		{
			int i = left, j = right;
			double pivot = matches[(left + right) / 2].score;

			while (i <= j)
			{
				while (matches[i].score < pivot)
				{
					i++;
				}

				while (matches[j].score > pivot)
				{
					j--;
				}

				if (i <= j)
				{
					// Swap
					match tmp = matches[i];
					matches[i] = matches[j];
					matches[j] = tmp;

					i++;
					j--;
				}
			}

			// Recursive calls
			if (left < j)
			{
				SortMatches(matches, left, j);
			}

			if (i < right)
			{
				SortMatches(matches, i, right);
			}
		}

		/*
		private void SortMatches(match[] matches, int low, int high)
		{
			int pivot_loc = 0;

			if (low < high)
			{
				pivot_loc = PartitionMatches(matches, low, high);
			}
			SortMatches(matches, low, pivot_loc - 1);
			SortMatches(matches, pivot_loc + 1, high);
		}

		private int PartitionMatches(match[] matches, int low, int high)
		{
			double pivot = matches[high].score;
			int i = low - 1;

			for (int j = low; j < high - 1; j++)
			{
				if (matches[j].score <= pivot)
				{
					i++;
					SwapMatches(matches, i, j);
				}
			}
			SwapMatches(matches, i + 1, high);
			return i + 1;
		}

		private void SwapMatches(match[] matches, int a, int b)
		{
			match temp = matches[a];
			matches[a] = matches[b];
			matches[b] = temp;
		}
		*/


		private void pnlAll_Paint(object sender, PaintEventArgs e)
		{

		}

		private void frmRemapper_Load(object sender, EventArgs e)
		{
			InitForm();
		}

		private void btnAutoMap_Click(object sender, EventArgs e)
		{
			AutoMap();
		}

		private void AutoMap()
		{
			ImBusy(true);

			string sourceName = "";
			int sourceSI = utils.UNDEFINED;
			int masterSI = utils.UNDEFINED;
			int[] matchSIs = null;
			SeqPart srcID = null;
			const string STATUSautoMap = "AutoMap \"";
			const string STATUSto = "\" to...";

			int w =  pnlStatus.Width;
			pnlProgress.Width = w;
			pnlProgress.Size = new Size(w, pnlProgress.Height);
			pnlStatus.Visible = false;
			pnlProgress.Visible = true;
			staStatus.Refresh();
			int mq = seqMaster.Tracks.Count + seqMaster.ChannelGroups.Count + seqMaster.Channels.Count;
			mq -= seqMaster.RGBchannels.Count * 2;
			int sq = seqSource.Tracks.Count + seqSource.ChannelGroups.Count + seqSource.Channels.Count;
			sq -= seqSource.RGBchannels.Count * 2;
			int qq = mq * sq;
			pnlProgress.Maximum = mq+1;
			int pp = 0;
			string logFile = utils.GetAppTempFolder() + "Fuzzy.log";
			if (File.Exists(logFile))
			{
				File.Delete(logFile);
			}

			//frmOptions opt = new frmOptions();


			// TRACKS
			foreach (SeqPart masID in seqMaster.Children.Items)
			{
				// Try matching by SavedIndex first, there is a good chance they match
				//    (if one file is a derivative of the other)
				lblMessage.Text = STATUSautoMap + masID.Name + STATUSto;
				pnlMessage.Refresh();
				if (masID.SavedIndex <= seqSource.Children.HighestSavedIndex)
				{
					srcID = seqSource.Children.bySavedIndex[masID.SavedIndex];
				}
				if (srcID != null)
				{
					if (masID.Name.CompareTo(srcID.Name) != 0)
					{
						// By SavedIndex didn't work, try by name, use fuzy find if exact find fails
						//srcID = seqSource.Children.FindByName(masID.Name, TableType.Track, true);
						srcID = FuzzyFindName(masID.Name, seqSource, TableType.Track);
					}
				}
				if (srcID != null)
				{
					// Got a match, map it!
					MapChannels(masID.SavedIndex, srcID.SavedIndex, true, false);
				}
				pp++;
				pnlProgress.Value = pp;
				staStatus.Refresh();
			}  // end Track loop

			// CHANNEL GROUPS
			foreach (SeqPart masID in seqMaster.Children.Items)
			{
				// Try matching by SavedIndex first, there is a good chance they match
				lblMessage.Text = STATUSautoMap + masID.Name + STATUSto;
				pnlMessage.Refresh();
				if (masID.SavedIndex <= seqSource.Children.HighestSavedIndex)
				{
					srcID = seqSource.Children.bySavedIndex[masID.SavedIndex];
				}
				if (srcID != null)
				{
					if (masID.Name.CompareTo(srcID.Name) != 0)
					{
						// By SavedIndex didn't work, try by name, use fuzy find if exact find fails
						//srcID = seqSource.Children.FindByName(masID.Name, TableType.ChannelGroup, true);
						srcID = FuzzyFindName(masID.Name, seqSource, TableType.ChannelGroup);
					}
				}
				if (srcID != null)
				{
					// Got a match, map it!
					MapChannels(masID.SavedIndex, srcID.SavedIndex, true, false);
				}
				pp++;
				pnlProgress.Value = pp;
				staStatus.Refresh();
			}  // end ChannelGroup loop

			// RGB CHANNELS
			foreach (SeqPart masID in seqMaster.Children.Items)
			{
				lblMessage.Text = STATUSautoMap + masID.Name + STATUSto;
				pnlMessage.Refresh();
				if (masID.SavedIndex <= seqSource.Children.HighestSavedIndex)
				{
					srcID = seqSource.Children.bySavedIndex[masID.SavedIndex];
				}
				if (srcID != null)
				{
					if (masID.Name.CompareTo(srcID.Name) != 0)
					{
						//srcID = seqSource.Children.FindByName(masID.Name, TableType.RGBchannel, true);
						srcID = FuzzyFindName(masID.Name, seqSource, TableType.RGBchannel);
					}
				}
				if (srcID != null)
				{
					// Always map children of RGB Channels
					MapChannels(masID.SavedIndex, srcID.SavedIndex, true, true);
				}
				pp++;
				pnlProgress.Value = pp;
				staStatus.Refresh();
			}  // end RGBchannel loop

			// regular CHANNELS
			foreach (SeqPart masID in seqMaster.Children.Items)
			{
				lblMessage.Text = STATUSautoMap + masID.Name + STATUSto;
				pnlMessage.Refresh();
				Channel ch = (Channel)masID;
				if (ch.rgbChild == RGBchild.None)
				{
					if (masID.SavedIndex <= seqSource.Children.HighestSavedIndex)
					{
						srcID = seqSource.Children.bySavedIndex[masID.SavedIndex];
					}
					if (srcID != null)
					{
						if (masID.Name.CompareTo(srcID.Name) != 0)
						{
							//srcID = seqSource.Children.FindByName(masID.Name, TableType.Channel, true);
							srcID = FuzzyFindName(masID.Name, seqSource, TableType.Channel);
						}
					}
					if (srcID != null)
					{
						MapChannels(masID.SavedIndex, srcID.SavedIndex, true, true);
					}
					pp++;
					pnlProgress.Value = pp;
					staStatus.Refresh();
				}
			}  // end regular Channel loop

			pnlProgress.Visible = false;
			pnlStatus.Visible = true;
			ImBusy(false);
			if (File.Exists(logFile))
			{
				System.Diagnostics.Process.Start(logFile);
			}


		}

		private void frmRemapper_Paint(object sender, PaintEventArgs e)
		{
			if (!firstShown)
			{
				firstShown = true;
				FirstShow();
			}
		}

		private void pnlHelp_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start(helpPage);
		}

		private void pnlAbout_Click(object sender, EventArgs e)
		{
			ImBusy(true);
			Form aboutBox = new About();
			aboutBox.ShowDialog(this);
			ImBusy(false);
		}


		private void RestoreFormPosition()
		{
			// Multi Monitor Aware - Restore Postition to last Used
			Screen screen = Screen.AllScreens[0]; ;
			// Read the previous screen used from the INI file
			int screenNum = Properties.Settings.Default.Screen; // Val(ReadIni(File, "Main", "PosScreen"))
			// Verify the Specified screen exists, if so then use it
			if (Screen.AllScreens.Length < screenNum + 1)
			{
				screen = Screen.AllScreens[0];
			}
			else
			{
				screen = Screen.AllScreens[screenNum];
			}
			// Read the Position from the INI File
			Point lastLocation = Properties.Settings.Default.Location;
			Point newLocation = new System.Drawing.Point(lastLocation.X, lastLocation.Y);
			if (newLocation.X < 0) newLocation.X = 0;
			if (newLocation.Y < 0) newLocation.Y = 0;
			if (screen.Bounds.Contains(newLocation))
			{
				if ((newLocation.X + Width) > screen.Bounds.Right)
				{
					newLocation.X = screen.Bounds.Right - Width;
				}
				if ((newLocation.Y + Height) > Bounds.Bottom)
				{
					newLocation.Y = screen.Bounds.Bottom - Height;
				}
			}
			else
			{
				newLocation.X = screen.Bounds.Left + (screen.Bounds.Width - this.Width)/2;
				newLocation.Y = screen.Bounds.Top +  (screen.Bounds.Height - this.Height)/2;
			}
			this.StartPosition = FormStartPosition.Manual;
			this.Location = newLocation;
		}

		private void btnSaveNewSeq_Click(object sender, EventArgs e)
		{
			SaveNewMappedSequence();
		}

		private void SaveNewMappedSequence()
		{ 

			dlgSaveFile.DefaultExt = Path.GetExtension(sourceFile);
			dlgSaveFile.Filter = "Musical Sequence|*.lms|Animated Sequence|*.las|All Files|*.*";
			dlgSaveFile.FilterIndex = 0;
			string initDir = SeqFolder;
			string initFile = "";
			if (sourceFile.Length > 4)
			{
				string pth = Path.GetFullPath(sourceFile);
				if (Directory.Exists(pth))
				{
					initDir = pth;
				}
				if (File.Exists(sourceFile))
				{
					initFile = Path.GetFileName(sourceFile);
				}
			}
			string newName = SuggestedNewName(initFile);
			dlgSaveFile.FileName = newName;
			dlgSaveFile.InitialDirectory = initDir;
			dlgSaveFile.OverwritePrompt = true;
			dlgSaveFile.CheckPathExists = true;
			dlgSaveFile.Title = "Save New Sequence As...";

			DialogResult dr = dlgSaveFile.ShowDialog();
			if (dr == DialogResult.OK)
			{

				string saveTemp = System.IO.Path.GetTempPath();
				saveTemp += Path.GetFileName(dlgSaveFile.FileName);
				int mapErr = SaveNewMappedSequence(saveTemp);
				if (mapErr == 0)
				{
					saveFile = dlgSaveFile.FileName;
					if (File.Exists(saveFile))
					{
						//TODO: Add Exception Catch
						File.Delete(saveFile);
					}
					File.Copy(saveTemp, saveFile);
					File.Delete(saveTemp);
					//dirtyMap = false;
					//btnSaveMap.Enabled = dirtyMap;
					//txtMappingFile.Text = Path.GetFileName(mapFile);
				} // end no errors saving map
			} // end dialog result = OK

		}

		private void Event_DragDrop(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
				processDrop = true;
				ProcessFileList(files);
				//this.Cursor = Cursors.Default;
			}

		}

		private void Event_DragEnter(object sender, DragEventArgs e)
		{
			e.Effect = DragDropEffects.Copy;
			//this.Cursor = Cursors.Cross;
		}

		private string SuggestedNewName(string originalName)
		{
			string p = Path.GetDirectoryName(originalName);
			string n = Path.GetFileNameWithoutExtension(originalName);
			string e = Path.GetExtension(originalName);
			string ty = DateTime.Now.Year.ToString();
			string ly = (DateTime.Now.Year - 1).ToString();
			n = n.Replace(ly, ty);
			int i = 1;
			string ret = p + n + " Remapped" + e;
			while(File.Exists(ret))
			{
				i++;
				ret = p + n + " Remapped (" + i.ToString() + ")" + e;
			}
			return ret;
		} // end SuggestedNewName

		private void ProcessCommandLine()
		{
			commandArgs = Environment.GetCommandLineArgs();
			string arg;
			for (int f = 0; f < commandArgs.Length; f++)
			{
				arg = commandArgs[f];
				// Does it LOOK like a file?
				byte isFile = 0;
				if (arg.Substring(1, 2).CompareTo(":\\") == 0) isFile = 1;  // Local File
				if (arg.Substring(0, 2).CompareTo("\\\\") == 0) isFile = 1; // UNC file
				if (arg.Substring(4).IndexOf(".") > utils.UNDEFINED) isFile++;  // contains a period
				if (utils.InvalidCharacterCount(arg) == 0) isFile++;
				if (isFile == 3)
				{
					if (File.Exists(arg))
					{
						string ext = Path.GetExtension(arg).ToLower();
						if (ext.CompareTo(".exe") == 0)
						{
							if (f == 0)
							{
								thisEXE = arg;
							}
						}
						if ((ext.CompareTo(".lms") == 0) || (ext.CompareTo(".las") == 0))
						{
							Array.Resize(ref batch_fileList, batch_fileCount + 1);
							batch_fileList[batch_fileCount] = arg;
							batch_fileCount++;
						}
						else
						{
							if (ext.CompareTo("chsel") == 0)
							{
								cmdSelectionsFile = arg;
							}
						}
					}
				}
				else
				{
					// Not a file, is it an argument
					if (arg.Substring(0, 1).CompareTo("/") == 0)
					{
						//TODO: Process any commands
					}
				}
			} // foreach argument
			if (batch_fileCount == 1)
			{


			}
			else
			{
				if (batch_fileCount > 1)
				{
					ProcessSourcesBatch(batch_fileList);
				}
			}


		}

		private void ProcessFileList(string[] batchFilenames)
		{
			batch_fileCount = 0; // reset
			bool inclSelections = false;
			DialogResult dr = DialogResult.None;

			foreach (string file in batchFilenames)
			{
				// None of this should be necessary for a file dragdrop			

				// Does it LOOK like a file?
				//byte isFile = 0;
				//if (arg.Substring(1, 2).CompareTo(":\\") == 0) isFile = 1;  // Local File
				//if (arg.Substring(0, 2).CompareTo("\\\\") == 0) isFile = 1; // UNC file
				//if (arg.Substring(4).IndexOf(".") > utils.UNDEFINED) isFile++;  // contains a period
				//if (InvalidCharacterCount(arg) == 0) isFile++;
				//if (isFile == 2)
				//{
				//	if (File.Exists(arg))
				//	{
				batchTypes = BATCHnone;
				string ext = Path.GetExtension(file).ToLower();
				if (ext.CompareTo(".lcc") == 0)
				{
					if (File.Exists(file))
					{
						LoadMasterFile(file);
						batchTypes |= BATCHmaster;
					}
				}
				if (ext.CompareTo(".chmap") == 0)
				{
					if (File.Exists(file))
					{
						mapFile = file;
						batchTypes |= BATCHmap;
					}
				}
				if ((ext.CompareTo(".lms") == 0) ||
						(ext.CompareTo(".las") == 0))
				{
					Array.Resize(ref batch_fileList, batch_fileCount + 1);
					batch_fileList[batch_fileCount] = file;
					batch_fileCount++;
					batchTypes |= BATCHsources;

				}
				//	}
				//}
			}
			if (batch_fileCount > 1)
			{
				batchMode = true;
				ProcessSourcesBatch(batch_fileList);
			}
			else
			{
			}
		} // end ProcessDragDropFiles

		private int GetMapFileLineCount(string mapFile)
		{
			int lineCount = 0;
			string lineIn = "";
			StreamReader reader = new StreamReader(mapFile);
			while ((lineIn = reader.ReadLine()) != null)
			{
				lineCount++;
			}
			reader.Close();
			return lineCount;
		}

		private void ProcessSourcesBatch(string[] batchFilenames)
		{
			//if (batch_fileCount > 0)
			if (seqMaster.Children.Items.Count > 1)
			{
				ShowProgressBars(2);
				for (int f = 0; f < batch_fileCount; f++)
				{
					LoadSourceFile(batch_fileList[f]);
					if (File.Exists(mapFile))
					{
						batch_fileNumber = f;
						ReadApplyMapV2(mapFile);
						string newnm = SuggestedNewName(sourceFile); // R we gettin here?
						SaveNewMappedSequence(newnm);
					}
					else
					{
						f = batch_fileCount;
						break;
					}
				} // cmdSeqFileCount-- Batch Mode or Not
			}
			batchMode = false;
			ShowProgressBars(0);
			ImBusy(false);
			//string msg = "Batch mode is not supported... yet.\r\nLook for this feature in a future release (soon)!";
			//MessageBox.Show(this, msg, "Batch Mode", MessageBoxButtons.OK, MessageBoxIcon.Information);
		} // end ProcessSourcesBatch

		private void mnuOpenMaster_Click(object sender, EventArgs e)
		{
			BrowseMasterFile();
		}

		private void mnuOpenSource_Click(object sender, EventArgs e)
		{
			BrowseSourceFile();
		}

		private void mnuOpenMap_Click(object sender, EventArgs e)
		{
			BrowseForMap();
		}

		private void mnuSelect_Click(object sender, EventArgs e)
		{

		}

		private void ArrangePanes(bool sourceNowOnRight)
		{
			if (sourceNowOnRight)
			{
				lblSourceFile.Left = 415;
				lblSourceTree.Left = 415;
				txtSourceFile.Left = 415;
				treeSource.Left = 415;
				btnBrowseSource.Left = 721;

				lblMasterFile.Left = 15;
				lblMasterTree.Left = 15;
				txtMasterFile.Left = 15;
				treeMaster.Left = 15;
				btnBrowseMaster.Left = 321;

				mnuSourceLeft.Checked = false;
				mnuSourceRight.Checked = true;
			}
			else
			{
				lblSourceFile.Left = 15;
				lblSourceTree.Left = 15;
				txtSourceFile.Left = 15;
				treeSource.Left = 15;
				btnBrowseSource.Left = 321;

				lblMasterFile.Left = 415;
				lblMasterTree.Left = 415;
				txtMasterFile.Left = 415;
				treeMaster.Left = 415;
				btnBrowseMaster.Left = 721;

				mnuSourceLeft.Checked = true;
				mnuSourceRight.Checked = false;
			}

			sourceOnRight = sourceNowOnRight;
			Properties.Settings.Default.SourceOnRight = sourceOnRight;
			Properties.Settings.Default.Save();
		}

		private void mnuSourceLeft_Click(object sender, EventArgs e)
		{
			ArrangePanes(false);
		}

		private void mnuSourceRight_Click(object sender, EventArgs e)
		{
			ArrangePanes(true);
		}

		private void mnuMatchOptions_Click(object sender, EventArgs e)
		{
			frmOptions opt = new frmOptions();
			opt.ShowDialog(this);
		}

		private void mnuAutoMap_Click(object sender, EventArgs e)
		{
			AutoMap();
		}



		public SeqPart FuzzyFindName(string theName, Sequence4 sequence, TableType theType)
		{
			SeqPart ret = null;
			bool useFuzzy = Properties.Settings.Default.FuzzyUse;
			bool writeLog = Properties.Settings.Default.FuzzyWriteLog;

			string logFile = "";
			StreamWriter writer = new StreamWriter(Stream.Null);
			string lineOut = "";
			if (writeLog)
			{
				logFile = utils.GetAppTempFolder() + "Fuzzy.log";
				writer = new StreamWriter(logFile, true);
				writer.WriteLine("");
				lineOut = "Looking for     \"" + theName + "\" in ";
				lineOut += SeqEnums.TableTypeName(theType) + "s in ";
				lineOut += Path.GetFileName(sequence.info.filename);
				writer.WriteLine(lineOut);
			}

			if (sequence.Children.byName.ContainsKey(theName))
			{
				ret = sequence.Children.byName[theName];
				if (writeLog)
				{
					lineOut = "Exact Match Found \"" + ret.Name + "\" ";
					lineOut += "Saved Index=" + ret.SavedIndex.ToString();
					writer.WriteLine(lineOut);
				}
			}
			else
			{
				if (useFuzzy)
				{
					List<SeqPart> IDs = null;
					double[] scores = null;
					int[] SIs = null;
					int count = 0;
					long[] totTimes = null;
					int[] totCount = null;
					Array.Resize(ref totTimes, FuzzyFunctions.ALGORITHM_COUNT + 1);
					Array.Resize(ref totCount, FuzzyFunctions.ALGORITHM_COUNT + 1);
					double score;
					long finalAlgorithms = Properties.Settings.Default.FuzzyFinalAlgorithms;
					long prematchAlgorithm = Properties.Settings.Default.FuzzyPrematchAlgorithm;
					bool caseSensitive = Properties.Settings.Default.FuzzyCaseSensitive;
					double minPrematchScore = Properties.Settings.Default.FuzzyMinPrematch;
					double minFinalMatchScore = Properties.Settings.Default.FuzzyMinFinal;

					// Now perform all other requested algorithms
					if (writeLog)
					{
						lineOut = "Fuzzy Prematches with a minimum of " + minPrematchScore.ToString() + ":";
						writer.WriteLine(lineOut);
					}

					// Go thru all objects
					foreach (SeqPart id in IDs)
					{
						// get a quick prematch score
						score = theName.RankEquality(id.Name, prematchAlgorithm);
						// fi the score is above the minimum PreMatch
						if (score * 100 > minPrematchScore)
						{
							// Increment count and save the SavedIndex
							// NOte: No need to save the PreMatch score
							count++;
							Array.Resize(ref SIs, count);
							SIs[count - 1] = id.SavedIndex;
							if (writeLog)
							{
								lineOut = score.ToString("0.0000") + " SI:";
								lineOut += id.SavedIndex.ToString().PadLeft(5);
								lineOut += "=\"" + id.Name + "\"";
								writer.WriteLine(lineOut);
							}
						} // end score exceeds minimum
					} // end foreach loop
					if (writeLog)
					{
						lineOut = count.ToString() + " found.";
						writer.WriteLine(lineOut);
					}
					if (count > 0)
					{
						// Resize scores array to final size
						Array.Resize(ref scores, count);
						// Loop thru qualifying prematches
						for (int i = 0; i < count; i++)
						{
							// Get the ID, perform a more thorough final fuzzy match, and save the score
							SeqPart id = sequence.Children.bySavedIndex[SIs[i]];
							//score = theName.RankEquality(id.Name, finalAlgorithms);

							string source = theName;
							string target = id.Name;
							double avgScore = 0;
							List<double> comparisonResults = new List<double>();
							int methodCount = 0;
							double runningTotal = 0D;
							double scoreOut = 0D;
							double minScore = 0.4D;
							double maxScore = 0.99D;
							double thisScore = 0.5D;
							double WLscore = 0.8D;
							bool valid = false;

							lineOut = "<";
							if ((finalAlgorithms & FuzzyFunctions.USE_CASEINSENSITIVE) > 0)
							{
								source = source.Capitalize();
								target = target.Capitalize();
								lineOut += "Not ";
							}
							if (writeLog)
							{
								lineOut += "Case Sensitive>";
								writer.Write(lineOut);
							}

							// Use Weighted Levenshtein to set a baseline
							//  for what is an acceptable score from other algorithms
							WLscore = source.WeightedLevenshteinSimilarity(target);
							maxScore = WLscore + (1.0D - WLscore) * 0.75D;
							minScore = WLscore / 3.0D;
							minScore = Math.Max(minScore, 0.4D);

							if (writeLog)
							{
								lineOut = "Baseline Score (Weighted Levenshtein: ";
								lineOut += WLscore.ToString("0.0000 ");
								//writer.WriteLine(lineOut);
								lineOut += "   Min: " + minScore.ToString("0.0000") + "   Max: " + maxScore.ToString("0.0000");
								writer.WriteLine(lineOut);
							}



							for (int al =1; al <= FuzzyFunctions.ALGORITHM_COUNT; al++)
							{
								long mask = (long)Math.Pow(2D, (double) al) / 2;
								//if ((finalAlgorithms & mask) > 0)
								//{
									var watch = System.Diagnostics.Stopwatch.StartNew();
									thisScore = source.RankEquality(target, mask);
									watch.Stop();
									long elapsedMs = watch.ElapsedMilliseconds;
									totTimes[al] += elapsedMs;
									totCount[al]++;
									valid = WankEquality(thisScore, minScore, maxScore, ref runningTotal, ref methodCount);
									if (writeLog)
									{
										lineOut = WankLine(thisScore, valid, mask, elapsedMs);
										writer.WriteLine(lineOut);
									}
								//}
							}
							if (methodCount > 0)
							{
								avgScore = runningTotal / methodCount;
								if (writeLog)
								{
									lineOut = avgScore.ToString("0.0000 ") + "Average";
									writer.WriteLine(lineOut);
								}
							}
							scores[i] = avgScore;
						}
						// Now sort the final scores (and the SavedIndexes along with them)
						Array.Sort(scores, SIs);
						if (writeLog)
						{
							lineOut = "Final Matches:";
							writer.WriteLine(lineOut);
							for (int f = 0; f < count; f++)
							{
								lineOut = scores[f].ToString("0.0000") + " SI:";
								SeqPart y = sequence.Children.bySavedIndex[SIs[f]];
								lineOut += y.SavedIndex.ToString().PadLeft(5);
								lineOut += "=\"" + y.Name + "\"";
								writer.WriteLine(lineOut);
							}
						} // end writelog

						// Is the best/highest above the required minimum Final Match score?
						if (scores[count - 1] * 100 > minFinalMatchScore)
						{
							// Return the ID with the best qualifying final match
							ret = sequence.Children.bySavedIndex[SIs[count - 1]];
							// Get name just for debugging
							string msg = theName + " ~= " + ret.Name;
							if (writeLog)
							{
								lineOut = "Best Match Is:";
								writer.WriteLine(lineOut);
								lineOut = scores[count - 1].ToString("0.0000") + " SI:";
								SeqPart y = sequence.Children.bySavedIndex[SIs[count - 1]];
								lineOut += y.SavedIndex.ToString().PadLeft(5);
								lineOut += "=\"" + y.Name + "\"";
								writer.WriteLine(lineOut);
							}
						}
						else
						{
							if (writeLog)
							{
								lineOut = "No Final Matches meet the minimum score of " + minFinalMatchScore.ToString();
								writer.WriteLine(lineOut);
							}
						} // end score beats min final (or not)
					} // end if count; prematches
				} // end if useFuzzy
			} // end if exact match found, or not
			if (writeLog)
			{
				writer.Close();
				//System.Diagnostics.Process.Start(logFile);
			}
			return ret;
		}

		private static bool WankEquality(double thisScore, double minScore, double maxScore, ref double runningTotal, ref int methodCount)
		{
			bool valid = false;
			if ((thisScore >= minScore) && (thisScore <= maxScore)) valid = true;
			if (valid)
			{
				runningTotal += thisScore;
				methodCount++;
			}
			return valid;
		}

		private static string WankLine(double theScore, bool isValid, long algorithm, long elapsed)
		{
			string lineOut = theScore.ToString("0.0000 ") + FuzzyFunctions.AlgorithmNames(algorithm);
			if (!isValid) lineOut += " Not";
			lineOut += " Valid  ";
			lineOut += elapsed.ToString() +"μs";

			return lineOut;
		}

		public static SeqPart FindName(string theName, List<SeqPart> IDs)
		{
			SeqPart ret = null;
			int idx = BinarySearch(theName, IDs);
			if (idx > utils.UNDEFINED)
			{
				ret = IDs[idx];
			}
			return ret;
		}

		public static int BinarySearch(string theName, List<SeqPart> IDs)
		{
			return BinarySearch3(theName, IDs, 0, IDs.Count - 1);
		}

		public static int BinarySearch3(string theName, List<SeqPart> IDs, int start, int end)
		{
			int index = -1;
			int mid = (start + end) / 2;
			if ((theName.CompareTo(IDs[start].Name) > 0) && (theName.CompareTo(IDs[end].Name) < 0))
			{
				int cmp = theName.CompareTo(IDs[mid].Name);
				if (cmp < 0)
					BinarySearch3(theName, IDs, start, mid);
				else if (cmp > 0)
					BinarySearch3(theName, IDs, mid + 1, end);
				else if (cmp == 0)
					index = mid;
				//if (index != -1)
					//Console.WriteLine("got it at " + index);
			}
			return index;
		}

		private void ShowProgressBars(int howMany)
		{
			if (howMany == 0)
			{
				btnLoadMap.Visible = true;
				btnSaveMap.Visible = true;
				txtMappingFile.Visible = true;
				prgBarInner.Visible = false;
				prgBarOuter.Visible = false;
			}
			else
			{
				btnLoadMap.Visible = false;
				btnSaveMap.Visible = false;
				txtMappingFile.Visible = false;
				prgBarInner.Value = 0;
				prgBarInner.Visible = true;
			}
			if (howMany == 2)
			{
				prgBarInner.Value = 0;
				prgBarOuter.Value = 0;
				prgBarInner.Visible = true;
				prgBarOuter.Visible = true;
			}
			else
			{
				prgBarOuter.Visible = false;
			}
		} // end ShowProgressBars

	} // end class frmRemapper
} // end namespace MapORama
