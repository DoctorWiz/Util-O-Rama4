﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using LORUtils;

namespace TestORama
{
	public partial class frmTest : Form
	{
		private string fileName = "";
		private Sequence4 seq = new Sequence4();
		private string applicationName = "TEST-O-Rama";
		private string tempPath = "C:\\Windows\\Temp\\";  // Gets overwritten with X:\\Username\\AppData\\Roaming\\Util-O-Rama\\Split-O-Rama\\
		private string thisEXE = "TEST-O-Rama.exe";
		private string[] commandArgs = null;
		private bool firstShown = false;
		private string[] batch_fileList = null;
		private int batch_fileCount = 0;
		private bool batchMode = false;
		const char DELIM1 = '⬖';
		const char DELIM4 = '⬙';


		public frmTest()
		{
			InitializeComponent();
		}

		private void InitForm()
		{
			//this.Cursor = Cursors.WaitCursor;
			RestoreFormPosition();
			string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
			string mySubDir = "\\UtilORama\\";
			tempPath = appDataDir + mySubDir;
			if (!Directory.Exists(tempPath))
			{
				Directory.CreateDirectory(tempPath);
			}
			string appName = applicationName.Replace("-", "");
			mySubDir	+= appName + "\\";
			tempPath = appDataDir + mySubDir;
			if (!Directory.Exists(tempPath))
			{
				Directory.CreateDirectory(tempPath);
			}
			ProcessCommandLine();
			//this.Cursor = DefaultCursor;
			chkAutoLaunch.Checked = Properties.Settings.Default.AutoLaunch;
			chkAutoLoad.Checked = Properties.Settings.Default.AutoLoad;
			chkAutoSave.Checked = Properties.Settings.Default.AutoSave;
			fileName = Properties.Settings.Default.LastFile;
		}

		private void ProcessCommandLine()
		{
			commandArgs = Environment.GetCommandLineArgs();
			string arg;
			for (int f = 0; f < commandArgs.Length; f++)
			{
				arg = commandArgs[f];
				// Does it LOOK like a file?
				int isFile = 0;
				if (arg.Substring(1, 2).CompareTo(":\\") == 0) isFile = 1;  // Local File
				if (arg.Substring(0, 2).CompareTo("\\\\") == 0) isFile = 1; // UNC file
				if (arg.Substring(4).IndexOf(".") > utils.UNDEFINED) isFile++;  // contains a period
				if (utils.InvalidCharacterCount(arg) == 0) isFile++;
				if (isFile == 3)
				{
					if (File.Exists(arg))
					{
						string ext = Path.GetExtension(arg).ToLower();
						if (ext.CompareTo(".exe") == 0)
						{
							if (f == 0)
							{
								thisEXE = arg;
							}
								
						}
						if ((ext.CompareTo(".lms") == 0) ||
							  (ext.CompareTo(".las") == 0) ||
							  (ext.CompareTo(".lcc") == 0) ||
							  (ext.CompareTo(".lcb") == 0))
						{
							Array.Resize(ref batch_fileList, batch_fileCount + 1);
							batch_fileList[batch_fileCount] = arg;
							batch_fileCount++;
						}
					}
				}
				else
				{
					// Not a file, is it an argument
					if (arg.Substring(0, 1).CompareTo("/") == 0)
					{
						//TODO: Process any commands
					}
				}
			} // foreach argument
			if (batch_fileCount == 1)
			{


			}
			else
			{
				if (batch_fileCount > 1)
				{
					ProcessFileBatch(batch_fileList);
				}
			}


		}

		private void SaveFormPosition()
		{
			// Called with form is closed
			if (WindowState == FormWindowState.Normal)
			{
				Properties.Settings.Default.Location = Location;
				Properties.Settings.Default.Size = Size;
				Properties.Settings.Default.Minimized = false;
			}
			else
			{
				Properties.Settings.Default.Location = RestoreBounds.Location;
				Properties.Settings.Default.Size = RestoreBounds.Size;
				Properties.Settings.Default.Minimized = true;
			}
			Properties.Settings.Default.Save();
			this.Cursor = Cursors.Default;

		} // End SaveFormPosition

		private void RestoreFormPosition()
		{
			// Called when form is loaded
			//TODO: This only gets the area of the first screen in a multi-screen setup

			//int myWidth = Properties.Settings.Default.Size.Width;
			//int myHeight = Properties.Settings.Default.Size.Height;
			int myWidth = this.Width;
			int myHeight = this.Height;
			int myLeft = Properties.Settings.Default.Location.X;
			int myTop = Properties.Settings.Default.Location.Y;
			int scrWd = SystemInformation.WorkingArea.Width;
			int scrHt = SystemInformation.WorkingArea.Height;

			if (myTop > (scrHt - myHeight))
			{
				myTop = scrHt - myHeight;
			}
			if (myLeft > (scrWd - myWidth))
			{
				myLeft = scrWd - myWidth;
			}

			// Should get all screens and figure out if size/Placement of the form is valid
			//TODO: Restore form.WindowState and if maximized use RestoreBounds()
			//this.SetDesktopLocation(myLeft, myTop);
			//this.Width = myWidth;
			//this.Height = myHeight;
			this.SetBounds(myLeft, myTop, myWidth, myHeight);
			//frmReport_ResizeEnd(null, null);


		} // End RestoreFormPosition


		private void frmReport_FormClosing(object sender, FormClosingEventArgs e)
		{
			SaveFormPosition();
		}

		


		private void frmReport_DragDrop(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
			{
				string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
				ProcessFileList(files);
			}
		}

		private void ProcessFileList(string[] batchFilenames)
		{
			batch_fileCount = 0; // reset
			DialogResult dr = DialogResult.None;

			foreach (string file in batchFilenames)
			{
				string ext = Path.GetExtension(file).ToLower();
				if ((ext.CompareTo(".lms") == 0) ||
					  (ext.CompareTo(".las") == 0) ||
						(ext.CompareTo(".lcc") == 0) ||
					  (ext.CompareTo(".lcb") == 0))
				{
					Array.Resize(ref batch_fileList, batch_fileCount + 1);
					batch_fileList[batch_fileCount] = file;
					batch_fileCount++;
				}
			}
			if (batch_fileCount > 1)
			{
				batchMode = true;
				ProcessFileBatch(batch_fileList);
			}
			else
			{
				if (batch_fileCount == 1)
				{
					string thisFile = batch_fileList[0];
					string reportTempFile = tempPath + Path.GetFileNameWithoutExtension(thisFile) +" Report.htm";
					//CreateReport(thisFile, reportTempFile);
				}
			} // batch_fileCount-- Batch Mode or Not
		} // end ProcessFileList

		private void ProcessFileBatch(string[] batchFilenames)
		{
			string thisFile = batch_fileList[0];
			string reportTempFile = tempPath + Path.GetFileNameWithoutExtension(thisFile) + " Report.htm";
			//CreateReport(thisFile, reportTempFile);

			for (int f=1; f< batchFilenames.Length; f++)
			{
				thisFile = batch_fileList[f];
				Process.Start(thisEXE, thisFile);
			}
			batchMode = false;
		} // end ProcessFileBatch

		private void ImBusy(bool isBusy)
		{
			if (isBusy)
			{
				this.Cursor = Cursors.WaitCursor;
				this.Enabled = false;
			}
			else
			{
				this.Enabled = true;
				this.Cursor = Cursors.Default;
			}
		} // end ImBusy

		private void frmReport_Load(object sender, EventArgs e)
		{
			InitForm();
		}

		private void btnBrowse_Click(object sender, EventArgs e)
		{
			string initDir = utils.DefaultSequencesPath;
			string initFile = "";

			dlgOpenFile.Filter = "Light-O-Rama Sequences|*.lms;*.las";
			dlgOpenFile.FilterIndex = 1;
			dlgOpenFile.DefaultExt = ".lms";
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			dlgOpenFile.Title = "Select a Sequence...";
			//pnlAll.Enabled = false;
			DialogResult result = dlgOpenFile.ShowDialog(this);

			if (result == DialogResult.OK)
			{
				ImBusy(true);
				string thisFile  = dlgOpenFile.FileName;
				this.Text = "Test-O-Rama - " + Path.GetFileName(thisFile);
				Properties.Settings.Default.LastFile = thisFile;
				Properties.Settings.Default.Save();
				int err = loadSequence(thisFile);
				//CreateReport(thisFile, thisRpt);

				//webReport.Navigate(thisRpt);
				btnSaveAs.Enabled = true;
				btnReload.Enabled = true;
				//btnBrowse.Text = "Analyze another Sequence...";
				//MessageBox.Show(this, seq.summary(), "Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
				ImBusy(false);

			} // end if (result = DialogResult.OK)
				//pnlAll.Enabled = true;

		}

		private int loadSequence(string seqFile)
		{
			int err = 0;
			txtFilename.Text = Path.GetFileName(seqFile);
			err = seq.ReadSequenceFile(seqFile);
			MessageBox.Show(this, seq.summary(), "Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
			fileName = seqFile;

			if (err == 0)
			{
				btnSaveAs.Enabled = true;
				if (chkAutoSave.Checked)
				{
					int f = 2;
					string autoSeqPath = utils.DefaultSequencesPath;
					string autoSeqName = Path.GetFileNameWithoutExtension(fileName);
					string ext = Path.GetExtension(fileName);
					string tryFile = autoSeqPath + autoSeqName + " Rewrite" + ext;
					//while (System.IO.File.Exists(tryFile))
					//{
					//	tryFile = autoSeqPath + autoSeqName + " (" + f.ToString() + ")" + ext;
					//	f++;
					//}
					err = SaveSequence(tryFile);
					
				}
			}
			return err;
			 


		}

	

		private void chkAutoLoad_CheckedChanged(object sender, EventArgs e)
		{
			if (firstShown)
			{
				Properties.Settings.Default.AutoLoad = chkAutoLoad.Checked;
				Properties.Settings.Default.Save();
			}
		}

		private void chkAutoSave_CheckedChanged(object sender, EventArgs e)
		{
			if (firstShown)
			{
				Properties.Settings.Default.AutoSave = chkAutoSave.Checked;
				Properties.Settings.Default.Save();
				if (!chkAutoSave.Checked) chkAutoLaunch.Checked = false;
				chkAutoLaunch.Enabled = chkAutoSave.Checked;
			}
		}

		private void chkAutoLaunch_CheckedChanged(object sender, EventArgs e)
		{
			if (firstShown				)
			{
				Properties.Settings.Default.AutoLaunch = chkAutoLaunch.Checked;
				Properties.Settings.Default.Save();
			}
		}

		private void frmTest_Paint(object sender, PaintEventArgs e)
		{
			if (!firstShown)
			{
				firstShown = true;
				FirstShow();
			}
		} // end Paint event

		private void FirstShow()
		{
			if (chkAutoLoad.Checked)
			{
				if (File.Exists(fileName))
				{
					loadSequence(fileName);
					MessageBox.Show(this, seq.summary(), "Summary", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
			}
		} // end FirstShow

		private void btnSaveAs_Click(object sender, EventArgs e)
		{
			string filt = "";
			string tit = "";
			//string ext = Path.GetExtension(fileName).ToLower();
			string ext = ".lms";
			//if (ext.CompareTo(".loredit") == 0)
			//{
			filt = "Light-O-Rama Musical Sequences|*.lms|Light-O-Rama Animated Sequence|*.las";
			tit = "Save Sequence As...";
			//}
			string initDir = "";
			string initFile = "";
			if (fileName.Length > 5)
			{
				if (Directory.Exists(Path.GetDirectoryName(fileName)))
				{
					initDir = Path.GetDirectoryName(fileName);
					initFile = Path.GetFileNameWithoutExtension(fileName) + " Rewrite"; // + ext;
				}
			}
			if (initDir.Length < 5)
			{
				// Can't imagine that we would ever make it this far, but, just in case...
				//if (ext.CompareTo(".lcc") == 0)
				//{
				//	initDir = utils.DefaultChannelConfigsPath;
				//}
				//else
				//{
					initDir = utils.DefaultSequencesPath;
				//}
			}

			dlgSaveFile.Filter = filt;
			dlgSaveFile.FilterIndex = 1;
			//dlgSaveFile.FileName = Path.GetFullPath(fileSeqCur) + Path.GetFileNameWithoutExtension(fileSeqCur) + " Part " + part.ToString() + ext;
			dlgSaveFile.CheckPathExists = true;
			dlgSaveFile.InitialDirectory = initDir;
			dlgSaveFile.DefaultExt = ext;
			dlgSaveFile.OverwritePrompt = true;
			dlgSaveFile.Title = tit;
			dlgSaveFile.SupportMultiDottedExtensions = true;
			dlgSaveFile.ValidateNames = true;
			//newFileIn = Path.GetFileNameWithoutExtension(fileSeqCur) + " Part " + part.ToString(); // + ext;
			//newFileIn = "Part " + part.ToString() + " of " + Path.GetFileNameWithoutExtension(fileSeqCur);
			//newFileIn = "Part Mother Fucker!!";
			dlgSaveFile.FileName = initFile;
			DialogResult result = dlgSaveFile.ShowDialog(this);
			if (result == DialogResult.OK)
			{
				SaveSequence(dlgSaveFile.FileName);
			}

		} // end Save As...

		private int SaveSequence(string newName)
		{
			int err = seq.WriteSequenceFile(newName);
			if (err==0)
			{
				if (chkAutoLaunch.Checked)
				{
					System.Diagnostics.Process.Start(newName);
				}
			}
			return err;
		} // end SaveSequence

		private void btnReload_Click(object sender, EventArgs e)
		{
			if (File.Exists(fileName))
			{
				loadSequence(fileName);
			}
		}
	} // end form frmTest
} // end namespace InfoRama
