﻿namespace SplitORama
{
	partial class frmSplit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSplit));
			this.cmdSaveSequence = new System.Windows.Forms.Button();
			this.treChannels = new System.Windows.Forms.TreeView();
			this.imlTreeIcons = new System.Windows.Forms.ImageList(this.components);
			this.label2 = new System.Windows.Forms.Label();
			this.cmdBrowseSequence = new System.Windows.Forms.Button();
			this.txtSequenceFile = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.cmdBrowseMap = new System.Windows.Forms.Button();
			this.txtMapFile = new System.Windows.Forms.TextBox();
			this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
			this.dlgSaveFile = new System.Windows.Forms.SaveFileDialog();
			this.cmdInvert = new System.Windows.Forms.Button();
			this.cmdSaveMap = new System.Windows.Forms.Button();
			this.lblSelectionCount = new System.Windows.Forms.Label();
			this.cmdNothing = new System.Windows.Forms.Button();
			this.ttip = new System.Windows.Forms.ToolTip(this.components);
			this.staStatus = new System.Windows.Forms.StatusStrip();
			this.pnlHelp = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlProgress = new System.Windows.Forms.ToolStripProgressBar();
			this.pnlStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlAbout = new System.Windows.Forms.ToolStripStatusLabel();
			this.prgProgress = new System.Windows.Forms.ProgressBar();
			this.cmdClear = new System.Windows.Forms.Button();
			this.cmdAll = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.staStatus.SuspendLayout();
			this.SuspendLayout();
			// 
			// cmdSaveSequence
			// 
			this.cmdSaveSequence.Location = new System.Drawing.Point(281, 566);
			this.cmdSaveSequence.Name = "cmdSaveSequence";
			this.cmdSaveSequence.Size = new System.Drawing.Size(75, 23);
			this.cmdSaveSequence.TabIndex = 0;
			this.cmdSaveSequence.Text = "Save As...";
			this.cmdSaveSequence.UseVisualStyleBackColor = true;
			this.cmdSaveSequence.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// treChannels
			// 
			this.treChannels.BackColor = System.Drawing.Color.White;
			this.treChannels.ForeColor = System.Drawing.Color.Black;
			this.treChannels.FullRowSelect = true;
			this.treChannels.ImageKey = "Channel.ico";
			this.treChannels.ImageList = this.imlTreeIcons;
			this.treChannels.LineColor = System.Drawing.Color.Gray;
			this.treChannels.Location = new System.Drawing.Point(12, 116);
			this.treChannels.Name = "treChannels";
			this.treChannels.SelectedImageKey = "Channel.ico";
			this.treChannels.Size = new System.Drawing.Size(300, 404);
			this.treChannels.TabIndex = 7;
			this.treChannels.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treChannels_AfterSelect);
			this.treChannels.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treChannels_NodeMouseClick);
			// 
			// imlTreeIcons
			// 
			this.imlTreeIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlTreeIcons.ImageStream")));
			this.imlTreeIcons.TransparentColor = System.Drawing.Color.Transparent;
			this.imlTreeIcons.Images.SetKeyName(0, "track");
			this.imlTreeIcons.Images.SetKeyName(1, "channelGroup");
			this.imlTreeIcons.Images.SetKeyName(2, "rgbChannel");
			this.imlTreeIcons.Images.SetKeyName(3, "channel");
			this.imlTreeIcons.Images.SetKeyName(4, "redChannel");
			this.imlTreeIcons.Images.SetKeyName(5, "grnChannel");
			this.imlTreeIcons.Images.SetKeyName(6, "bluChannel");
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 58);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(75, 13);
			this.label2.TabIndex = 3;
			this.label2.Text = "Selections List";
			// 
			// cmdBrowseSequence
			// 
			this.cmdBrowseSequence.Location = new System.Drawing.Point(235, 34);
			this.cmdBrowseSequence.Name = "cmdBrowseSequence";
			this.cmdBrowseSequence.Size = new System.Drawing.Size(77, 20);
			this.cmdBrowseSequence.TabIndex = 2;
			this.cmdBrowseSequence.Text = "Browse...";
			this.cmdBrowseSequence.UseVisualStyleBackColor = true;
			this.cmdBrowseSequence.Click += new System.EventHandler(this.cmdBrowseSeq_Click);
			// 
			// txtSequenceFile
			// 
			this.txtSequenceFile.Enabled = false;
			this.txtSequenceFile.Location = new System.Drawing.Point(12, 34);
			this.txtSequenceFile.Name = "txtSequenceFile";
			this.txtSequenceFile.Size = new System.Drawing.Size(219, 20);
			this.txtSequenceFile.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 18);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 13);
			this.label1.TabIndex = 100;
			this.label1.Text = "Sequence File";
			// 
			// cmdBrowseMap
			// 
			this.cmdBrowseMap.Location = new System.Drawing.Point(235, 65);
			this.cmdBrowseMap.Name = "cmdBrowseMap";
			this.cmdBrowseMap.Size = new System.Drawing.Size(77, 20);
			this.cmdBrowseMap.TabIndex = 5;
			this.cmdBrowseMap.Text = "Load...";
			this.cmdBrowseMap.UseVisualStyleBackColor = true;
			this.cmdBrowseMap.Click += new System.EventHandler(this.cmdBrowseMap_Click);
			// 
			// txtMapFile
			// 
			this.txtMapFile.Enabled = false;
			this.txtMapFile.Location = new System.Drawing.Point(12, 74);
			this.txtMapFile.Name = "txtMapFile";
			this.txtMapFile.Size = new System.Drawing.Size(219, 20);
			this.txtMapFile.TabIndex = 4;
			// 
			// dlgOpenFile
			// 
			this.dlgOpenFile.FileName = "openFileDialog1";
			// 
			// cmdInvert
			// 
			this.cmdInvert.Location = new System.Drawing.Point(15, 546);
			this.cmdInvert.Name = "cmdInvert";
			this.cmdInvert.Size = new System.Drawing.Size(75, 23);
			this.cmdInvert.TabIndex = 12;
			this.cmdInvert.Text = "Invert";
			this.cmdInvert.UseVisualStyleBackColor = true;
			this.cmdInvert.Click += new System.EventHandler(this.cmdInvert_Click);
			// 
			// cmdSaveMap
			// 
			this.cmdSaveMap.Location = new System.Drawing.Point(235, 85);
			this.cmdSaveMap.Name = "cmdSaveMap";
			this.cmdSaveMap.Size = new System.Drawing.Size(77, 20);
			this.cmdSaveMap.TabIndex = 6;
			this.cmdSaveMap.Text = "Save As...";
			this.cmdSaveMap.UseVisualStyleBackColor = true;
			this.cmdSaveMap.Click += new System.EventHandler(this.cmdSaveMap_Click);
			// 
			// lblSelectionCount
			// 
			this.lblSelectionCount.AutoSize = true;
			this.lblSelectionCount.ForeColor = System.Drawing.SystemColors.Highlight;
			this.lblSelectionCount.Location = new System.Drawing.Point(74, 530);
			this.lblSelectionCount.Name = "lblSelectionCount";
			this.lblSelectionCount.Size = new System.Drawing.Size(13, 13);
			this.lblSelectionCount.TabIndex = 11;
			this.lblSelectionCount.Text = "0";
			this.lblSelectionCount.Click += new System.EventHandler(this.lblSelectionCount_Click);
			// 
			// cmdNothing
			// 
			this.cmdNothing.Location = new System.Drawing.Point(316, 568);
			this.cmdNothing.Name = "cmdNothing";
			this.cmdNothing.Size = new System.Drawing.Size(18, 19);
			this.cmdNothing.TabIndex = 59;
			this.cmdNothing.UseVisualStyleBackColor = true;
			// 
			// staStatus
			// 
			this.staStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pnlHelp,
            this.pnlProgress,
            this.pnlStatus,
            this.pnlAbout});
			this.staStatus.Location = new System.Drawing.Point(0, 601);
			this.staStatus.Name = "staStatus";
			this.staStatus.Size = new System.Drawing.Size(368, 24);
			this.staStatus.TabIndex = 61;
			// 
			// pnlHelp
			// 
			this.pnlHelp.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlHelp.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlHelp.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlHelp.ForeColor = System.Drawing.SystemColors.Highlight;
			this.pnlHelp.IsLink = true;
			this.pnlHelp.Name = "pnlHelp";
			this.pnlHelp.Size = new System.Drawing.Size(45, 19);
			this.pnlHelp.Text = "Help...";
			this.pnlHelp.Click += new System.EventHandler(this.pnlHelp_Click);
			// 
			// pnlProgress
			// 
			this.pnlProgress.Name = "pnlProgress";
			this.pnlProgress.Size = new System.Drawing.Size(100, 18);
			this.pnlProgress.Visible = false;
			// 
			// pnlStatus
			// 
			this.pnlStatus.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlStatus.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
			this.pnlStatus.Name = "pnlStatus";
			this.pnlStatus.Size = new System.Drawing.Size(123, 19);
			this.pnlStatus.Spring = true;
			// 
			// pnlAbout
			// 
			this.pnlAbout.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlAbout.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlAbout.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlAbout.ForeColor = System.Drawing.SystemColors.Highlight;
			this.pnlAbout.Name = "pnlAbout";
			this.pnlAbout.Size = new System.Drawing.Size(52, 19);
			this.pnlAbout.Text = "About...";
			this.pnlAbout.Click += new System.EventHandler(this.pnlAbout_Click);
			// 
			// prgProgress
			// 
			this.prgProgress.Location = new System.Drawing.Point(14, 277);
			this.prgProgress.Name = "prgProgress";
			this.prgProgress.Size = new System.Drawing.Size(340, 62);
			this.prgProgress.TabIndex = 9;
			this.prgProgress.Visible = false;
			// 
			// cmdClear
			// 
			this.cmdClear.Location = new System.Drawing.Point(96, 546);
			this.cmdClear.Name = "cmdClear";
			this.cmdClear.Size = new System.Drawing.Size(75, 23);
			this.cmdClear.TabIndex = 13;
			this.cmdClear.Text = "Clear";
			this.cmdClear.UseVisualStyleBackColor = true;
			this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
			// 
			// cmdAll
			// 
			this.cmdAll.Location = new System.Drawing.Point(177, 546);
			this.cmdAll.Name = "cmdAll";
			this.cmdAll.Size = new System.Drawing.Size(75, 23);
			this.cmdAll.TabIndex = 14;
			this.cmdAll.Text = "All";
			this.cmdAll.UseVisualStyleBackColor = true;
			this.cmdAll.Click += new System.EventHandler(this.cmdAll_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(15, 530);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(59, 13);
			this.label3.TabIndex = 10;
			this.label3.Text = "Selections:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(281, 551);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(81, 13);
			this.label4.TabIndex = 101;
			this.label4.Text = "New Sequence";
			// 
			// frmSplit
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(368, 625);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.cmdAll);
			this.Controls.Add(this.cmdClear);
			this.Controls.Add(this.prgProgress);
			this.Controls.Add(this.staStatus);
			this.Controls.Add(this.lblSelectionCount);
			this.Controls.Add(this.cmdSaveMap);
			this.Controls.Add(this.cmdInvert);
			this.Controls.Add(this.cmdSaveSequence);
			this.Controls.Add(this.treChannels);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cmdBrowseSequence);
			this.Controls.Add(this.txtSequenceFile);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cmdBrowseMap);
			this.Controls.Add(this.txtMapFile);
			this.Controls.Add(this.cmdNothing);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "frmSplit";
			this.Text = "Split-O-Rama";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSplit_FormClosing);
			this.Load += new System.EventHandler(this.frmSplit_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmSplit_Paint);
			this.staStatus.ResumeLayout(false);
			this.staStatus.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button cmdSaveSequence;
		private System.Windows.Forms.TreeView treChannels;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button cmdBrowseSequence;
		private System.Windows.Forms.TextBox txtSequenceFile;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button cmdBrowseMap;
		private System.Windows.Forms.TextBox txtMapFile;
		private System.Windows.Forms.OpenFileDialog dlgOpenFile;
		private System.Windows.Forms.SaveFileDialog dlgSaveFile;
		private System.Windows.Forms.ImageList imlTreeIcons;
		private System.Windows.Forms.Button cmdInvert;
		private System.Windows.Forms.Button cmdSaveMap;
		private System.Windows.Forms.Label lblSelectionCount;
		private System.Windows.Forms.Button cmdNothing;
		private System.Windows.Forms.ToolTip ttip;
		private System.Windows.Forms.StatusStrip staStatus;
		private System.Windows.Forms.ToolStripStatusLabel pnlHelp;
		private System.Windows.Forms.ToolStripStatusLabel pnlAbout;
		private System.Windows.Forms.ToolStripProgressBar pnlProgress;
		private System.Windows.Forms.ToolStripStatusLabel pnlStatus;
		private System.Windows.Forms.ProgressBar prgProgress;
		private System.Windows.Forms.Button cmdClear;
		private System.Windows.Forms.Button cmdAll;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
	}
}

