﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using LORUtils;


namespace SplitORama
{
	public partial class frmSplit : Form
	{
		private string seqFile = "";
		private string lastSeq = "";
		private string mapFile = "";
		private string lastMap = "";
		private Sequence seq = new Sequence();
		private int nodeIndex = LOR.UNDEFINED;
		private int selectionCount = 0;
		private int part = 1;
		private bool dirtyMap = false;
		private bool dirtySeq = false;
		private const string helpPage = "http://wizlights.com/util-o-rama/split-o-rama/default.html";

		//private List<TreeNode>[] siNodes;
		private List<List<TreeNode>> siNodes = new List<List<TreeNode>>();

		
		const char DELIM1 = '⬖';
		const char DELIM4 = '⬙';

		private	string[] trackNames = null;
		private int[] trackNums = null;
		private string[] channelGroupNames = null;
		private int[] channelGroupSIs = null;
		private string[] rgbChannelNames = null;
		private int[] rgbChannelSIs = null;
		private string[] channelNames = null;
		private int[] channelSIs = null;



		public frmSplit()
		{
			InitializeComponent();
		}

		private void cmdBrowseSeq_Click(object sender, EventArgs e)
		{
			string initDir = Sequence.SequenceFolder;
			string initFile = "";

			dlgOpenFile.Filter = "Musical Sequences (*.lms)|*.lms|Animated Sequences (*.las)|*.las";
			dlgOpenFile.DefaultExt = "*.lms";
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.CheckFileExists = true;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Multiselect = false;
			dlgOpenFile.Title = "Select First Sequence...";
			//pnlAll.Enabled = false;
			DialogResult result = dlgOpenFile.ShowDialog();

			if (result == DialogResult.OK)
			{
				seqFile = dlgOpenFile.FileName;

				FileInfo fi = new FileInfo(seqFile);
				Properties.Settings.Default.LastSequence = seqFile;
				Properties.Settings.Default.Save();

				txtSequenceFile.Text = utils.ShortenLongPath(seqFile, 80);
				seq.ReadSequenceFile(seqFile);
				utils.FillChannels(treChannels, seq, siNodes);
				part = 1;
				dirtySeq = false;

				//TODO if map file exists, ask if user wants to apply it


			} // end if (result = DialogResult.OK)
				//pnlAll.Enabled = true;
		} // end browse for First File

		private void frmSplit_Load(object sender, EventArgs e)
		{
			InitForm();
		}

		private void InitForm()
		{
			RestoreFormPosition();

			lastSeq = Properties.Settings.Default.LastSequence;
			lastMap = Properties.Settings.Default.LastMap;

			if (File.Exists(lastSeq))
			{
				seq.ReadSequenceFile(lastSeq);
				seqFile = lastSeq;
				utils.FillChannels(treChannels, seq, siNodes);
				txtSequenceFile.Text = utils.ShortenLongPath(seqFile, 80);
			}

			if (File.Exists(lastMap))
			{
				//TODO: Apply Map

			}






		}

		private void SaveFormPosition()
		{
			// Called with form is closed
			if (WindowState == FormWindowState.Normal)
			{
				Properties.Settings.Default.Location = Location;
				Properties.Settings.Default.Size = Size;
				Properties.Settings.Default.Minimized = false;
			}
			else
			{
				Properties.Settings.Default.Location = RestoreBounds.Location;
				Properties.Settings.Default.Size = RestoreBounds.Size;
				Properties.Settings.Default.Minimized = true;
			}
			Properties.Settings.Default.Save();

		} // End SaveFormPosition

		private void RestoreFormPosition()
		{
			// Called when form is loaded
			//TODO: This only gets the area of the first screen in a multi-screen setup

			int ileft = Properties.Settings.Default.Location.X;
			int itop = Properties.Settings.Default.Location.Y;
			int scrHt = Screen.PrimaryScreen.Bounds.Height;
			int scrWd = Screen.PrimaryScreen.Bounds.Width;


			if (itop > (scrHt - this.Height))
			{
				itop = scrHt - this.Height;
			}
			if (ileft > (scrWd - this.Width))
			{
				ileft = scrWd - this.Width;
			}
			
			
			// Should get all screens and figure out if size/placement of the form is valid
			//TODO: Restore form.WindowState and if maximized use RestoreBounds()
			this.SetDesktopLocation(ileft, itop);

		} // End RestoreFormPosition

		private void CloseForm()
		{
			SaveFormPosition();
		}



		private void frmSplit_FormClosing(object sender, FormClosingEventArgs e)
		{
			if (dirtySeq)
			{
				//TODO ask to save sequence
				//e.Cancel = true;
			}
			if (dirtyMap)
			{
				//TODO ask to save map
			}





			CloseForm();
		}

		private void treChannels_AfterSelect(object sender, TreeViewEventArgs e)
		{
			utils.ChanInfo nodeTag;
			bool ignoreRGB = false;

			if (e.Node.Parent != null)
			{
				nodeTag = (utils.ChanInfo)e.Node.Parent.Tag;
				if (nodeTag.tableType == tableType.rgbChannel)
				{
					// If the node clicked on has a parent,
					// and that parent is an RGBchannel,
					// Then this is an RGB sub channel,
					// So IGNORE this click
					ignoreRGB = true;
				}

			}

			if (!ignoreRGB)
			{
				nodeTag = (utils.ChanInfo)e.Node.Tag;
				string foo = e.Node.Text;  //! FOR DEBUGGING, REMOVE LATER
				if (e.Node.IsSelected)
				{
					bool wasSelected = e.Node.Checked;
					if (wasSelected)
					{
						// WAS selected, so now have to deselect
						SelectNodes(nodeTag.savedIndex, false, true);
						//treChannels.SelectedNode = null;
						//treChannels.SelectedNode.Selected = false
						dirtyMap = true;
						dirtySeq = true;

					}
					else
					{
						// WAS NOT selected, so now have to select
						SelectNodes(nodeTag.savedIndex, true, true);
						dirtyMap = true;
						dirtySeq = true;
					}
					//e.Node.IsSelected = false;

				}
				//treChannels.
				lblSelectionCount.Text = selectionCount.ToString();
				//? Why doesn't this work?
				//cmdSaveMap.Enabled = (selectionCount > 0);
				if (selectionCount > 0)
				{
					cmdSaveMap.Enabled = true;
					btnSave.Enabled = true;
				}
				else
				{
					cmdSaveMap.Enabled = false;
					btnSave.Enabled = false;
				}

			} // NOT RGB
			//cmdNothing.Focus();
			txtMapFile.Focus();


		}

		void SelectNodes(int nodeSI, bool select, bool andChildren)
		{
			utils.ChanInfo nodeTag;
			List<TreeNode> qlist;

			//if (siNodes[nodeSI]!= null)
			if (nodeSI == LOR.UNDEFINED)
			{
				// WHY?
				int xx = 1;
			}
			else
			{
				qlist = siNodes[nodeSI];
				if (qlist.Count > 0)
				{
					//if (siNodes[nodeSI].Length > 0)
					//if (siNodes[nodeSI])
					//{
					//foreach (TreeNode nOde in siNodes[nodeSI])
					for (int q = 0; q < siNodes[nodeSI].Count; q++)
					{
						TreeNode nOde = siNodes[nodeSI][q];
						if (select)
						{
							if (!nOde.Checked) // sanity check, should not be checked
							{
								nOde.Checked = true;
								selectionCount++;
								nOde.ForeColor = Color.Yellow;
								nOde.BackColor = Color.DarkBlue;
								if (andChildren)
								{
									if (nOde.Nodes.Count > 0)
									{
										foreach (TreeNode childNode in nOde.Nodes)
										{
											nodeTag = (utils.ChanInfo)childNode.Tag;
											SelectNodes(nodeTag.savedIndex, select, true);
										}
									}
								}
								if (nOde.Parent != null)
								{
									nodeTag = (utils.ChanInfo)nOde.Parent.Tag;
									SelectNodes(nodeTag.savedIndex, select, false);
								}
							} // node.!checked
						}
						else // !select
						{
							if (nOde.Checked) // sanity check, should be checked
							{
								nOde.Checked = false;
								selectionCount--;
								nOde.ForeColor = SystemColors.WindowText;
								nOde.BackColor = SystemColors.Window;
								if (andChildren)
								{
									if (nOde.Nodes.Count > 0)
									{
										foreach (TreeNode childNode in nOde.Nodes)
										{
											nodeTag = (utils.ChanInfo)childNode.Tag;
											SelectNodes(nodeTag.savedIndex, select, true);
										}
									}
								}
								if (nOde.Parent != null)
								{
									if (!HasSelectedChildren(nOde.Parent))
									{
										nodeTag = (utils.ChanInfo)nOde.Parent.Tag;
										SelectNodes(nodeTag.savedIndex, select, false);
									}
								}
							} // node.checked
						} // if (select)
					} // foreach (TreeNode nOde in siNodes[nodeSI])
						//}
				} // siNodes[nodeSI].Count > 0
				else
				{
					// siNodes[nodeSI].Count = 0
					//? Why Not?
					int x = 1;
				}
			}
		} // end SelectNode

		private bool HasSelectedChildren(TreeNode nOde)
		{
			bool ret = false;
			if (nOde.Nodes.Count > 0)
			{
				foreach (TreeNode childNode in nOde.Nodes)
				{
					ret = childNode.Checked;
					if (ret)
					{
						break;
					}
				}
			}
			return ret;
		} // end HasSelectedChildren

		private void treChannels_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
		{
		}

		private void cmdInvert_Click(object sender, EventArgs e)
		{
			foreach (TreeNode nOde in treChannels.Nodes)
			{
				if (nOde.Nodes.Count == 0)
				{
					if (nOde.Checked)
					{
						nOde.Checked = false;
						nOde.BackColor = SystemColors.Window;
						nOde.ForeColor = SystemColors.WindowText;
					}
					else
					{
						nOde.Checked = true;
						nOde.BackColor = Color.DarkBlue;
						nOde.ForeColor = Color.Yellow;
					}
				} // has NO child nodes
			} // foreach nodes
			foreach (TreeNode nOde in treChannels.Nodes)
			{
				if (nOde.Nodes.Count > 0)
				{
					bool childSel = HasSelectedChildren(nOde);
					if (childSel)
					{
						if (!nOde.Checked)
						{
							nOde.Checked = true;
							nOde.BackColor = Color.DarkBlue;
							nOde.ForeColor = Color.Yellow;
						}
					}
					else
					{
						if (nOde.Checked)
						{
							nOde.Checked = false;
							nOde.BackColor = SystemColors.Window;
							nOde.ForeColor = SystemColors.WindowText;
						}
					} // some child nodes are selected
				} // has child nodes
			} // foreach nodes
		} // end Invert Selection

		private void CopySelectionsToSequence(TreeNodeCollection nOdes)
		{
			utils.ChanInfo nodeTag;
			foreach (TreeNode nOde in nOdes)
			{
				nodeTag = (utils.ChanInfo)nOde.Tag;
				if (nodeTag.tableType == tableType.track)
				{
					seq.tracks[nodeTag.objIndex].selected = nOde.Checked;
				}
				if (nodeTag.tableType == tableType.channel)
				{
					seq.channels[nodeTag.objIndex].selected = nOde.Checked;
				}
				if (nodeTag.tableType == tableType.rgbChannel)
				{
					seq.rgbChannels[nodeTag.objIndex].selected = nOde.Checked;
				}
				if (nodeTag.tableType == tableType.channelGroup)
				{
					seq.channelGroups[nodeTag.objIndex].selected = nOde.Checked;
				}
				if (nOde.Nodes.Count > 0)
				{
					CopySelectionsToSequence(nOde.Nodes);
				}
			} // loop thru nodes

			// Select ALL timing grids
			for (int t = 0; t < seq.timingGridCount; t++)
			{
				seq.timingGrids[t].selected = true;
			}
		} // end CopySelectionToSequence

		private void btnSave_Click(object sender, EventArgs e)
		{
			string newFileIn;
			string newFileOut;
			string ext = Path.GetExtension(seqFile).ToLower();
			if (ext == ".las")
			{
				dlgSaveFile.Filter = "Animated Sequences (*.las)|*.las";
			}
			if (ext == ".lms")
			{
				dlgSaveFile.Filter = "Musical Sequences (*.lms)|*.lms";
			}
			dlgSaveFile.FilterIndex = 1;
			//dlgSaveFile.FileName = Path.GetFullPath(seqFile) + Path.GetFileNameWithoutExtension(seqFile) + " Part " + part.ToString() + ext;
			dlgSaveFile.CheckPathExists = true;
			dlgSaveFile.InitialDirectory = Path.GetFullPath(seqFile);
			dlgSaveFile.DefaultExt = ext;
			dlgSaveFile.OverwritePrompt = true;
			dlgSaveFile.Title = "Save Partial Sequence As...";
			dlgSaveFile.SupportMultiDottedExtensions = true;
			dlgSaveFile.ValidateNames = true;
			newFileIn = Path.GetFileNameWithoutExtension(seqFile) + " Part " + part.ToString(); // + ext;
			//newFileIn = "Part " + part.ToString() + " of " + Path.GetFileNameWithoutExtension(seqFile);
			//newFileIn = "Part Mother Fucker!!";
			dlgSaveFile.FileName = newFileIn;
			DialogResult result = dlgSaveFile.ShowDialog(this);
			if (result == DialogResult.OK)
			{
				newFileOut = dlgSaveFile.FileName;
				int pos = newFileOut.IndexOf("Part ");
				if (pos < 0)
				{
					string msg = "Dadgummit!";
					DialogResult r = MessageBox.Show(this, msg, "Failure!", MessageBoxButtons.OK, MessageBoxIcon.Stop, MessageBoxDefaultButton.Button1);
					int xxx = 1;
				}
				else
				{
					CopySelectionsToSequence(treChannels.Nodes);
					seq.WriteSequenceFileInDisplayOrder(newFileOut, true);
					part++;
					dirtySeq = false;
				}
			}
		} // end Save File As

		private void cmdSaveMap_Click(object sender, EventArgs e)
		{
			dlgSaveFile.DefaultExt = "ChSel";
			dlgSaveFile.Filter = "Channel Selections|*.ChSel";
			dlgSaveFile.FilterIndex = 0;
			string initDir = Sequence.SequenceFolder + "Channel Maps\\";
			string initFile = "";
			if (mapFile.Length > 4)
			{
				string pth = Path.GetFullPath(mapFile);
				if (Directory.Exists(pth))
				{
					initDir = pth;
				}
				if (File.Exists(mapFile))
				{
					initFile = Path.GetFileName(mapFile);
				}
				else
				{
					if (File.Exists(seqFile))
					{
						initFile = Path.GetFileNameWithoutExtension(seqFile) +"Channel Selections";
					}
				}
			}
			dlgSaveFile.FileName = initFile;
			dlgSaveFile.InitialDirectory = initDir;
			dlgSaveFile.OverwritePrompt = true;
			dlgSaveFile.CheckPathExists = true;
			dlgSaveFile.DefaultExt = "ChSel";
			dlgSaveFile.SupportMultiDottedExtensions = true;
			dlgSaveFile.ValidateNames = true;
			dlgSaveFile.Title = "Save Channel Selections As...";

			DialogResult dr = dlgSaveFile.ShowDialog();
			if (dr == DialogResult.OK)
			{

				string mapTemp = System.IO.Path.GetTempPath();
				mapTemp += Path.GetFileName(dlgSaveFile.FileName);
				int mapErr = SaveMap(mapTemp);
				if (mapErr == 0)
				{
					mapFile = dlgSaveFile.FileName;
					if (File.Exists(mapFile))
					{
						//TODO: Add Exception Catch
						File.Delete(mapFile);
					}
					File.Copy(mapTemp, mapFile);
					File.Delete(mapTemp);
					dirtyMap = false;
					cmdSaveMap.Enabled = dirtyMap;
				} // end no errors saving map
			} // end dialog result = OK
		} // end SaveMapAs...

		private int SaveMap(string fileName)
		{
			int ret = 0;

			int lineCount = 0;
			StreamWriter writer = new StreamWriter(fileName);
			string lineOut = ""; // line to be written out, gets modified if necessary
													 //int pos1 = LOR.UNDEFINED; // positions of certain key text in the line

			SaveSelectionsToMap(writer, treChannels.Nodes);

			writer.Close();
			return ret;
		} // end SaveMap

		private void SaveSelectionsToMap(StreamWriter writer, TreeNodeCollection nOdes)
		{
			string lineOut = "";
			utils.ChanInfo nodeTag;
			foreach (TreeNode nOde in nOdes)
			{
				if (nOde.Checked)
				{
					nodeTag = (utils.ChanInfo)nOde.Tag;
					tableType type;
					type = nodeTag.tableType;
					lineOut = nodeTag.tableType.ToString() + DELIM1;
					lineOut += nOde.Text + DELIM1;
					lineOut += nodeTag.savedIndex.ToString() + DELIM1;
					lineOut += nodeTag.objIndex.ToString() + DELIM1;
					if (type == tableType.channel)
					{
						lineOut += seq.channels[nodeTag.objIndex].output.ToString();
					}
					else
					{
						lineOut += "None" + DELIM4 + "-1" + DELIM4 + "-1" + DELIM4 + "-1"; // + DELIM2;
					}

					writer.WriteLine(lineOut);

					if (nOde.Nodes.Count > 0)
					{
						SaveSelectionsToMap(writer, nOde.Nodes);
					} // has children
				} // node checked
			} // loop thru nodes
		} // end SaveSelectionsToMap

		private void cmdBrowseMap_Click(object sender, EventArgs e)
		{
			dlgOpenFile.DefaultExt = "ChSel";
			dlgOpenFile.Filter = "Channel Selections|*.ChSel";
			dlgOpenFile.DefaultExt = "ChMap";
			dlgOpenFile.FilterIndex = 0;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.SupportMultiDottedExtensions = true;
			dlgOpenFile.ValidateNames = true;
			
			string initDir = Sequence.SequenceFolder + "Channel Maps\\";
			string initFile = "";
			if (mapFile.Length > 4)
			{
				string pth = Path.GetFullPath(mapFile);
				if (Directory.Exists(pth))
				{
					initDir = pth;
				}
				if (File.Exists(mapFile))
				{
					initFile = Path.GetFileName(mapFile);
				}
			}
			dlgOpenFile.FileName = initFile;
			dlgOpenFile.InitialDirectory = initDir;
			dlgOpenFile.CheckPathExists = true;
			dlgOpenFile.Title = "Load-Apply Channel Selections..";

			DialogResult dr = dlgOpenFile.ShowDialog(this);
			if (dr == DialogResult.OK)
			{
				mapFile = dlgOpenFile.FileName;
				txtMapFile.Text = Path.GetFileName(mapFile);
				Properties.Settings.Default.LastMap = mapFile;
				Properties.Settings.Default.Save();
				ReadApplyMap(dlgOpenFile.FileName, true);
				dirtyMap = false;
				//btnSaveMap.Enabled = dirtyMap;
			} // end dialog result = OK

		} // end cmdBrowseMap_Click

		private int ReadApplyMap(string mapFilename, bool fuzzy)
		{
			//////////////////////////////////////////////
			// PART ONE -	build sorted arrays of names //
			////////////////////////////////////////////
			FillNameLists();
			Array.Sort(trackNames, trackNums);
			Array.Sort(channelGroupNames, channelGroupSIs);
			Array.Sort(rgbChannelNames, rgbChannelSIs);
			Array.Sort(channelNames, channelSIs);

			//////////////////////////////////////////////
			// PART TWO -	search sorted arrays of names //
			////////////////////////////////////////////
			int noFind = 0;
			int lineCount = 0;
			int foundSI = LOR.UNDEFINED;
			int foundIdx = LOR.UNDEFINED;
			StreamReader reader = new StreamReader(mapFilename);
			string lineIn = ""; // line to be read in, gets parsed as requited
			string[] parts = null;
			//string type = "";
			tableType objType = tableType.None;
			string objName = "";
			string output = "";
			ClearSelections(treChannels.Nodes);

			while ((lineIn = reader.ReadLine()) != null)
			{
				if (lineIn.Length > 7)
				{
					parts = lineIn.Split(DELIM1);
					if (parts.Length == 4)
					{
						objType = (tableType) Enum.Parse(typeof(tableType), parts[0]);
						objName = parts[1];
						if (objType == tableType.track)
						{
							foundIdx = utils.BTreeFindName(trackNames, objName);
							if (foundIdx == LOR.UNDEFINED)
							{
								foundIdx = utils.FuzzyFindName(trackNames, objName);
							}
							if (foundIdx != LOR.UNDEFINED)
							{
								foundSI = trackNums[foundIdx];
								SelectNodes(foundSI, true, true);
;							}
							else
							{
								//TODO Log Track Not Found
							}
						}
					} // line split into exactly 4 parts
				} // end if length > 7

				if (nodeIndex == null)
				{
				
				}


			} // end while more lines



			reader.Close();
			return noFind;
		} // end LoadApplyMap

		private void FillNameLists()
		{
			Array.Resize(ref trackNames, seq.trackCount);
			Array.Resize(ref trackNums, seq.trackCount);
			Array.Resize(ref channelGroupNames, seq.channelGroupCount);
			Array.Resize(ref channelGroupSIs, seq.channelGroupCount);
			Array.Resize(ref rgbChannelNames, seq.rgbChannelCount);
			Array.Resize(ref rgbChannelSIs, seq.rgbChannelCount);
			Array.Resize(ref channelNames, seq.channelCount);
			Array.Resize(ref channelSIs, seq.channelCount);


			for (int tr = 0; tr < seq.trackCount; tr++)
			{
				trackNames[tr] = seq.tracks[tr].name;
				trackNums[tr] = tr;
			}
			for (int chg = 0; chg< seq.channelGroupCount; chg++)
			{
				channelGroupNames[chg] = seq.channelGroups[chg].name;
				channelGroupSIs[chg] = seq.channelGroups[chg].savedIndex;
			}
			for (int rch = 0; rch<seq.rgbChannelCount; rch++)
			{
				rgbChannelNames[rch] = seq.rgbChannels[rch].name;
				rgbChannelSIs[rch] = seq.rgbChannels[rch].savedIndex;
			}
			for (int ch=0; ch < seq.channelCount; ch++)
			{
				channelNames[ch] = seq.channels[ch].name;
				channelSIs[ch] = seq.channels[ch].savedIndex;
			}
			
		} // end Fill Name Lists

		private void ClearSelections(TreeNodeCollection nOdes)
		{
			foreach (TreeNode nOde in nOdes)
			{
				if (nOde.Checked)
				{
					nOde.Checked = false;
					nOde.ForeColor = SystemColors.WindowText;
					nOde.BackColor = SystemColors.Window;
				}
				if (nOde.Nodes.Count > 0)
				{
					ClearSelections(nOde.Nodes);
				}
			} // end for each node
		} // end ClearSelections



		private void pnlAbout_Click(object sender, EventArgs e)
		{
			Form aboutBox = new frmAbout();
			//aboutBox.Icon = this.Icon;
			//aboutBox.InitForm();
			
			aboutBox.Show(this);

		}

		private void pnlHelp_Click(object sender, EventArgs e)
		{
			System.Diagnostics.Process.Start(helpPage);
		}
	} // end frmSplit
} // end namespace SplitORama
