﻿namespace SplitORama
{
	partial class frmSplit
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSplit));
			this.btnSave = new System.Windows.Forms.Button();
			this.treChannels = new System.Windows.Forms.TreeView();
			this.imlTreeIcons = new System.Windows.Forms.ImageList(this.components);
			this.label2 = new System.Windows.Forms.Label();
			this.cmdBrowseSeq = new System.Windows.Forms.Button();
			this.txtSequenceFile = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.cmdBrowseMap = new System.Windows.Forms.Button();
			this.txtMapFile = new System.Windows.Forms.TextBox();
			this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
			this.dlgSaveFile = new System.Windows.Forms.SaveFileDialog();
			this.cmdInvert = new System.Windows.Forms.Button();
			this.cmdSaveMap = new System.Windows.Forms.Button();
			this.lblSelectionCount = new System.Windows.Forms.Label();
			this.cmdNothing = new System.Windows.Forms.Button();
			this.ttip = new System.Windows.Forms.ToolTip(this.components);
			this.staStatus = new System.Windows.Forms.StatusStrip();
			this.pnlHelp = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlProgress = new System.Windows.Forms.ToolStripProgressBar();
			this.pnlStatus = new System.Windows.Forms.ToolStripStatusLabel();
			this.pnlAbout = new System.Windows.Forms.ToolStripStatusLabel();
			this.prgProgress = new System.Windows.Forms.ProgressBar();
			this.staStatus.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnSave
			// 
			this.btnSave.Enabled = false;
			this.btnSave.Location = new System.Drawing.Point(161, 555);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(151, 30);
			this.btnSave.TabIndex = 55;
			this.btnSave.Text = "Save As...";
			this.btnSave.UseVisualStyleBackColor = true;
			this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
			// 
			// treChannels
			// 
			this.treChannels.BackColor = System.Drawing.Color.White;
			this.treChannels.FullRowSelect = true;
			this.treChannels.ImageKey = "Channel.ico";
			this.treChannels.ImageList = this.imlTreeIcons;
			this.treChannels.Location = new System.Drawing.Point(12, 116);
			this.treChannels.Name = "treChannels";
			this.treChannels.SelectedImageKey = "Channel.ico";
			this.treChannels.Size = new System.Drawing.Size(300, 404);
			this.treChannels.TabIndex = 54;
			this.treChannels.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treChannels_AfterSelect);
			this.treChannels.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treChannels_NodeMouseClick);
			// 
			// imlTreeIcons
			// 
			this.imlTreeIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlTreeIcons.ImageStream")));
			this.imlTreeIcons.TransparentColor = System.Drawing.Color.Transparent;
			this.imlTreeIcons.Images.SetKeyName(0, "track");
			this.imlTreeIcons.Images.SetKeyName(1, "channelGroup");
			this.imlTreeIcons.Images.SetKeyName(2, "rgbChannel");
			this.imlTreeIcons.Images.SetKeyName(3, "channel");
			this.imlTreeIcons.Images.SetKeyName(4, "redChannel");
			this.imlTreeIcons.Images.SetKeyName(5, "grnChannel");
			this.imlTreeIcons.Images.SetKeyName(6, "bluChannel");
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(12, 58);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(75, 13);
			this.label2.TabIndex = 53;
			this.label2.Text = "Selections List";
			// 
			// cmdBrowseSeq
			// 
			this.cmdBrowseSeq.Location = new System.Drawing.Point(235, 34);
			this.cmdBrowseSeq.Name = "cmdBrowseSeq";
			this.cmdBrowseSeq.Size = new System.Drawing.Size(77, 20);
			this.cmdBrowseSeq.TabIndex = 52;
			this.cmdBrowseSeq.Text = "Browse...";
			this.cmdBrowseSeq.UseVisualStyleBackColor = true;
			this.cmdBrowseSeq.Click += new System.EventHandler(this.cmdBrowseSeq_Click);
			// 
			// txtSequenceFile
			// 
			this.txtSequenceFile.Enabled = false;
			this.txtSequenceFile.Location = new System.Drawing.Point(12, 34);
			this.txtSequenceFile.Name = "txtSequenceFile";
			this.txtSequenceFile.Size = new System.Drawing.Size(219, 20);
			this.txtSequenceFile.TabIndex = 51;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 18);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(75, 13);
			this.label1.TabIndex = 50;
			this.label1.Text = "Sequence File";
			// 
			// cmdBrowseMap
			// 
			this.cmdBrowseMap.Location = new System.Drawing.Point(235, 65);
			this.cmdBrowseMap.Name = "cmdBrowseMap";
			this.cmdBrowseMap.Size = new System.Drawing.Size(77, 20);
			this.cmdBrowseMap.TabIndex = 49;
			this.cmdBrowseMap.Text = "Load...";
			this.cmdBrowseMap.UseVisualStyleBackColor = true;
			this.cmdBrowseMap.Click += new System.EventHandler(this.cmdBrowseMap_Click);
			// 
			// txtMapFile
			// 
			this.txtMapFile.Enabled = false;
			this.txtMapFile.Location = new System.Drawing.Point(12, 74);
			this.txtMapFile.Name = "txtMapFile";
			this.txtMapFile.Size = new System.Drawing.Size(219, 20);
			this.txtMapFile.TabIndex = 48;
			// 
			// dlgOpenFile
			// 
			this.dlgOpenFile.FileName = "openFileDialog1";
			// 
			// cmdInvert
			// 
			this.cmdInvert.Enabled = false;
			this.cmdInvert.Location = new System.Drawing.Point(15, 526);
			this.cmdInvert.Name = "cmdInvert";
			this.cmdInvert.Size = new System.Drawing.Size(90, 30);
			this.cmdInvert.TabIndex = 56;
			this.cmdInvert.Text = "Invert Selection";
			this.cmdInvert.UseVisualStyleBackColor = true;
			this.cmdInvert.Click += new System.EventHandler(this.cmdInvert_Click);
			// 
			// cmdSaveMap
			// 
			this.cmdSaveMap.Enabled = false;
			this.cmdSaveMap.Location = new System.Drawing.Point(235, 85);
			this.cmdSaveMap.Name = "cmdSaveMap";
			this.cmdSaveMap.Size = new System.Drawing.Size(77, 20);
			this.cmdSaveMap.TabIndex = 57;
			this.cmdSaveMap.Text = "Save As...";
			this.cmdSaveMap.UseVisualStyleBackColor = true;
			this.cmdSaveMap.Click += new System.EventHandler(this.cmdSaveMap_Click);
			// 
			// lblSelectionCount
			// 
			this.lblSelectionCount.AutoSize = true;
			this.lblSelectionCount.ForeColor = System.Drawing.SystemColors.Highlight;
			this.lblSelectionCount.Location = new System.Drawing.Point(324, 127);
			this.lblSelectionCount.Name = "lblSelectionCount";
			this.lblSelectionCount.Size = new System.Drawing.Size(13, 13);
			this.lblSelectionCount.TabIndex = 58;
			this.lblSelectionCount.Text = "0";
			// 
			// cmdNothing
			// 
			this.cmdNothing.Location = new System.Drawing.Point(203, 561);
			this.cmdNothing.Name = "cmdNothing";
			this.cmdNothing.Size = new System.Drawing.Size(18, 19);
			this.cmdNothing.TabIndex = 59;
			this.cmdNothing.UseVisualStyleBackColor = true;
			// 
			// staStatus
			// 
			this.staStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pnlHelp,
            this.pnlProgress,
            this.pnlStatus,
            this.pnlAbout});
			this.staStatus.Location = new System.Drawing.Point(0, 592);
			this.staStatus.Name = "staStatus";
			this.staStatus.Size = new System.Drawing.Size(368, 24);
			this.staStatus.TabIndex = 61;
			// 
			// pnlHelp
			// 
			this.pnlHelp.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlHelp.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlHelp.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlHelp.ForeColor = System.Drawing.SystemColors.Highlight;
			this.pnlHelp.IsLink = true;
			this.pnlHelp.Name = "pnlHelp";
			this.pnlHelp.Size = new System.Drawing.Size(45, 19);
			this.pnlHelp.Text = "Help...";
			this.pnlHelp.Click += new System.EventHandler(this.pnlHelp_Click);
			// 
			// pnlProgress
			// 
			this.pnlProgress.Name = "pnlProgress";
			this.pnlProgress.Size = new System.Drawing.Size(100, 18);
			this.pnlProgress.Visible = false;
			// 
			// pnlStatus
			// 
			this.pnlStatus.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlStatus.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
			this.pnlStatus.Name = "pnlStatus";
			this.pnlStatus.Size = new System.Drawing.Size(256, 19);
			this.pnlStatus.Spring = true;
			// 
			// pnlAbout
			// 
			this.pnlAbout.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
			this.pnlAbout.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
			this.pnlAbout.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlAbout.ForeColor = System.Drawing.SystemColors.Highlight;
			this.pnlAbout.Name = "pnlAbout";
			this.pnlAbout.Size = new System.Drawing.Size(52, 19);
			this.pnlAbout.Text = "About...";
			this.pnlAbout.Click += new System.EventHandler(this.pnlAbout_Click);
			// 
			// prgProgress
			// 
			this.prgProgress.Location = new System.Drawing.Point(14, 277);
			this.prgProgress.Name = "prgProgress";
			this.prgProgress.Size = new System.Drawing.Size(340, 62);
			this.prgProgress.TabIndex = 62;
			this.prgProgress.Visible = false;
			// 
			// frmSplit
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(368, 616);
			this.Controls.Add(this.prgProgress);
			this.Controls.Add(this.staStatus);
			this.Controls.Add(this.lblSelectionCount);
			this.Controls.Add(this.cmdSaveMap);
			this.Controls.Add(this.cmdInvert);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.treChannels);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cmdBrowseSeq);
			this.Controls.Add(this.txtSequenceFile);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cmdBrowseMap);
			this.Controls.Add(this.txtMapFile);
			this.Controls.Add(this.cmdNothing);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "frmSplit";
			this.Text = "Split-O-Rama";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSplit_FormClosing);
			this.Load += new System.EventHandler(this.frmSplit_Load);
			this.staStatus.ResumeLayout(false);
			this.staStatus.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.TreeView treChannels;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button cmdBrowseSeq;
		private System.Windows.Forms.TextBox txtSequenceFile;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button cmdBrowseMap;
		private System.Windows.Forms.TextBox txtMapFile;
		private System.Windows.Forms.OpenFileDialog dlgOpenFile;
		private System.Windows.Forms.SaveFileDialog dlgSaveFile;
		private System.Windows.Forms.ImageList imlTreeIcons;
		private System.Windows.Forms.Button cmdInvert;
		private System.Windows.Forms.Button cmdSaveMap;
		private System.Windows.Forms.Label lblSelectionCount;
		private System.Windows.Forms.Button cmdNothing;
		private System.Windows.Forms.ToolTip ttip;
		private System.Windows.Forms.StatusStrip staStatus;
		private System.Windows.Forms.ToolStripStatusLabel pnlHelp;
		private System.Windows.Forms.ToolStripStatusLabel pnlAbout;
		private System.Windows.Forms.ToolStripProgressBar pnlProgress;
		private System.Windows.Forms.ToolStripStatusLabel pnlStatus;
		private System.Windows.Forms.ProgressBar prgProgress;
	}
}

