﻿using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace LORUtils
{
	internal enum deviceType
	{ None, LOR, DMX, Digital };

	public enum effectType { None, intensity, shimmer, twinkle, DMX }

	internal enum timingGridType
	{ None, freeform, fixedGrid };

	internal enum tableType
	{ None, channel, rgbChannel, channelGroup }

	internal class channel
	{
		public string name = "";
		public long color = 0;
		public long centiseconds = 0;
		public deviceType deviceType = deviceType.None;
		public int circuit = -1;
		public int network = -1;
		public int unit = -1;
		public int savedIndex = -1;
		//public int firstEffectIndex = -1;
		//public int finalEffectIndex = -1;
		public bool written = false;

		public effect[] effects;
		public int effectCount = 0;

		public static	string getSequenceFolder()
		{
			const string keyName = "HKEY_CURRENT_USER\\SOFTWARE\\Light-O-Rama\\Shared";
			string userDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
			string fldr = (string)Registry.GetValue(keyName, "NonAudioPath", userDocs);
			return fldr;
		} // End getSequenceFolder



		public void AddEffect(effect newEffect)
		{
			Array.Resize(ref effects, effectCount + 1);
			effects[effectCount] = newEffect;
		}

		//TODO: add RemoveEffect procedure
		//TODO: add SortEffects procedure (by startCentisecond)

	}

	internal class savedIndex
	{
		// savedIndexes are like array indexes or database record numbers.
		// They start at 0 (zero) and range up to the count-1.
		// -1 (minus one) is assigned to new channels/groups at creation, but is not a
		// valid savedIndex.
		// A new savedIndex will be assigned to channels, RGB channels, or channel groups
		// when added to a sequence if they don't already have one.
		// (existing saved index will not be overwritten.)
		// savedIndexes may not be duplicated and/or skipped
		// Every channel, RGB channel, and channel group must have a savedIndex.
		// The savedIndex has no affect on the order items are displayed.
		// savedIDs used by TimingGrids are not the same as savedIndexes.
		public tableType objType = tableType.None;
		public int objIndex = -1;
	}

	internal class rgbChannel
	{
		public string name = "";
		public long totalCentiseconds = 0;
		public int savedIndex =-1;
		public int redChannelIndex =-1;  // index/position in the channels[] array
		public int grnChannelIndex =-1;
		public int bluChannelIndex =-1;
		public int redSavedIndex =-1;
		public int grnSavedIndex =-1;
		public int bluSavedIndex =-1;
		public bool written = false;
	}

	internal class channelGroup : Sequence
	{
		// Channel Groups can contain regular channels, RGB Channels, and other groups.
		// Groups can be nested many levels deep (limit?).
		// channels and other groups may be in more than one group.
		// Don't create circular references of groups in each other.
		public int channelIndex =-1;
		public int channelSavedIndex =-1;
		public string name = "";
		public long totalCentiSeconds = 0;
		public int savedIndex = -1;
		public int[] itemSavedIndexes;
		public int itemCount = 0;
		public bool written = false;

		public void AddItem(int itemSavedIndex)
		{
			bool alreadyAdded = false;
			for (int i = 0; i < itemCount; i++)
			{
				if (itemSavedIndex == itemSavedIndexes[i])
				{
					//TODO: Using saved index, look up name of item being added
					string sMsg = "This item has already been added to this Channel Group '" + name + "'.";
					DialogResult rs = MessageBox.Show(sMsg, "Channel Groups", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					if (System.Diagnostics.Debugger.IsAttached)
						System.Diagnostics.Debugger.Break();
					//TODO: Make this just a warning, put "add" code below into an else block
					//TODO: Do the same with Tracks
					alreadyAdded = true;
					i=itemCount; // Break out of loop
				}
			}
			if (!alreadyAdded)
			{
				Array.Resize(ref itemSavedIndexes, itemCount + 3);
				itemSavedIndexes[itemCount] = itemSavedIndex;
				itemCount++;
			}
		}

		//TODO: add RemoveItem procedure
	}

	/*
	internal class channelGroupItem
	{
		public int channelGroupListIndex;
		public int GroupItemSavedIndex;
		//public int channelSavedIndex;
	}
	*/

	internal class effect
	{
		//public int channelIndex = -1;
		//public int savedIndex = -1;
		public effectType type = effectType.None;
		public long startCentisecond = -1;
		public long endCentisecond = 9999999999L;
		public int intensity = -1;
		public int startIntensity = -1;
		public int endIntensity = -1;
	}

	internal class timingGrid
	{
		// Tracks must have a timing grid assigned.
		// All sequences must contain at least one track, ergo all sequences neet at least one timing grid.
		public string name = "";
		// SaveID is like savedIndex for channels, but separate.
		// Same rules apply, see savedIndex above
		public int saveID = -1;
		public timingGridType type = timingGridType.None;
		public int spacing = -1;
		public long[] timings;
		public int itemCount = 0;

		public void AddTiming(long time)
		{
			Array.Resize(ref timings, itemCount + 1);
			timings[itemCount] = time;
			itemCount++;
		}
		//TODO: add RemovePosition
		//TODO: add Sorttimings
	}

	/*
	internal class timingGridItem
	{
		public int gridIndex = -1;
		public long centisecond = -1;
	}
	*/

	internal class track
	{
		// Tracks are the ultimate top-level groups.
		// They do not have savedIndexes.
		// channels, RGB channels, and channel groups will not bee displayed
		// and will not be accessible unless added to a track
		// or a subitem of a group in a track.
		// All sequences must have at least one track.
		public string name = "";
		public long totalCentiseconds = 0;
		public int timingGridIndex = -1;
		public int timingGridSaveID = -1;
		public int[] itemSavedIndexes;
		public int itemCount;

		public void AddItem(int itemSavedIndex)
		{
			for (int i = 0; i < itemCount; i++)
			{
				if (itemSavedIndex == itemSavedIndexes[i])
				{
					string sMsg = "Item being Added to a Track '" + name + "' already exists in that Track!";
					DialogResult rs = MessageBox.Show(sMsg, "Tracks", MessageBoxButtons.OK, MessageBoxIcon.Error);
					if (System.Diagnostics.Debugger.IsAttached)
						System.Diagnostics.Debugger.Break();
				}
			}

			Array.Resize(ref itemSavedIndexes, itemCount + 1);
			itemSavedIndexes[itemCount] = itemSavedIndex;
			itemCount++;
		}

		//TODO: add RemoveItem procedure
	}

	/*
	internal class trackItem
	{
		public int trackIndex = -1;
		public int trackItemSavedIndex = -1;
	}
	*/

	internal class Sequence
	{
		private const string TABLEchannel = "channel";
		private const string FIELDname = "name";
		private const string FIELDcolor = "color";
		private const string FIELDcentiseconds = "centiseconds";
		private const string FIELDdeviceType = "deviceType";
		private const string FIELDcircuit = "circuit";
		private const string FIELDnetwork = "network";
		private const string FIELDunit = "unit";
		private const string FIELDsavedIndex = "savedIndex";

		private const string TABLErgbChannel = "rgbChannel";
		private const string TABLEchannelGroup = "channelGroup";
		private const string TABLEchannelGroupList = "channelGroupList";
		private const string FIELDchannelGroup = "channelGroup";
		private const string TABLEcellDemarcation = "cellDemarcation";
		private const string TABLEchannelsClipboard = "channelsClipboard";

		private const string TABLEsequence = "sequence";
		private const string TABLEeffect = "effect";
		private const string FIELDtype = "type";
		private const string FIELDcentisecond = "centisecond";
		private const string FIELDtotalCentiseconds = "totalCentiseconds";
		private const string FIELDstartCentisecond = "startCentisecond";
		private const string FIELDendCentisecond = "endCentisecond";
		private const string FIELDintensity = "intensity";
		private const string FIELDstartIntensity = "startIntensity";
		private const string FIELDendIntensity = "endIntensity";
		private const string TABLEtimingGrid = "timingGrid";
		private const string FIELDsaveID = "saveID";
		private const string TABLEtiming = "timing";
		private const string FIELDspacing = "spacing";
		private const string TABLEtrack = "track";
		private const string STARTtracks = "<tracks>";
		private const string STARTgrids = "<timingGrids>";



		private const string SPC = " ";
		private const string LEVEL0 = "";
		private const string LEVEL1 = "  ";
		private const string LEVEL2 = "    ";
		private const string LEVEL3 = "      ";
		private const string LEVEL4 = "        ";
		// Or, if you prefer tabs instead of spaces...
		//private const string LEVEL1 = "\t";
		//private const string LEVEL2 = "\t\t";
		//private const string LEVEL3 = "\t\t\t";
		//private const string LEVEL4 = "\t\t\t\t";
		private const string PLURAL = "s";
		private const string FIELDEQ = "=\"";
		private const string ENDQT = "\"";
		private const string STFLD = "<";
		private const string ENDFLD = "/>";
		private const string FINFLD = ">";
		private const string STTBL = "<";
		private const string FINTBL = "</";
		private const string ENDTBL = ">";

		private const string DEVICElor = "LOR";
		private const string DEVICEdmx = "DMX Universe";
		private const string DEVICEdigital = "Digital IO";

		private const string EFFECTintensity = "intensity";
		private const string EFFECTshimmer = "shimmer";
		private const string EFFECTtwinkle = "twinkle";
		private const string EFFECTdmx = "DMX intensity";
		private const string GRIDfreeform = "freeform";
		private const string GRIDfixed = "fixed";

		private StreamWriter writer;
		private string lineOut = ""; // line to be written out, gets modified if necessary
		private int curSavedIndex = 0;
		private string dbgMsg = "";

		public channel[] channels;
		public savedIndex[] savedIndexes;
		public rgbChannel[] rgbChannels;
		public channelGroup[] channelGroups;
		//public channelGroupItem[] channelGroupItems;
		//public effect[] effects;
		public timingGrid[] timingGrids;
		//public timingGridItem[] timingGridItems;
		public track[] tracks;
		//public trackItem[] trackItems;

		public int lineCount = 0;
		public int channelCount = 0;
		public int rgbChannelCount = 0;
		public int channelGroupsCount = 0;
		public int groupItemCount = 0;
		public int effectCount = 0;
		public int timingGridCount = 0;
		public int gridItemCount = 0;
		public int trackCount = 0;
		public int trackItemCount = 0;
		public int highestSavedIndex = -1;
		public long totalCentiseconds = 0;

		public string FileName = "";
		public string xmlInfo;
		public string sequenceInfo;
		public string animationInfo;

		private struct updatedTrack
		{
			public int[] newSavedIndexes;
		}

		// CONSTRUCTOR
		//public void Sequence()
		//{
		//}

		public int AddChannel(channel newChan)
		{
			if (newChan.savedIndex < 0)
			{
				highestSavedIndex++;
				newChan.savedIndex = highestSavedIndex;
				Array.Resize(ref savedIndexes, highestSavedIndex + 3);
				savedIndexes[highestSavedIndex] = new savedIndex();
				savedIndexes[highestSavedIndex].objType = tableType.channel;
				savedIndexes[highestSavedIndex].objIndex = channelCount;
			}
			Array.Resize(ref channels, channelCount + 3);
			channels[channelCount] = newChan;
			channelCount++;
			return highestSavedIndex;
		} // end AddChannel

		public int AddRGBChannel(rgbChannel newChan)
		{
			if (newChan.savedIndex < 1)
			{
				highestSavedIndex++;
				newChan.savedIndex = highestSavedIndex;
				Array.Resize(ref savedIndexes, highestSavedIndex + 3);
				savedIndexes[highestSavedIndex] = new savedIndex();
				savedIndexes[highestSavedIndex].objType = tableType.rgbChannel;
				savedIndexes[highestSavedIndex].objIndex = rgbChannelCount;
			}
			Array.Resize(ref rgbChannels, rgbChannelCount + 3);
			rgbChannels[rgbChannelCount] = newChan;
			rgbChannelCount++;
			return highestSavedIndex;
		} // end AddChannel

		public int AddChannelGroup(channelGroup newGroup)
		{
			if (newGroup.savedIndex < 1)
			{
				highestSavedIndex++;
				newGroup.savedIndex = highestSavedIndex;
				Array.Resize(ref savedIndexes, highestSavedIndex + 3);
				savedIndexes[highestSavedIndex] = new savedIndex();
				savedIndexes[highestSavedIndex].objType = tableType.channelGroup;
				savedIndexes[highestSavedIndex].objIndex = channelGroupsCount;
			}
			else
			{
				string foo = "Oops!";
			}

			Array.Resize(ref channelGroups, channelGroupsCount + 3);
			channelGroups[channelGroupsCount] = newGroup;
			channelGroupsCount++;
			return highestSavedIndex;
		}

		//TODO: add RemoveChannel, RemoveRGBchannel, RemoveChannelGroup, and RemoveTrack procedures

		public int AddTimingGrid(timingGrid newGrid)
		{
			Array.Resize(ref timingGrids, timingGridCount + 3);
			timingGrids[timingGridCount] = newGrid;
			timingGridCount++;
			return timingGridCount - 1;
		}

		public int AddTrack(track newTrack)
		{
			Array.Resize(ref tracks, trackCount + 3);
			tracks[trackCount] = newTrack;
			trackCount++;
			return trackCount - 1;
		}

		protected string getItemName(int savedIndex)
		{
			string nameOut = "";
			if (this.savedIndexes[savedIndex].objType == tableType.channel)
			{
				nameOut = channels[savedIndexes[savedIndex].objIndex].name;
			}
			if (savedIndexes[savedIndex].objType == tableType.rgbChannel)
			{
				nameOut = rgbChannels[savedIndexes[savedIndex].objIndex].name;
			}
			if (savedIndexes[savedIndex].objType == tableType.channelGroup)
			{
				nameOut = channelGroups[savedIndexes[savedIndex].objIndex].name;
			}


			return nameOut;
		}

		public int readFile_NOTWORKING(string existingFileName)
		{
			int errState = 0;
			lineCount = 0;
			StreamReader reader = new StreamReader(existingFileName);
			string lineIn; // line read in (does not get modified)
			int pos1 = -1; // positions of certain key text in the line

			// Zero these out from any previous run
			//lineCount = 0;
			channelCount = 0;
			rgbChannelCount = 0;
			channelGroupsCount = 0;
			highestSavedIndex = 0;
			groupItemCount = 0;
			effectCount = 0;
			timingGridCount = 0;
			gridItemCount = 0;
			trackCount = 0;
			trackItemCount = 0;
			highestSavedIndex = 0;
			totalCentiseconds = 0;

			int curChannel = -1;
			int currgbChannel = -1;
			int curSavedIndex = -1;
			int curChannelGroupList = -1;
			int curGroupItem = -1;
			int curEffect = -1;
			int curTimingGrid = -1;
			int curGridItem = -1;
			int curTrack = -1;

			// * PASS 1 - COUNT OBJECTS
			while ((lineIn = reader.ReadLine()) != null)
			{
				lineCount++;
				// does this line mark the start of a channel?
				pos1 = lineIn.IndexOf("xml version=");
				if (pos1 > 0)
				{
					xmlInfo = lineIn;
				}
				pos1 = lineIn.IndexOf("saveFileVersion=");
				if (pos1 > 0)
				{
					sequenceInfo = lineIn;
				}
				pos1 = lineIn.IndexOf("animation rows=");
				if (pos1 > 0)
				{
					animationInfo = lineIn;
				}
				//pos1 = lineIn.IndexOf("<channel name=");
				pos1 = lineIn.IndexOf(STFLD + TABLEchannel + SPC + FIELDname);
				if (pos1 > 0)
				{
					channelCount++;
				}
				//pos1 = lineIn.IndexOf("<rgbChannel totalCentiseconds=");
				pos1 = lineIn.IndexOf(STFLD + TABLErgbChannel + SPC);
				if (pos1 > 0)
				{
					rgbChannelCount++;
				}
				//pos1 = lineIn.IndexOf("<channelGroup totalCentiseconds=");
				pos1 = lineIn.IndexOf(STFLD + TABLEchannelGroupList + SPC);
				if (pos1 > 0)
				{
					channelGroupsCount++;
				}
				//pos1 = lineIn.IndexOf("<effect type=");
				pos1 = lineIn.IndexOf(STFLD + TABLEeffect + SPC);
				if (pos1 > 0)
				{
					effectCount++;
				}
				if (trackCount == 0)
				{
					pos1 = lineIn.IndexOf(TABLEchannelGroup + SPC + FIELDsavedIndex);
					if (pos1 > 0)
					{
						groupItemCount++;
					}
				}
				//pos1 = lineIn.IndexOf("<timingGrid ");
				pos1 = lineIn.IndexOf(STFLD + TABLEtimingGrid + SPC);
				if (pos1 > 0)
				{
					timingGridCount++;
				}
				//pos1 = lineIn.IndexOf("<timing centisecond=");
				pos1 = lineIn.IndexOf(STFLD + TABLEtiming + SPC);
				if (pos1 > 0)
				{
					gridItemCount++;
				}
				//pos1 = lineIn.IndexOf("<track totalCentiseconds=");
				pos1 = lineIn.IndexOf(STFLD + TABLEtrack + SPC);
				if (pos1 > 0)
				{
					trackCount++;
				}
				if (trackCount > 0)
				{
					pos1 = lineIn.IndexOf(STFLD + TABLEchannel + SPC);
					if (pos1 > 0)
					{
						trackItemCount++;
					}
				}

				//pos1 = lineIn.IndexOf(" savedIndex=");
				pos1 = lineIn.IndexOf(FIELDsavedIndex);
				if (pos1 > 0)
				{
					curSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
					if (curSavedIndex > highestSavedIndex)
					{
						highestSavedIndex = curSavedIndex;
					}
				}
			}

			reader.Close();
			// CREATE ARRAYS TO HOLD OBJECTS
			//rgbChannel[] rgbChannels;
			//int[] channelGroup;
			//savedIndex[] savedIndexes;
			channels = new channel[channelCount + 2];
			savedIndexes = new savedIndex[highestSavedIndex + 3];
			rgbChannels = new rgbChannel[rgbChannelCount + 2];
			channelGroups = new channelGroup[channelGroupsCount + 2];
			//channelGroupItems = new channelGroupItem[groupItemCount + 2];
			//effects = new effect[effectCount + 2];
			timingGrids = new timingGrid[timingGridCount + 2];
			//timingGridItems = new timingGridItem[gridItemCount + 2];
			tracks = new track[trackCount + 2];
			//trackItems = new trackItem[trackItemCount + 2];

			// * PASS 2 - COLLECT OBJECTS
			reader = new StreamReader(existingFileName);
			lineCount = 0;
			while ((lineIn = reader.ReadLine()) != null)
			{
				lineCount++;
				// does this line mark the start of a regular channel?
				pos1 = lineIn.IndexOf(TABLEchannel + SPC + FIELDname);
				if (pos1 > 0)
				{
					curChannel++;
					channel chan = new channel();
					savedIndex si = new savedIndex();
					chan.name = getKeyWord(lineIn, FIELDname);
					chan.color = getKeyValue(lineIn, FIELDcolor);
					chan.centiseconds = getKeyValue(lineIn, FIELDcentiseconds);
					chan.deviceType = enumDevice(getKeyWord(lineIn, FIELDdeviceType));
					chan.unit = getKeyValue(lineIn, FIELDunit);
					chan.network = getKeyValue(lineIn, FIELDnetwork);
					chan.circuit = getKeyValue(lineIn, FIELDcircuit);
					chan.savedIndex = getKeyValue(lineIn, FIELDsavedIndex);
					channels[curChannel] = chan;
					curSavedIndex = chan.savedIndex;

					si.objType = tableType.channel;
					si.objIndex = curChannel;
					savedIndexes[curSavedIndex] = si;
				}

				// does this line mark the start of a RGB channel?
				pos1 = lineIn.IndexOf(TABLErgbChannel + SPC + FIELDtotalCentiseconds);
				if (pos1 > 0)
				{
					currgbChannel++;
					rgbChannel rgbc = new rgbChannel();
					savedIndex si = new savedIndex();
					rgbc.name = getKeyWord(lineIn, FIELDname);
					rgbc.totalCentiseconds = getKeyValue(lineIn, FIELDtotalCentiseconds);
					rgbc.savedIndex = getKeyValue(lineIn, FIELDsavedIndex);
					curSavedIndex = rgbc.savedIndex;
					lineIn = reader.ReadLine();
					lineIn = reader.ReadLine();
					rgbc.redSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
					rgbc.redChannelIndex = savedIndexes[rgbc.redSavedIndex].objIndex;
					lineIn = reader.ReadLine();
					rgbc.grnSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
					rgbc.grnChannelIndex = savedIndexes[rgbc.grnSavedIndex].objIndex;
					lineIn = reader.ReadLine();
					rgbc.bluSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
					rgbc.bluChannelIndex = savedIndexes[rgbc.bluSavedIndex].objIndex;
					rgbChannels[currgbChannel] = rgbc;

					si.objType = tableType.rgbChannel;
					si.objIndex = currgbChannel;
					savedIndexes[curSavedIndex] = si;
				}

				// does this line mark the start of a Channel Group List?
				if (curTrack < 0)
				{
					pos1 = lineIn.IndexOf(TABLEchannelGroupList + SPC + FIELDtotalCentiseconds);
					if (pos1 > 0)
					{
						curChannelGroupList++;
						channelGroup changl = new channelGroup();
						savedIndex si = new savedIndex();
						changl.name = getKeyWord(lineIn, FIELDname);
						changl.channelIndex = curChannel;
						changl.channelSavedIndex = curSavedIndex;
						changl.totalCentiSeconds = getKeyValue(lineIn, FIELDtotalCentiseconds);
						changl.savedIndex = getKeyValue(lineIn, FIELDsavedIndex);
						curSavedIndex = changl.savedIndex;
						channelGroups[curChannelGroupList] = changl;

						si.objType = tableType.channelGroup;
						si.objIndex = curChannelGroupList;
						savedIndexes[curSavedIndex] = si;
						lineIn = reader.ReadLine();
						lineIn = reader.ReadLine();
						pos1 = lineIn.IndexOf(TABLEchannelGroup + SPC + FIELDsavedIndex);
						while (pos1 > 0)
						{
							//curGroupItem++;
							//channelGroupItem gi = new channelGroupItem();
							//gi.channelGroupListIndex = curChannelGroupList;
							//gi.GroupItemSavedIndex = curSavedIndex;
							//gi.GroupItemSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
							int isl  = getKeyValue(lineIn, FIELDsavedIndex);
							//channelGroupItems[curGroupItem] = gi;
							changl.AddItem(isl);

							lineIn = reader.ReadLine();
							pos1 = lineIn.IndexOf(TABLEchannelGroup + SPC + FIELDsavedIndex);
						}
					}
				}

				// does this line mark the start of an Effect?
				pos1 = lineIn.IndexOf(TABLEeffect + SPC + FIELDtype);
				if (pos1 > 0)
				{
					curEffect++;

					//DEBUG!
					if (curEffect > 638)
					{
						errState = 1;
					}

					effect ef = new effect();
					//ef.channelIndex = curChannel;
					//ef.savedIndex = curSavedIndex;
					ef.type = enumEffect(getKeyWord(lineIn, FIELDtype));
					ef.startCentisecond = getKeyValue(lineIn, FIELDstartCentisecond);
					ef.endCentisecond = getKeyValue(lineIn, FIELDendCentisecond);
					ef.intensity = getKeyValue(lineIn, SPC + FIELDintensity);
					ef.startIntensity = getKeyValue(lineIn, FIELDstartIntensity);
					ef.endIntensity = getKeyValue(lineIn, FIELDendIntensity);
					//if (channels[curChannel].firstEffectIndex < 0)
					//{
					//	channels[curChannel].firstEffectIndex = curEffect;
					//}
					//channels[curChannel].finalEffectIndex = curEffect;
					//effects[curEffect] = ef;
					channels[curChannel].AddEffect(ef);
				}

				// does this line mark the start of a Timing Grid?
				pos1 = lineIn.IndexOf(STFLD + TABLEtimingGrid + SPC);
				if (pos1 > 0)
				{
					curTimingGrid++;
					timingGrid tg = new timingGrid();
					tg.name = getKeyWord(lineIn, FIELDname);
					tg.type = enumGridType(getKeyWord(lineIn, FIELDtype));
					tg.saveID = getKeyValue(lineIn, FIELDsaveID);
					tg.spacing = getKeyValue(lineIn, FIELDspacing);
					timingGrids[curTimingGrid] = tg;

					if (tg.type == timingGridType.freeform)
					{
						lineIn = reader.ReadLine();
						pos1 = lineIn.IndexOf(TABLEtiming + SPC + FIELDcentisecond);
						while (pos1 > 0)
						{
							curGridItem++;
							//timingGridItem grit = new timingGridItem();
							//grit.gridIndex = curTimingGrid;
							int gpos = getKeyValue(lineIn, FIELDcentisecond);
							timingGrids[curTimingGrid].AddTiming(gpos);

							lineIn = reader.ReadLine();
							pos1 = lineIn.IndexOf(TABLEtiming + SPC + FIELDcentisecond);
						}
					}
				}

				// does this line mark the start of a Track?
				pos1 = lineIn.IndexOf(TABLEtrack + SPC);
				if (pos1 > 0)
				{
					curTrack++;
					track trk = new track();
					trk.name = getKeyWord(lineIn, FIELDname);
					trk.totalCentiseconds = getKeyValue(lineIn, FIELDtotalCentiseconds);
					totalCentiseconds = trk.totalCentiseconds;
					trk.timingGridSaveID = getKeyValue(lineIn, TABLEtimingGrid);
					tracks[curTrack] = trk;

					lineIn = reader.ReadLine();
					lineIn = reader.ReadLine();
					pos1 = lineIn.IndexOf(TABLEchannel + SPC + FIELDsavedIndex);
					while (pos1 > 0)
					{
						//curTrackItem++;
						//trackItem tit = new trackItem();
						//tit.trackIndex = curTrack;
						int isi = getKeyValue(lineIn, FIELDsavedIndex);
						//tit.savedIndex = getKeyValue(lineIn, FIELDsavedIndex);
						trk.AddItem(isi);
						//trackItems[curTrackItem] = tit;

						lineIn = reader.ReadLine();
						pos1 = lineIn.IndexOf(TABLEchannel + SPC + FIELDsavedIndex);
					}
				}

				// does this line mark the start of a Track Item?
			}

			/*
			channel chan2 = new channel();
			channels[curChannel + 1] = chan2;
			rgbChannel rgbc2 = new rgbChannel();
			rgbChannels[currgbChannel + 1] = rgbc2;
			savedIndex si2 = new savedIndex();
			savedIndexes[curSavedIndex + 1] = si2;
			channelGroup changl2 = new channelGroup();
			channelGroups[curChannelGroupList + 1] = changl2;
			//channelGroupItem gi2 = new channelGroupItem();
			//channelGroupItems[curGroupItem + 1] = gi2;
			effect ef2 = new effect();
			ef2.type = enumEffect(getKeyWord(lineIn, FIELDtype));
			ef2.startCentisecond = getKeyValue(lineIn, FIELDstartCentisecond);
			ef2.endCentisecond = getKeyValue(lineIn, FIELDendCentisecond);
			ef2.intensity = getKeyValue(lineIn, SPC + FIELDintensity);
			ef2.startIntensity = getKeyValue(lineIn, FIELDstartIntensity);
			ef2.endIntensity = getKeyValue(lineIn, FIELDendIntensity);
			channels[curChannel+1].AddEffect(ef2);

			timingGrid tg2 = new timingGrid();
			AddTimingGrid(tg2);
			tg2.AddTiming(0);
			track trk2 = new track();
			tracks[curTrack + 1] = trk2;
			//trackItem tit2 = new trackItem();
			//trackItems[curTrackItem + 1] = tit2;
			*/

			reader.Close();
			totalCentiseconds = tracks[0].totalCentiseconds;

			if (errState <= 0)
			{
				FileName = existingFileName;
			}

			return errState;
		}

		public int readFile(string existingFileName)
		{
			int errState = 0;
			StreamReader reader = new StreamReader(existingFileName);
			string lineIn; // line read in (does not get modified)
			int pos1 = -1; // positions of certain key text in the line

			// Zero these out from any previous run
			lineCount = 0;
			channelCount = 0;
			rgbChannelCount = 0;
			channelGroupsCount = 0;
			highestSavedIndex = 0;
			groupItemCount = 0;
			effectCount = 0;
			timingGridCount = 0;
			gridItemCount = 0;
			trackCount = 0;
			trackItemCount = 0;
			highestSavedIndex = 0;
			totalCentiseconds = 0;

			int curChannel = -1;
			int currgbChannel = -1;
			int curSavedIndex = -1;
			int curChannelGroupList = -1;
			int curGroupItem = -1;
			int curEffect = -1;
			int curTimingGrid = -1;
			int curGridItem = -1;
			int curTrack = -1;
			bool trackMode = false;

			// * PASS 1 - COUNT OBJECTS
			while ((lineIn = reader.ReadLine()) != null)
			{
				lineCount++;
				// does this line mark the start of a channel?
				pos1 = lineIn.IndexOf("xml version=");
				if (pos1 > 0)
				{
					xmlInfo = lineIn;
				}
				pos1 = lineIn.IndexOf("saveFileVersion=");
				if (pos1 > 0)
				{
					sequenceInfo = lineIn;
				}
				pos1 = lineIn.IndexOf("animation rows=");
				if (pos1 > 0)
				{
					animationInfo = lineIn;
				}
				//pos1 = lineIn.IndexOf("<channel name=");
				pos1 = lineIn.IndexOf(STFLD + TABLEchannel + SPC + FIELDname);
				if (pos1 > 0)
				{
					channelCount++;
				}
				//pos1 = lineIn.IndexOf("<rgbChannel totalCentiseconds=");
				pos1 = lineIn.IndexOf(STFLD + TABLErgbChannel + SPC);
				if (pos1 > 0)
				{
					rgbChannelCount++;
				}
				//pos1 = lineIn.IndexOf("<channelGroup totalCentiseconds=");
				pos1 = lineIn.IndexOf(STFLD + TABLEchannelGroupList + SPC);
				if (pos1 > 0)
				{
					channelGroupsCount++;
				}
				//pos1 = lineIn.IndexOf("<effect type=");
				pos1 = lineIn.IndexOf(STFLD + TABLEeffect + SPC);
				if (pos1 > 0)
				{
					effectCount++;
				}
				if (trackCount == 0)
				{
					pos1 = lineIn.IndexOf(TABLEchannelGroup + SPC + FIELDsavedIndex);
					if (pos1 > 0)
					{
						groupItemCount++;
					}
				}
				//pos1 = lineIn.IndexOf("<timingGrid ");
				pos1 = lineIn.IndexOf(STFLD + TABLEtimingGrid + SPC);
				if (pos1 > 0)
				{
					timingGridCount++;
				}
				//pos1 = lineIn.IndexOf("<timing centisecond=");
				pos1 = lineIn.IndexOf(STFLD + TABLEtiming + SPC);
				if (pos1 > 0)
				{
					gridItemCount++;
				}
				//pos1 = lineIn.IndexOf("<track totalCentiseconds=");
				pos1 = lineIn.IndexOf(STFLD + TABLEtrack + SPC);
				if (pos1 > 0)
				{
					trackCount++;
				}
				if (trackCount > 0)
				{
					pos1 = lineIn.IndexOf(STFLD + TABLEchannel + SPC);
					if (pos1 > 0)
					{
						trackItemCount++;
					}
				}

				//pos1 = lineIn.IndexOf(" savedIndex=");
				pos1 = lineIn.IndexOf(FIELDsavedIndex);
				if (pos1 > 0)
				{
					curSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
					if (curSavedIndex > highestSavedIndex)
					{
						highestSavedIndex = curSavedIndex;
					}
				}
			}

			reader.Close();
			// CREATE ARRAYS TO HOLD OBJECTS
			channels = new channel[channelCount + 2];
			savedIndexes = new savedIndex[highestSavedIndex + 3];
			rgbChannels = new rgbChannel[rgbChannelCount + 2];
			channelGroups = new channelGroup[channelGroupsCount + 2];
			timingGrids = new timingGrid[timingGridCount + 2];
			tracks = new track[trackCount + 2];

			//////////////////////////////////
			// * PASS 2 - COLLECT OBJECTS * //
			//////////////////////////////////
			reader = new StreamReader(existingFileName);
			lineCount = 0;
			while ((lineIn = reader.ReadLine()) != null)
			{
				lineCount++;
				// have we reached the tracks section?
				pos1 = lineIn.IndexOf(STARTtracks);
				if (pos1 > 0)
				{
					trackMode = true;
				}
				if (!trackMode)
				{
					// does this line mark the start of a regular channel?
					pos1 = lineIn.IndexOf(TABLEchannel + SPC + FIELDname);
					if (pos1 > 0)
					{
						curChannel++;
						channel chan = new channel();
						savedIndex si = new savedIndex();
						chan.name = getKeyWord(lineIn, FIELDname);
						chan.color = getKeyValue(lineIn, FIELDcolor);
						chan.centiseconds = getKeyValue(lineIn, FIELDcentiseconds);
						chan.deviceType = enumDevice(getKeyWord(lineIn, FIELDdeviceType));
						chan.unit = getKeyValue(lineIn, FIELDunit);
						chan.network = getKeyValue(lineIn, FIELDnetwork);
						chan.circuit = getKeyValue(lineIn, FIELDcircuit);
						chan.savedIndex = getKeyValue(lineIn, FIELDsavedIndex);
						channels[curChannel] = chan;
						curSavedIndex = chan.savedIndex;

						si.objType = tableType.channel;
						si.objIndex = curChannel;
						savedIndexes[curSavedIndex] = si;
					}

					// does this line mark the start of a RGB channel?
					pos1 = lineIn.IndexOf(TABLErgbChannel + SPC + FIELDtotalCentiseconds);
					if (pos1 > 0)
					{
						currgbChannel++;
						rgbChannel rgbc = new rgbChannel();
						savedIndex si = new savedIndex();
						rgbc.name = getKeyWord(lineIn, FIELDname);
						rgbc.totalCentiseconds = getKeyValue(lineIn, FIELDtotalCentiseconds);
						rgbc.savedIndex = getKeyValue(lineIn, FIELDsavedIndex);
						curSavedIndex = rgbc.savedIndex;
						lineIn = reader.ReadLine();
						lineIn = reader.ReadLine();
						rgbc.redSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
						rgbc.redChannelIndex = savedIndexes[rgbc.redSavedIndex].objIndex;
						lineIn = reader.ReadLine();
						rgbc.grnSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
						rgbc.grnChannelIndex = savedIndexes[rgbc.grnSavedIndex].objIndex;
						lineIn = reader.ReadLine();
						rgbc.bluSavedIndex = getKeyValue(lineIn, FIELDsavedIndex);
						rgbc.bluChannelIndex = savedIndexes[rgbc.bluSavedIndex].objIndex;
						rgbChannels[currgbChannel] = rgbc;

						si.objType = tableType.rgbChannel;
						si.objIndex = currgbChannel;
						savedIndexes[curSavedIndex] = si;
					}

					// does this line mark the start of a Channel Group List?
					if (curTrack < 0)
					{
						pos1 = lineIn.IndexOf(TABLEchannelGroupList + SPC + FIELDtotalCentiseconds);
						if (pos1 > 0)
						{
							curChannelGroupList++;
							channelGroup changl = new channelGroup();
							savedIndex si = new savedIndex();
							changl.name = getKeyWord(lineIn, FIELDname);
							changl.channelIndex = curChannel;
							changl.channelSavedIndex = curSavedIndex;
							changl.totalCentiSeconds = getKeyValue(lineIn, FIELDtotalCentiseconds);
							changl.savedIndex = getKeyValue(lineIn, FIELDsavedIndex);
							curSavedIndex = changl.savedIndex;
							channelGroups[curChannelGroupList] = changl;

							si.objType = tableType.channelGroup;
							si.objIndex = curChannelGroupList;
							savedIndexes[curSavedIndex] = si;
							lineIn = reader.ReadLine();
							lineIn = reader.ReadLine();
							pos1 = lineIn.IndexOf(TABLEchannelGroup + SPC + FIELDsavedIndex);
							while (pos1 > 0)
							{
								int isl = getKeyValue(lineIn, FIELDsavedIndex);
								changl.AddItem(isl);
								lineIn = reader.ReadLine();
								pos1 = lineIn.IndexOf(TABLEchannelGroup + SPC + FIELDsavedIndex);
							}
						}
					}

					// does this line mark the start of an Effect?
					pos1 = lineIn.IndexOf(TABLEeffect + SPC + FIELDtype);
					if (pos1 > 0)
					{
						curEffect++;

						//DEBUG!
						if (curEffect > 638)
						{
							errState = 1;
						}

						effect ef = new effect();
						ef.type = enumEffect(getKeyWord(lineIn, FIELDtype));
						ef.startCentisecond = getKeyValue(lineIn, FIELDstartCentisecond);
						ef.endCentisecond = getKeyValue(lineIn, FIELDendCentisecond);
						ef.intensity = getKeyValue(lineIn, SPC + FIELDintensity);
						ef.startIntensity = getKeyValue(lineIn, FIELDstartIntensity);
						ef.endIntensity = getKeyValue(lineIn, FIELDendIntensity);
						channels[curChannel].AddEffect(ef);
					}

					// does this line mark the start of a Timing Grid?
					pos1 = lineIn.IndexOf(STFLD + TABLEtimingGrid + SPC);
					if (pos1 > 0)
					{
						curTimingGrid++;
						timingGrid tg = new timingGrid();
						tg.name = getKeyWord(lineIn, FIELDname);
						tg.type = enumGridType(getKeyWord(lineIn, FIELDtype));
						tg.saveID = getKeyValue(lineIn, FIELDsaveID);
						tg.spacing = getKeyValue(lineIn, FIELDspacing);
						timingGrids[curTimingGrid] = tg;

						if (tg.type == timingGridType.freeform)
						{
							lineIn = reader.ReadLine();
							pos1 = lineIn.IndexOf(TABLEtiming + SPC + FIELDcentisecond);
							while (pos1 > 0)
							{
								curGridItem++;
								int gpos = getKeyValue(lineIn, FIELDcentisecond);
								timingGrids[curTimingGrid].AddTiming(gpos);

								lineIn = reader.ReadLine();
								pos1 = lineIn.IndexOf(TABLEtiming + SPC + FIELDcentisecond);
							}
						}
					}
				}
				else // in Track Mode
				{
					// does this line mark the start of a Track?
					pos1 = lineIn.IndexOf(TABLEtrack + SPC);
					if (pos1 > 0)
					{
						curTrack++;
						track trk = new track();
						trk.name = getKeyWord(lineIn, FIELDname);
						trk.totalCentiseconds = getKeyValue(lineIn, FIELDtotalCentiseconds);
						totalCentiseconds = trk.totalCentiseconds;
						trk.timingGridSaveID = getKeyValue(lineIn, TABLEtimingGrid);
						tracks[curTrack] = trk;

						lineIn = reader.ReadLine();
						lineIn = reader.ReadLine();
						pos1 = lineIn.IndexOf(TABLEchannel + SPC + FIELDsavedIndex);
						while (pos1 > 0)
						{
							int isi = getKeyValue(lineIn, FIELDsavedIndex);
							trk.AddItem(isi);
							lineIn = reader.ReadLine();
							pos1 = lineIn.IndexOf(TABLEchannel + SPC + FIELDsavedIndex);
						}
					} // end if start of track
				} // end Track Mode (or not)
			} // end while line is valid

			reader.Close();
			totalCentiseconds = tracks[0].totalCentiseconds;

			if (errState <= 0)
			{
				FileName = existingFileName;
			}

			return errState;
		}


		public int WriteFile(string newFilename)
		{
			int errState = 0;
			lineCount = 0;

			//backupFile(fileName);

			string tmpFile = newFilename + ".tmp";

			writer = new StreamWriter(tmpFile);
			string lineOut = ""; // line to be written out, gets modified if necessary
													 //int pos1 = -1; // positions of certain key text in the line

			int curChannel = 0;
			int currgbChannel = 0;
			int curSavedIndex = 1;
			int curChannelGroupList = 0;
			int curGroupItem = 0;
			int curTimingGrid = 0;
			int curGridItem = 0;
			int curTrack = 0;
			int curTrackItem = 0;
			bool closeChannel = false;

			lineOut = xmlInfo;
			writer.WriteLine(lineOut); lineCount++;
			lineOut = sequenceInfo;
			writer.WriteLine(lineOut); lineCount++;
			lineOut = "  <" + TABLEchannel + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			while (curChannel < channelCount)
			{
				channel chnl = channels[curChannel];
				closeChannel = false;
				lineOut = LEVEL2 + STFLD + TABLEchannel;
				lineOut += SPC + FIELDname + FIELDEQ + chnl.name + ENDQT;
				lineOut += SPC + FIELDcolor + FIELDEQ + chnl.color.ToString() + ENDQT;
				lineOut += SPC + FIELDcentiseconds + FIELDEQ + chnl.centiseconds.ToString() + ENDQT;
				if (chnl.deviceType == deviceType.LOR)
				{
					lineOut += SPC + FIELDdeviceType + FIELDEQ + deviceName(chnl.deviceType) + ENDQT;
					lineOut += SPC + FIELDunit + FIELDEQ + chnl.unit.ToString() + ENDQT;
					lineOut += SPC + FIELDcircuit + FIELDEQ + chnl.circuit.ToString() + ENDQT;
				}
				else if (chnl.deviceType == deviceType.DMX)
				{
					lineOut += SPC + FIELDdeviceType + FIELDEQ + deviceName(chnl.deviceType) + ENDQT;
					lineOut += SPC + FIELDcircuit + FIELDEQ + chnl.circuit.ToString() + ENDQT;
					lineOut += SPC + FIELDnetwork + FIELDEQ + chnl.network.ToString() + ENDQT;
				}
				lineOut += SPC + FIELDsavedIndex + FIELDEQ + chnl.savedIndex.ToString() + ENDQT;
				curSavedIndex = chnl.savedIndex;
				// Are there any effects for this channel?
				//if (effects[curEffect].channelIndex == curChannel)
				if (chnl.effectCount > 0)
				{
					// complete channel line with regular '>' then do effects
					lineOut += FINFLD;
					writer.WriteLine(lineOut); lineCount++;

					writeEffects(channels[curChannel]);
						//while (effects[curEffect].channelIndex == curChannel)
				}
				else // NO effects for this channal
				{
					// complete channel line with field end '/>'
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				if (closeChannel)
				{
					lineOut = LEVEL2 + FINTBL + TABLEchannel + FINFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				// Was this an RGB Channel?
				if (currgbChannel < rgbChannelCount)
				{
					if (rgbChannels[currgbChannel].bluSavedIndex == curSavedIndex)
					{
						lineOut = LEVEL2 + STFLD + TABLErgbChannel;
						lineOut += SPC + FIELDtotalCentiseconds + FIELDEQ + rgbChannels[currgbChannel].totalCentiseconds.ToString() + ENDQT;
						lineOut += SPC + FIELDname + FIELDEQ + rgbChannels[currgbChannel].name + ENDQT;
						lineOut += SPC + FIELDsavedIndex + FIELDEQ + rgbChannels[currgbChannel].savedIndex.ToString() + ENDQT;
						lineOut += FINFLD;
						writer.WriteLine(lineOut); lineCount++;
						lineOut = LEVEL3 + STFLD + TABLEchannel + PLURAL + FINFLD;
						writer.WriteLine(lineOut); lineCount++;
						lineOut = LEVEL4 + STFLD + TABLEchannel;
						lineOut += SPC + FIELDsavedIndex + FIELDEQ + rgbChannels[currgbChannel].redSavedIndex.ToString() + ENDQT;
						lineOut += ENDFLD;
						writer.WriteLine(lineOut); lineCount++;
						lineOut = LEVEL4 + STFLD + TABLEchannel;
						lineOut += SPC + FIELDsavedIndex + FIELDEQ + rgbChannels[currgbChannel].grnSavedIndex.ToString() + ENDQT;
						lineOut += ENDFLD;
						writer.WriteLine(lineOut); lineCount++;
						lineOut = LEVEL4 + STFLD + TABLEchannel;
						lineOut += SPC + FIELDsavedIndex + FIELDEQ + rgbChannels[currgbChannel].bluSavedIndex.ToString() + ENDQT;
						lineOut += ENDFLD;
						writer.WriteLine(lineOut); lineCount++;
						lineOut = LEVEL3 + FINTBL + TABLEchannel + PLURAL + FINFLD;
						writer.WriteLine(lineOut); lineCount++;
						lineOut = LEVEL2 + FINTBL + TABLErgbChannel + FINFLD;
						writer.WriteLine(lineOut); lineCount++;

						curSavedIndex = rgbChannels[currgbChannel].savedIndex;
						currgbChannel++;
					}
				}

				// is a group coming up next?
				while (channelGroups[curChannelGroupList].savedIndex == curSavedIndex + 1)
				{
					lineOut = LEVEL2 + STFLD + TABLEchannelGroupList;
					lineOut += SPC + FIELDtotalCentiseconds + FIELDEQ + channelGroups[curChannelGroupList].totalCentiSeconds.ToString() + ENDQT;
					lineOut += SPC + FIELDname + FIELDEQ + channelGroups[curChannelGroupList].name + ENDQT;
					lineOut += SPC + FIELDsavedIndex + FIELDEQ + channelGroups[curChannelGroupList].savedIndex.ToString() + ENDQT;
					lineOut += FINFLD;
					writer.WriteLine(lineOut); lineCount++;
					lineOut = LEVEL3 + STFLD + TABLEchannelGroup + PLURAL + FINFLD;
					writer.WriteLine(lineOut); lineCount++;
					/*
					while (channelGroupItems[curGroupItem].channelGroupListIndex == curChannelGroupList)
					{
						lineOut = LEVEL4 + STFLD + TABLEchannelGroup;
						lineOut += SPC + FIELDsavedIndex + FIELDEQ + channelGroupItems[curGroupItem].GroupItemSavedIndex.ToString() + ENDQT;
						lineOut += ENDFLD;
						writer.WriteLine(lineOut); lineCount++;

						curGroupItem++;
					}
					*/
					for (int igi=0; igi< channelGroups[curChannelGroupList].itemCount; igi++)
					{
						lineOut = LEVEL4 + STFLD + TABLEchannelGroup;
						lineOut += SPC + FIELDsavedIndex + FIELDEQ + channelGroups[curChannelGroupList].itemSavedIndexes[igi].ToString() + ENDQT;
						lineOut += ENDFLD;
						writer.WriteLine(lineOut); lineCount++;

						curGroupItem++;
					}
					lineOut = LEVEL3 + FINTBL + TABLEchannelGroup + PLURAL + FINFLD;
					writer.WriteLine(lineOut); lineCount++;
					lineOut = LEVEL2 + FINTBL + TABLEchannelGroupList + FINFLD;
					writer.WriteLine(lineOut); lineCount++;
					curSavedIndex = channelGroups[curChannelGroupList].savedIndex;
					curChannelGroupList++;
				}

				curChannel++;
			} // curChannel < channelCount

			lineOut = LEVEL1 + FINTBL + TABLEchannel + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			// TIMING GRIDS
			lineOut = "  <" + TABLEtimingGrid + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;
			while (curTimingGrid < timingGridCount)
			{
				lineOut = LEVEL2 + STFLD + TABLEtimingGrid;
				lineOut += SPC + FIELDsaveID + FIELDEQ + timingGrids[curTimingGrid].saveID.ToString() + ENDQT;
				if (timingGrids[curTimingGrid].name.Length > 1)
				{
					lineOut += SPC + FIELDname + FIELDEQ + timingGrids[curTimingGrid].name + ENDQT;
				}
				lineOut += SPC + FIELDtype + FIELDEQ + timingName(timingGrids[curTimingGrid].type) + ENDQT;
				if (timingGrids[curTimingGrid].spacing > 1)
				{
					lineOut += SPC + FIELDspacing + FIELDEQ + timingGrids[curTimingGrid].spacing.ToString() + ENDQT;
				}
				if (timingGrids[curTimingGrid].type == timingGridType.fixedGrid)
				{
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				else if (timingGrids[curTimingGrid].type == timingGridType.freeform)
				{
					lineOut += FINFLD;
					writer.WriteLine(lineOut); lineCount++;

					for (int tm=0; tm< timingGrids[curTimingGrid].itemCount; tm++)
					//while (timingGridItems[curGridItem].gridIndex == curTimingGrid)
					{
						lineOut = LEVEL4 + STFLD + TABLEtiming;
						lineOut += SPC + FIELDcentisecond + FIELDEQ + timingGrids[curTimingGrid].timings[tm].ToString() + ENDQT;
						lineOut += ENDFLD;
						writer.WriteLine(lineOut); lineCount++;

						curGridItem++;
					}

					lineOut = LEVEL2 + FINTBL + TABLEtimingGrid + FINFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				curTimingGrid++;
			}
			lineOut = LEVEL1 + FINTBL + TABLEtimingGrid + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			// TRACKS
			lineOut = "  <" + TABLEtrack + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;
			while (curTrack < trackCount)
			{
				lineOut = LEVEL2 + STFLD + TABLEtrack;
				if (tracks[curTrack].name.Length > 1)
				{
					lineOut += SPC + FIELDname + FIELDEQ + tracks[curTrack].name + ENDQT;
				}
				lineOut += SPC + FIELDtotalCentiseconds + FIELDEQ + tracks[curTrack].totalCentiseconds.ToString() + ENDQT;
				lineOut += SPC + TABLEtimingGrid + FIELDEQ + tracks[curTrack].timingGridSaveID.ToString() + ENDQT;
				lineOut += FINFLD;
				writer.WriteLine(lineOut); lineCount++;

				lineOut = LEVEL3 + STFLD + TABLEchannel + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;

				/*
				while (trackItems[curTrackItem].trackIndex == curTrack)
				{
					lineOut = LEVEL4 + STFLD + TABLEchannel;
					lineOut += SPC + FIELDsavedIndex + FIELDEQ + trackItems[curTrackItem].savedIndex.ToString() + ENDQT;
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;

					curTrackItem++;
				}
				*/
				for (int iti = 0; iti < tracks[curTrack].itemCount; iti++)
				{
					lineOut = LEVEL4 + STFLD + TABLEchannel;
					lineOut += SPC + FIELDsavedIndex + FIELDEQ + tracks[curTrack].itemSavedIndexes[iti].ToString() + ENDQT;
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;

					curTrackItem++;
				}

				lineOut = LEVEL3 + FINTBL + TABLEchannel + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
				curTrack++;

				// TODO: Support Loops!
				lineOut = "      <loopLevels/>";
				writer.WriteLine(lineOut); lineCount++;

				lineOut = LEVEL2 + FINTBL + TABLEtrack + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
			}
			lineOut = LEVEL1 + FINTBL + TABLEtrack + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			lineOut = animationInfo;
			writer.WriteLine(lineOut); lineCount++;

			lineOut = "</sequence>";
			writer.WriteLine(lineOut); lineCount++;

			Console.WriteLine(lineCount.ToString() + " Out:" + lineOut);
			Console.WriteLine("");

			writer.Flush();
			writer.Close();


			if (File.Exists(newFilename))
			{
				string bakFile = newFilename.Substring(0, newFilename.Length - 3) + "bak";
				if (File.Exists(bakFile))
				{
					File.Delete(bakFile);
				}
				File.Move(newFilename, bakFile);
			}
			File.Move(tmpFile, newFilename);

			if (errState <= 0)
			{
				FileName = newFilename;
			}

			return errState;
		}

		public int WriteClipboardFile(string newFilename)
		{
			//TODO: This procedure is totally untested!!

			int errState = 0;
			lineCount = 0;

			//backupFile(fileName);

			string tmpFile = newFilename + ".tmp";

			writer = new StreamWriter(tmpFile);
			lineOut = ""; // line to be written out, gets modified if necessary
										//int pos1 = -1; // positions of certain key text in the line

			int curTimingGrid = 0;
			int curGridItem = 0;
			int curTrack = 0;
			int curTrackItem = 0;
			int[] newSIs = new int[1];
			int newSI = -1;
			updatedTrack[] updatedTracks = new updatedTrack[trackCount];

			lineOut = xmlInfo;
			writer.WriteLine(lineOut); lineCount++;
			lineOut = STFLD + TABLEchannelsClipboard + " version=\"1\" name=\"" + fileNameOnly(newFilename) + "\"" + ENDFLD;
			writer.WriteLine(lineOut); lineCount++;

			// Write Timing Grid aka cellDemarcation
			lineOut = LEVEL1 + STFLD + TABLEcellDemarcation + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;
			for (int tm = 0; tm < timingGrids[0].itemCount; tm++)
			{
				lineOut = LEVEL2 + STFLD + TABLEcellDemarcation;
				lineOut += SPC + FIELDcentisecond + FIELDEQ + timingGrids[curTimingGrid].timings[tm].ToString() + ENDQT;
				lineOut += ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
			}
			lineOut = LEVEL1 + FINTBL + TABLEcellDemarcation + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			// Write JUST CHANNELS in display order
			// DO NOT write track, RGB group, or channel group info
			for (int trk = 0; trk < trackCount; trk++)
			{
				for (int ti = 0; ti < tracks[trk].itemCount; ti++)
				{
					int si = tracks[trk].itemSavedIndexes[ti];
					ParseItemsToClipboard(si);
				} // end for track items loop
			} // end for tracks loop

			lineOut = LEVEL1 + FINTBL + TABLEchannel + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			lineOut = FINTBL + TABLEchannelsClipboard + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			Console.WriteLine(lineCount.ToString() + " Out:" + lineOut);
			Console.WriteLine("");

			writer.Flush();
			writer.Close();

			if (File.Exists(newFilename))
			{
				string bakFile = newFilename.Substring(0, newFilename.Length - 3) + "bak";
				if (File.Exists(bakFile))
				{
					File.Delete(bakFile);
				}
				File.Move(newFilename, bakFile);
			}
			File.Move(tmpFile, newFilename);

			if (errState <= 0)
			{
				FileName = newFilename;
			}

			return errState;
		} // end WriteClipboardFile

		void ParseItemsToClipboard(int saveID)
		{
			int oi = savedIndexes[saveID].objIndex;
			tableType itemType = savedIndexes[saveID].objType;
			if (itemType == tableType.channel)
			{
				lineOut = LEVEL2 + STFLD + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
				writeEffects(channels[oi]);
				lineOut = LEVEL2 + FINTBL + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
			} // end if channel

			if (itemType == tableType.rgbChannel)
			{
				rgbChannel rgbch = rgbChannels[oi];
				// Get and write Red Channel
				int ci = rgbChannels[oi].redChannelIndex;
				lineOut = LEVEL2 + STFLD + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
				writeEffects(channels[ci]);
				lineOut = LEVEL2 + FINTBL + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;

				// Get and write Green Channel
				ci = rgbChannels[oi].grnChannelIndex;
				lineOut = LEVEL2 + STFLD + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
				writeEffects(channels[ci]);
				lineOut = LEVEL2 + FINTBL + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;

				// Get and write Blue Channel
				ci = rgbChannels[oi].bluChannelIndex;
				lineOut = LEVEL2 + STFLD + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
				writeEffects(channels[ci]);
				lineOut = LEVEL2 + FINTBL + TABLEchannel + ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
			} // end if rgbChannel

			if (itemType == tableType.channelGroup)
			{
				channelGroup grp = channelGroups[oi];
				for (int itm=0; itm < grp.itemCount; itm++)
				{
					ParseItemsToClipboard(grp.itemSavedIndexes[itm]);
				}
			} // end if channelGroup
		} // end ParseChannelGroupToClipboard

		public int WriteFileInDisplayOrder(string newFilename)
		{
			int errState = 0;
			lineCount = 0;

			//backupFile(fileName);

			string tmpFile = newFilename + ".tmp";

			writer = new StreamWriter(tmpFile);
			lineOut = ""; // line to be written out, gets modified if necessary
										//int pos1 = -1; // positions of certain key text in the line

			int curTimingGrid = 0;
			int curGridItem = 0;
			int curTrack = 0;
			int curTrackItem = 0;
			int[] newSIs = new int[1];
			int newSI = -1;
			updatedTrack[] updatedTracks = new updatedTrack[trackCount];

			lineOut = xmlInfo;
			writer.WriteLine(lineOut); lineCount++;
			lineOut = sequenceInfo;
			writer.WriteLine(lineOut); lineCount++;

			lineOut = LEVEL1 + STFLD + TABLEchannel + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			for (int t = 0; t < trackCount; t++)
			{
				newSIs = writeTrackItems(t);
				updatedTrack ut = new updatedTrack();
				ut.newSavedIndexes = newSIs;
				updatedTracks[t] = ut;
			}

			lineOut = LEVEL1 + FINTBL + TABLEchannel + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			// TIMING GRIDS
			lineOut = LEVEL1 + STFLD + TABLEtimingGrid + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;
			while (curTimingGrid < timingGridCount)
			{
				lineOut = LEVEL2 + STFLD + TABLEtimingGrid;
				lineOut += SPC + FIELDsaveID + FIELDEQ + timingGrids[curTimingGrid].saveID.ToString() + ENDQT;
				if (timingGrids[curTimingGrid].name.Length > 1)
				{
					lineOut += SPC + FIELDname + FIELDEQ + timingGrids[curTimingGrid].name + ENDQT;
				}
				lineOut += SPC + FIELDtype + FIELDEQ + timingName(timingGrids[curTimingGrid].type) + ENDQT;
				if (timingGrids[curTimingGrid].spacing > 1)
				{
					lineOut += SPC + FIELDspacing + FIELDEQ + timingGrids[curTimingGrid].spacing.ToString() + ENDQT;
				}
				if (timingGrids[curTimingGrid].type == timingGridType.fixedGrid)
				{
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				else if (timingGrids[curTimingGrid].type == timingGridType.freeform)
				{
					lineOut += FINFLD;
					writer.WriteLine(lineOut); lineCount++;

					for (int tm = 0; tm < timingGrids[curTimingGrid].itemCount; tm++)
					//while (timingGridItems[curGridItem].gridIndex == curTimingGrid)
					{
						lineOut = LEVEL4 + STFLD + TABLEtiming;
						lineOut += SPC + FIELDcentisecond + FIELDEQ + timingGrids[curTimingGrid].timings[tm].ToString() + ENDQT;
						lineOut += ENDFLD;
						writer.WriteLine(lineOut); lineCount++;

						curGridItem++;
					}

					lineOut = LEVEL2 + FINTBL + TABLEtimingGrid + FINFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				curTimingGrid++;
			}
			lineOut = LEVEL1 + FINTBL + TABLEtimingGrid + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			// TRACKS
			lineOut = LEVEL1 + STFLD + TABLEtrack + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;
			while (curTrack < trackCount)
			{
				lineOut = LEVEL2 + STFLD + TABLEtrack;
				if (tracks[curTrack].name.Length > 1)
				{
					lineOut += SPC + FIELDname + FIELDEQ + tracks[curTrack].name + ENDQT;
				}
				lineOut += SPC + FIELDtotalCentiseconds + FIELDEQ + tracks[curTrack].totalCentiseconds.ToString() + ENDQT;
				lineOut += SPC + TABLEtimingGrid + FIELDEQ + tracks[curTrack].timingGridSaveID.ToString() + ENDQT;
				lineOut += FINFLD;
				writer.WriteLine(lineOut); lineCount++;

				lineOut = LEVEL3 + STFLD + TABLEchannel + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;

				/*
				while (trackItems[curTrackItem].trackIndex == curTrack)
				{
					lineOut = LEVEL4 + STFLD + TABLEchannel;
					//lineOut += SPC + FIELDsavedIndex + FIELDEQ + trackItems[curTrackItem].savedIndex.ToString() + ENDQT;
					newSI = updatedTracks[curTrack].newSavedIndexes[curTrackItem];
					lineOut += SPC + FIELDsavedIndex + FIELDEQ + newSI.ToString() + ENDQT;
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;

					curTrackItem++;
				}
				*/
				for (int iti = 0; iti < tracks[curTrack].itemCount; iti++)
				{
					lineOut = LEVEL4 + STFLD + TABLEchannel;
					//lineOut += SPC + FIELDsavedIndex + FIELDEQ + trackItems[curTrackItem].savedIndex.ToString() + ENDQT;
					newSI = updatedTracks[curTrack].newSavedIndexes[iti];
					lineOut += SPC + FIELDsavedIndex + FIELDEQ + newSI.ToString() + ENDQT;
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;

					curTrackItem++;
				}

				lineOut = LEVEL3 + FINTBL + TABLEchannel + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
				curTrack++;

				// TODO: Support Loops!
				lineOut = "      <loopLevels/>";
				writer.WriteLine(lineOut); lineCount++;

				lineOut = LEVEL2 + FINTBL + TABLEtrack + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
			}
			lineOut = LEVEL1 + FINTBL + TABLEtrack + PLURAL + FINFLD;
			writer.WriteLine(lineOut); lineCount++;

			lineOut = animationInfo;
			writer.WriteLine(lineOut); lineCount++;

			lineOut = FINTBL + TABLEsequence + FINFLD; // "</sequence>";
			writer.WriteLine(lineOut); lineCount++;

			Console.WriteLine(lineCount.ToString() + " Out:" + lineOut);
			Console.WriteLine("");

			writer.Flush();
			writer.Close();

			if (File.Exists(newFilename))
			{
				string bakFile = newFilename.Substring(0, newFilename.Length - 3) + "bak";
				if (File.Exists(bakFile))
				{
					File.Delete(bakFile);
				}
				File.Move(newFilename, bakFile);
			}
			File.Move(tmpFile, newFilename);

			if (errState <= 0)
			{
				FileName = newFilename;
			}

			return errState;
		} // end WriteClipboardFile




		private int[] writeTrackItems(int trackIndex)
		{
			int saveIndex = -1;
			int itemCount = 0;
			int[] newSIs = new int[1];
			track tr = tracks[trackIndex];
			//int curTrackItem = findFirstTrackItem(trackIndex);
			for (int iti=0; iti < tracks[trackIndex].itemCount; iti++)
			{
				int si = tracks[trackIndex].itemSavedIndexes[iti];
				if (savedIndexes[si].objType == tableType.channel)
				{
					saveIndex = writeChannel(savedIndexes[si].objIndex);
				}
				else if (savedIndexes[si].objType == tableType.rgbChannel)
				{
					saveIndex = writergbChannel(savedIndexes[si].objIndex);
				}
				else if (savedIndexes[si].objType == tableType.channelGroup)
				{
					saveIndex = writeChannelGroup(savedIndexes[si].objIndex);
				}
				Array.Resize(ref newSIs, itemCount + 1);
				newSIs[itemCount] = saveIndex;
				itemCount++;
				//curTrackItem++;
			}
			return newSIs;
		}

		private int writeChannel(int channelIndex)
		{
			if (!channels[channelIndex].written)
			{
				lineOut = LEVEL2 + STFLD + TABLEchannel;
				lineOut += SPC + FIELDname + FIELDEQ + channels[channelIndex].name + ENDQT;
				lineOut += SPC + FIELDcolor + FIELDEQ + channels[channelIndex].color.ToString() + ENDQT;
				lineOut += SPC + FIELDcentiseconds + FIELDEQ + channels[channelIndex].centiseconds.ToString() + ENDQT;
				if (channels[channelIndex].deviceType == deviceType.LOR)
				{
					lineOut += SPC + FIELDdeviceType + FIELDEQ + deviceName(channels[channelIndex].deviceType) + ENDQT;
					lineOut += SPC + FIELDunit + FIELDEQ + channels[channelIndex].unit.ToString() + ENDQT;
					lineOut += SPC + FIELDcircuit + FIELDEQ + channels[channelIndex].circuit.ToString() + ENDQT;
				}
				else if (channels[channelIndex].deviceType == deviceType.DMX)
				{
					lineOut += SPC + FIELDdeviceType + FIELDEQ + deviceName(channels[channelIndex].deviceType) + ENDQT;
					lineOut += SPC + FIELDcircuit + FIELDEQ + channels[channelIndex].circuit.ToString() + ENDQT;
					lineOut += SPC + FIELDnetwork + FIELDEQ + channels[channelIndex].network.ToString() + ENDQT;
				}
				lineOut += SPC + FIELDsavedIndex + FIELDEQ + curSavedIndex.ToString() + ENDQT;
				channels[channelIndex].savedIndex = curSavedIndex;
				curSavedIndex++;

				// Are there any effects for this channel?
				//firstEffect = findFirstEffect(channelIndex);
				if (channels[channelIndex].effectCount > 0)
				{
					// complete channel line with regular '>' then do effects
					lineOut += FINFLD;
					writer.WriteLine(lineOut); lineCount++;

					writeEffects(channels[channelIndex]);

					lineOut = LEVEL2 + FINTBL + TABLEchannel + FINFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				else // NO effects for this channal
				{
					// complete channel line with field end '/>'
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;
				}
				channels[channelIndex].written = true;
			}
			return channels[channelIndex].savedIndex;
		}

		private int writergbChannel(int rgbChannelIndex)
		{
			if (!rgbChannels[rgbChannelIndex].written)
			{
				int redSavedIndex = writeChannel(rgbChannels[rgbChannelIndex].redChannelIndex);
				int grnSavedIndex = writeChannel(rgbChannels[rgbChannelIndex].grnChannelIndex);
				int bluSavedIndex = writeChannel(rgbChannels[rgbChannelIndex].bluChannelIndex);

				lineOut = LEVEL2 + STFLD + TABLErgbChannel;
				lineOut += SPC + FIELDtotalCentiseconds + FIELDEQ + rgbChannels[rgbChannelIndex].totalCentiseconds.ToString() + ENDQT;
				lineOut += SPC + FIELDname + FIELDEQ + rgbChannels[rgbChannelIndex].name + ENDQT;
				lineOut += SPC + FIELDsavedIndex + FIELDEQ + curSavedIndex.ToString() + ENDQT;
				rgbChannels[rgbChannelIndex].savedIndex = curSavedIndex;
				curSavedIndex++;
				lineOut += FINFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL3 + STFLD + TABLEchannel + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL4 + STFLD + TABLEchannel;
				lineOut += SPC + FIELDsavedIndex + FIELDEQ + redSavedIndex.ToString() + ENDQT;
				lineOut += ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL4 + STFLD + TABLEchannel;
				lineOut += SPC + FIELDsavedIndex + FIELDEQ + grnSavedIndex.ToString() + ENDQT;
				lineOut += ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL4 + STFLD + TABLEchannel;
				lineOut += SPC + FIELDsavedIndex + FIELDEQ + bluSavedIndex.ToString() + ENDQT;
				lineOut += ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL3 + FINTBL + TABLEchannel + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL2 + FINTBL + TABLErgbChannel + FINFLD;
				writer.WriteLine(lineOut); lineCount++;

				rgbChannels[rgbChannelIndex].written = true;
			}
			return rgbChannels[rgbChannelIndex].savedIndex;
		}

		private int writeChannelGroup(int channelGroupIndex)
		{
			//dbgMsg = "writeChannelGroup(Index=" + channelGroupIndex.ToString() + ") SavedIndex=" + channelGroups[channelGroupIndex].savedIndex + " Name=" + channelGroups[channelGroupIndex].name   ;
			//Debug.Print(dbgMsg);

			int[] newSIs;
			int itemNo = 0;

			if (!channelGroups[channelGroupIndex].written)
			{
				//int curItem = findFirstGroupItem(channelGroupIndex);

				newSIs = writeChannelGroupItems(channelGroupIndex);

				lineOut = LEVEL2 + STFLD + TABLEchannelGroupList;
				lineOut += SPC + FIELDtotalCentiseconds + FIELDEQ + channelGroups[channelGroupIndex].totalCentiSeconds.ToString() + ENDQT;
				lineOut += SPC + FIELDname + FIELDEQ + channelGroups[channelGroupIndex].name + ENDQT;
				lineOut += SPC + FIELDsavedIndex + FIELDEQ + curSavedIndex.ToString() + ENDQT;
				channelGroups[channelGroupIndex].savedIndex = curSavedIndex;
				curSavedIndex++;
				lineOut += FINFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL3 + STFLD + TABLEchannelGroup + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;

				for (int igi = 0; igi < channelGroups[channelGroupIndex].itemCount; igi++)
				{
					lineOut = LEVEL4 + STFLD + TABLEchannelGroup;
					lineOut += SPC + FIELDsavedIndex + FIELDEQ + newSIs[itemNo].ToString() + ENDQT;
					lineOut += ENDFLD;
					writer.WriteLine(lineOut); lineCount++;
					itemNo++;
					//curItem++;
				}

				lineOut = LEVEL3 + FINTBL + TABLEchannelGroup + PLURAL + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
				lineOut = LEVEL2 + FINTBL + TABLEchannelGroupList + FINFLD;
				writer.WriteLine(lineOut); lineCount++;
			}
			return channelGroups[channelGroupIndex].savedIndex;
		}

		private int[] writeChannelGroupItems(int channelGroupIndex)
		{
			int[] newSIs = new int[1];
			int itemCount = 0;
			int si = -1;
			int saveIndex = -1;
			//int curGroupItem = firstGroupItem;

			for (int igi=0; igi < channelGroups[channelGroupIndex].itemCount; igi++)
			{
				si = channelGroups[channelGroupIndex].itemSavedIndexes[igi];
				if (savedIndexes[si].objType == tableType.channel)
				{
					saveIndex = writeChannel(savedIndexes[si].objIndex);
				}
				else if (savedIndexes[si].objType == tableType.rgbChannel)
				{
					saveIndex = writergbChannel(savedIndexes[si].objIndex);
				}
				else if (savedIndexes[si].objType == tableType.channelGroup)
				{
					saveIndex = writeChannelGroup(savedIndexes[si].objIndex);
				}

				Array.Resize(ref newSIs, itemCount + 1);
				newSIs[itemCount] = saveIndex;
				itemCount++;

				//curGroupItem++;
			}
			return newSIs;
		}

		private void writeEffects(channel thisChannel)
		{
			for (int effectIndex=0; effectIndex < thisChannel.effectCount; effectIndex++)
			//while (effects[curEffect].channelIndex == channelIndex)
			{
				lineOut = LEVEL3 + STFLD + TABLEeffect;
				lineOut += SPC + FIELDtype + FIELDEQ + effectName(thisChannel.effects[effectIndex].type) + ENDQT;
				lineOut += SPC + FIELDstartCentisecond + FIELDEQ + thisChannel.effects[effectIndex].startCentisecond.ToString() + ENDQT;
				lineOut += SPC + FIELDendCentisecond + FIELDEQ + thisChannel.effects[effectIndex].endCentisecond.ToString() + ENDQT;
				if (thisChannel.effects[effectIndex].intensity > -1)
				{
					lineOut += SPC + FIELDintensity + FIELDEQ + thisChannel.effects[effectIndex].intensity.ToString() + ENDQT;
				}
				if (thisChannel.effects[effectIndex].startIntensity > -1)
				{
					lineOut += SPC + FIELDstartIntensity + FIELDEQ + thisChannel.effects[effectIndex].startIntensity.ToString() + ENDQT;
					lineOut += SPC + FIELDendIntensity + FIELDEQ + thisChannel.effects[effectIndex].endIntensity.ToString() + ENDQT;
				}
				lineOut += ENDFLD;
				writer.WriteLine(lineOut); lineCount++;
			}
		}

		private string fileNameOnly(string fullFileName)
		{
			FileInfo fi = new FileInfo(fullFileName);
			string nameOnly = fi.Name;
			nameOnly = nameOnly.Substring(nameOnly.Length - fi.Extension.Length);
			return nameOnly;
		}


		public static Int32 getKeyValue(string lineIn, string keyWord)
		{
			Int32 valueOut = -1;
			int pos1 = -1;
			int pos2 = -1;
			string fooo = "";

			pos1 = lineIn.IndexOf(keyWord + "=");
			if (pos1 > 0)
			{
				fooo = lineIn.Substring(pos1 + keyWord.Length + 2);
				pos2 = fooo.IndexOf("\"");
				fooo = fooo.Substring(0, pos2);
				valueOut = Convert.ToInt32(fooo);
			}
			else
			{
				valueOut = -1;
			}

			return valueOut;
		}

		public static string getKeyWord(string lineIn, string keyWord)
		{
			string valueOut = "";
			int pos1 = -1;
			int pos2 = -1;
			string fooo = "";

			pos1 = lineIn.IndexOf(keyWord + "=");
			if (pos1 > 0)
			{
				fooo = lineIn.Substring(pos1 + keyWord.Length + 2);
				pos2 = fooo.IndexOf("\"");
				fooo = fooo.Substring(0, pos2);
				valueOut = fooo;
			}
			else
			{
				valueOut = "";
			}

			return valueOut;
		}

		private static deviceType enumDevice(string deviceName)
		{
			deviceType valueOut = deviceType.None;

			if (deviceName == DEVICElor)
			{
				valueOut = deviceType.LOR;
			}
			else if (deviceName == DEVICEdmx)
			{
				valueOut = deviceType.DMX;
			}
			else if (deviceName == DEVICEdigital)
			{
				valueOut = deviceType.Digital;
			}
			else if (deviceName == "")
			{
				valueOut = deviceType.None;
			}
			else
			{
				// TODO: throw exception here!
				valueOut = deviceType.None;
				string sMsg = "Unrecognized Device Type: ";
				sMsg += deviceName;
				DialogResult dr = MessageBox.Show(sMsg, "Unrecognized Keyword", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			return valueOut;
		}

		private static effectType enumEffect(string effectName)
		{
			effectType valueOut = effectType.None;

			if (effectName == EFFECTintensity)
			{
				valueOut = effectType.intensity;
			}
			else if (effectName == EFFECTshimmer)
			{
				valueOut = effectType.shimmer;
			}
			else if (effectName == EFFECTtwinkle)
			{
				valueOut = effectType.twinkle;
			}
			else if (effectName == EFFECTdmx)
			{
				valueOut = effectType.DMX;
			}
			else
			{
				// TODO: throw exception here
				valueOut = effectType.None;
				string sMsg = "Unrecognized Effect Name: ";
				sMsg += effectName;
				DialogResult dr = MessageBox.Show(sMsg, "Unrecognized Keyword", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			return valueOut;
		}

		private static timingGridType enumGridType(string typeName)
		{
			timingGridType valueOut = timingGridType.None;

			if (typeName == GRIDfreeform)
			{
				valueOut = timingGridType.freeform;
			}
			else if (typeName == "fixed")
			{
				valueOut = timingGridType.fixedGrid;
			}
			else
			{
				// TODO: throw exception here
				valueOut = timingGridType.None;
				string sMsg = "Unrecognized Timing Grid Type: ";
				sMsg += typeName;
				DialogResult dr = MessageBox.Show(sMsg, "Unrecognized Keyword", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}

			return valueOut;
		}

		private static string deviceName(deviceType devType)
		{
			string valueOut = "";
			switch (devType)
			{
				case deviceType.LOR:
					valueOut = DEVICElor;
					break;

				case deviceType.DMX:
					valueOut = DEVICEdmx;
					break;

				case deviceType.Digital:
					valueOut = DEVICEdigital;
					break;
			}
			return valueOut;
		}

		private static string effectName(effectType effType)
		{
			string valueOut = "";
			switch (effType)
			{
				case effectType.intensity:
					valueOut = EFFECTintensity;
					break;

				case effectType.shimmer:
					valueOut = EFFECTshimmer;
					break;

				case effectType.twinkle:
					valueOut = EFFECTtwinkle;
					break;

				case effectType.DMX:
					valueOut = EFFECTdmx;
					break;
			}
			return valueOut;
		}

		private static string timingName(timingGridType grdType)
		{
			string valueOut = "";
			switch (grdType)
			{
				case timingGridType.freeform:
					valueOut = GRIDfreeform;
					break;

				case timingGridType.fixedGrid:
					valueOut = GRIDfixed;
					break;
			}
			return valueOut;
		}

		/*
		private int findFirstTrackItem(int trackIndex)
		{
			int firstItem = -1;
			for (int i = 0; i < trackItemCount; i++)
			{
				if (trackItems[i].trackIndex == trackIndex)
				{
					firstItem = i;
					break;
				}
			}
			return firstItem;
		}
		*/

			/*
		private int findFirstEffect(int channelIndex)
		{
			int firstItem = -1;
			for (int i = 0; i < effectCount; i++)
			{
				if (effects[i].channelIndex == channelIndex)
				{
					firstItem = i;
					break;
				}
			}
			return firstItem;
		}
		*/

		/*
		 * private int findFirstGroupItem(int channelGroupIndex)
		{
			int firstItem = -1;
			for (int i = 0; i < groupItemCount; i++)
			{
				if (channelGroupItems[i].channelGroupListIndex == channelGroupIndex)
				{
					firstItem = i;
					break;
				}
			}
			return firstItem;
		}
		*/
	}
}