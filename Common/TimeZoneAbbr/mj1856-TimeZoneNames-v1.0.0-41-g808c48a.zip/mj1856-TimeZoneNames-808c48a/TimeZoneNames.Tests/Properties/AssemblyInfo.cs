﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TimeZoneNames.Tests")]
[assembly: AssemblyDescription("Tests for time zone names.")]

[assembly: ComVisible(false)]