﻿using LORUtils;
using System;
using System.IO;
using System.Windows.Forms;
using System.Media;
using System.Drawing;
using LORUtils;

namespace StringORama
{
	public partial class frmString : Form
	{
		private string lastFile = "";
		private string[] channels;
		private int[] unitIDs;
		private int[] unitChs;
		private RGBchannel[,] chanMatrix = null;
		private ChannelGroup[] sectionGroups = null;
		private ChannelGroup[] pixelGroups = null;
		private int chCount = 0;
		private int changesMade = 0;
		private bool reversed = false;
		private Sequence4 seq;

		private string sectionName = "";
		private int sectionNum = 1;
		private int batchCount = 170;
		private int batchStart = 1;
		private int batchEnd = 170;
		private int chOrder = 1;
		private int groupSize = 16;
		private int chIncr = 1;
		private int universeNum = 5;
		private int pixelNum = 1;
		private int chanNum = 1;
		private int chanBegin = 1;
		private int chanEnd = 3;

		private int sections = 0;
		private int pixelsPerSect = 0;
		private int rows = 0;
		private int pixelsPerRow = 0;

		private int airRows = 8;
		private int airCols = 8;
		private ChannelGroup[] colGroups = null;
		private ChannelGroup[] rowGroups = null;

		public frmString()
		{
			InitializeComponent();
		}

		private void lorForm_Load(object sender, EventArgs e)
		{
			initForm();
		}

		private void initForm()
		{
			lastFile = Properties.Settings.Default.lastFile;
			
			string ChannelList = Properties.Settings.Default.lastFile;
			//channels = ChannelList.Split(',');
			string basePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Light-O-Rama\\Sequences\\";

			if (lastFile.Length > basePath.Length)
			{
				if (lastFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
				{
					txtFile.Text = lastFile.Substring(basePath.Length);
				}
				else
				{
					txtFile.Text = lastFile;
				} // End else (lastFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
			} // end if (lastFile.Length > basePath.Length)

			/*
			if (channels.Length > 0)
			{
					for (int loop = 0; loop < channels.Length; loop++)
					{
							if (channels[loop].Length > 0)
							{
									channelsListBox.Items.Add(channels[loop]);
							} // end if (channels[loop].Length > 0)
					} // end for (int loop = 0; loop <= channels.Length; loop++)
			} // end if (channels.Length > 0)
			 */

			loadFormSettings();
		} // end private void InitForm()

		private void EnableControls(bool newState)
		{
			btnMake.Enabled = newState;
			fraBatch1.Enabled = newState;
			fraBatch2.Enabled = newState;
			fraAirship.Enabled = newState;
			txtFile.Enabled = newState;
			btnBrowse.Enabled = newState;
		}

		private void BrowseButton_Click(object sender, EventArgs e)
		{
			string basePath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Light-O-Rama\\Sequences\\";
			if (File.Exists(lastFile))
			{
				FileInfo fi = new FileInfo(lastFile);
				openFileDialog.InitialDirectory = fi.DirectoryName;
				openFileDialog.FileName = fi.Name;
			}
			else
			{
				openFileDialog.InitialDirectory = utils.DefaultSequencesPath;
				openFileDialog.FileName = "";
			}
			openFileDialog.Filter = "Sequences (*.lms,las)|*.lms;*.las|Just Musical Sequences (*.lms)|*.lms|Just Animated Sequences (*.las)|*.las";
			openFileDialog.DefaultExt = "*.lms;*.las";
			//openFileDialog.InitialDirectory = basePath;
			
			openFileDialog.CheckFileExists = true;
			openFileDialog.CheckPathExists = true;
			openFileDialog.Multiselect = false;
			DialogResult result = openFileDialog.ShowDialog();

			if (result == DialogResult.OK)
			{
				lastFile = openFileDialog.FileName;
				if (lastFile.Length > basePath.Length)
				{
					if (lastFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
					{
						txtFile.Text = lastFile.Substring(basePath.Length);
					}
					else
					{
						txtFile.Text = lastFile;
					} // End else (lastFile.Substring(0, basePath.Length).CompareTo(basePath) == 0)
				} // end if (lastFile.Length > basePath.Length)
			} // end if (result = DialogResult.OK)
		} // end private void BrowseButton_Click(object sender, EventArgs e)

		private void lorForm_FormClosed(object sender, FormClosedEventArgs e)
		{
			saveFormSettings();
		}

		private void RestoreFormPosition()
		{
			// Multi-Monitor aware
			// with bounds checking
			// repositions as necessary
			// should(?) be able to handle an additional screen that is no longer there,
			// a repositioned taskbar or gadgets bar,
			// or a resolution change.

			// Note: If the saved position spans more than one screen
			// the form will be repositioned to fit all within the
			// screen containing the center point of the form.
			// Thus, when restoring the position, it will no longer
			// span monitors.
			// This is by design!
			// Alternative 1: Position it entirely in the screen containing
			// the top left corner

			Point savedLoc = Properties.Settings.Default.Location;
			Size savedSize = Properties.Settings.Default.Size;
			FormWindowState savedState = (FormWindowState)Properties.Settings.Default.WindowState;
			int x = savedLoc.X; // Default to saved postion and size, will override if necessary
			int y = savedLoc.Y;
			int w = savedSize.Width;
			int h = savedSize.Height;
			Point center = new Point(x + w / w, y + h / 2); // Find center point
			int onScreen = 0; // Default to primary screen if not found on screen 2+
			Screen screen = Screen.AllScreens[0];

			// Find which screen it is on
			for (int si = 0; si < Screen.AllScreens.Length; si++)
			{
				// Alternative 1: Change "Contains(center)" to "Contains(savedLoc)"
				if (Screen.AllScreens[si].WorkingArea.Contains(center))
				{
					screen = Screen.AllScreens[si];
					onScreen = si;
				}
			}
			Rectangle bounds = screen.WorkingArea;
			// Alternate 2:
			//Rectangle bounds = Screen.GetWorkingArea(center);

			// Test Horizontal Positioning, correct if necessary
			if (this.MinimumSize.Width > bounds.Width)
			{
				// Houston, we have a problem, monitor is too narrow
				System.Diagnostics.Debugger.Break();
				w = this.MinimumSize.Width;
				// Center it horizontally over the working area...
				//x = (bounds.Width - w) / 2 + bounds.Left;
				// OR position it on left edge
				x = bounds.Left;
			}
			else
			{
				// Should fit horizontally
				// Is it too far left?
				if (x < bounds.Left) x = bounds.Left; // Move over
																							// Is it too wide?
				if (w > bounds.Width) w = bounds.Width; // Shrink it
																								// Is it too far right?
				if ((x + w) > bounds.Right)
				{
					// Keep width, move it over
					x = (bounds.Width - w) + bounds.Left;
				}
			}

			// Test Vertical Positioning, correct if necessary
			if (this.MinimumSize.Height > bounds.Height)
			{
				// Houston, we have a problem, monitor is too short
				System.Diagnostics.Debugger.Break();
				h = this.MinimumSize.Height;
				// Center it vertically over the working area...
				//y = (bounds.Height - h) / 2 + bounds.Top;
				// OR position at the top edge
				y = bounds.Top;
			}
			else
			{
				// Should fit vertically
				// Is it too high?
				if (y < bounds.Top) y = bounds.Top; // Move it down
																						// Is it too tall;
				if (h > bounds.Height) h = bounds.Height; // Shorten it
																									// Is it too low?
				if ((y + h) > bounds.Bottom)
				{
					// Kepp height, raise it up
					y = (bounds.Height - h) + bounds.Top;
				}
			}

			// Position and Size should be safe!
			// Move and Resize the form
			this.SetDesktopLocation(x, y);
			this.Size = new Size(w, h);

			// Window State
			if (savedState == FormWindowState.Maximized)
			{
				if (this.MaximizeBox)
				{
					// Optional.  Personally, I think it should always be reloaded non-maximized.
					//this.WindowState = savedState;
				}
			}
			if (savedState == FormWindowState.Minimized)
			{
				if (this.MinimizeBox)
				{
					// Don't think it's right to reload to a minimized state (confuses the user),
					// but you can enable this if you want.
					//this.WindowState = savedState;
				}
			}

		} // End LoadFormPostion

		private void SaveFormPosition()
		{
			// Get current location, size, and state
			Point myLoc = this.Location;
			Size mySize = this.Size;
			FormWindowState myState = this.WindowState;
			// if minimized or maximized
			if (myState != FormWindowState.Normal)
			{
				// override with the restore location and size
				myLoc = new Point(this.RestoreBounds.X, this.RestoreBounds.Y);
				mySize = new Size(this.RestoreBounds.Width, this.RestoreBounds.Height);
			}

			// Save it for later!
			Properties.Settings.Default.Location = myLoc;
			Properties.Settings.Default.Size = mySize;
			Properties.Settings.Default.WindowState = (int)myState;
			Properties.Settings.Default.Save();
		} // End SaveFormPostion

		private void saveFormSettings()
		{
			byte which;

			Properties.Settings.Default.FormLeft = this.Left;
			Properties.Settings.Default.FormTop = this.Top;

			Properties.Settings.Default.Track = Int16.Parse(txtTrack.Text);

			Properties.Settings.Default.Make1 = chkDoFence.Checked;
			Properties.Settings.Default.Universe1 = Convert.ToInt16(numUniverse1.Value);
			Properties.Settings.Default.batchName1 = txtBatchName1.Text;
			Properties.Settings.Default.StartCh1 = Int16.Parse(txtStartCh1.Text);
			Properties.Settings.Default.KeywdelCt1 = Int16.Parse(txtSections.Text);
			which = 0;
			if (optRGB1.Checked) which = 1;
			if (optGRB1.Checked) which = 2;
			Properties.Settings.Default.ColorOrder1 = which;
			Properties.Settings.Default.Reverse1 = optReverse1.Checked;


			Properties.Settings.Default.lastFile = txtFile.Text;

			Properties.Settings.Default.Save();
		}

		private void loadFormSettings()
		{
			int which;

			this.Left = Properties.Settings.Default.FormLeft;
			this.Top = Properties.Settings.Default.FormTop;

			txtTrack.Text = Properties.Settings.Default.Track.ToString();

			chkDoFence.Checked = Properties.Settings.Default.Make1;
			numUniverse1.Value = Properties.Settings.Default.Universe1;
			txtBatchName1.Text = Properties.Settings.Default.batchName1;
			txtStartCh1.Text = Properties.Settings.Default.StartCh1.ToString();
			txtSections.Text = Properties.Settings.Default.KeywdelCt1.ToString();
			which = Properties.Settings.Default.ColorOrder1;
			if (which == 1) optRGB1.Checked = true;
			if (which == 2) optGRB1.Checked = true;
			optReverse1.Checked = Properties.Settings.Default.Reverse1;

		}

		private void SetGroupSize(ComboBox GrpSizeCbo, int size)
		{
			GrpSizeCbo.SelectedIndex = 0;
			for (int q = 0; q < GrpSizeCbo.Items.Count; q++)
			{
				if (Convert.ToInt16(GrpSizeCbo.Items[q]) == size)
				{
					GrpSizeCbo.SelectedIndex = q;
				}
			}
		}

		private void skimFile(string fileName)
		{
			int savedIndex = 0;
			int biggestIndex = 0;

			StreamReader reader = new StreamReader(fileName);
			string lineIn; // line to be written out, gets modified if necessary
			while ((lineIn = reader.ReadLine()) != null)
			{
				savedIndex = getNumberValue(lineIn, "SavedIndex");
				if (savedIndex > biggestIndex) biggestIndex = savedIndex;
			}
			reader.Close();
		}

		private int getNumberValue(string lineIn, string keyword)
		{
			keyword += "=\"";
			int found = lineIn.IndexOf(keyword);
			string part2 = lineIn.Substring(found);
			found = lineIn.IndexOf("\"");
			part2 = lineIn.Substring(0, found);
			int ret = Convert.ToInt16(lineIn);
			return ret;
		}

		private string getStringValue(string lineIn, string keyword)
		{
			keyword += "=\"";
			int found = lineIn.IndexOf(keyword);
			string part2 = lineIn.Substring(found);
			found = lineIn.IndexOf("\"");
			string ret = lineIn.Substring(0, found);
			return ret;
		}

		private void putNumberValue(ref string lineIn, string keyword, int value)
		{
			string part1 = "";
			string part2 = "";

			keyword += "=\"";
			int found = lineIn.IndexOf(keyword);
			if (found >= 0)
			{
				part1 = lineIn.Substring(0, found);
				part2 = lineIn.Substring(found);
				found = lineIn.IndexOf("\"");
				part2 = lineIn.Substring(0, found);
				lineIn = part1 + value.ToString() + part2;
			}
			else
			{
				found = lineIn.IndexOf(">");
				part1 = lineIn.Substring(0, found);
				part2 = lineIn.Substring(found);
				found = part1.IndexOf("\\");
				if (found >= 0)
				{
					part1 += part2.Substring(found);
					part2 = part2.Substring(found);
				}
				string lineOut = part1 + " " + keyword + "=\"" + value.ToString() + "\"" + part2;
				lineIn = lineOut;
			}
		}

		private void putStringValue(ref string lineIn, string keyword, string value)
		{
			string part1 = "";
			string part2 = "";

			keyword += "=\"";
			int found = lineIn.IndexOf(keyword);
			if (found >= 0)
			{
				part1 = lineIn.Substring(0, found);
				part2 = lineIn.Substring(found);
				found = lineIn.IndexOf("\"");
				part2 = lineIn.Substring(0, found);
				lineIn = part1 + value + part2;
			}
			else
			{
				found = lineIn.IndexOf(">");
				part1 = lineIn.Substring(0, found);
				part2 = lineIn.Substring(found);
				found = part1.IndexOf("\\");
				if (found >= 0)
				{
					part1 += part2.Substring(found);
					part2 = part2.Substring(found);
				}
				string lineOut = part1 + " " + keyword + value + "\"" + part2;
				lineIn = lineOut;
			}
		}


		private void ImBusy(bool busyState)
		{
			fraBatch1.Enabled = !busyState;
			fraBatch2.Enabled = !busyState;
			fraAirship.Enabled = !busyState;
			fraBatch4.Enabled = !busyState;
			btnMake.Enabled = !busyState;
			txtFile.Enabled = !busyState;
			btnBrowse.Enabled = !busyState;
		}

		private void btnMake_Click(object sender, EventArgs e)
		{
			ImBusy(true);
			
			seq = new Sequence4();
			if (File.Exists(lastFile))
			{
				seq.ReadSequenceFile(lastFile);
			}

			if (chkDoFence.Checked)
			{
				BuildFence();
			}

			if (chkDoAirship.Checked)
			{
				BuildShip();
			}

			if (chkDoTree.Checked)
			{
				BuildTree();
			}

			FileInfo oFilenfo = new FileInfo(lastFile);
			string newFile = oFilenfo.Directory + "\\" + JustName(lastFile) + " + NEW" + oFilenfo.Extension;

			seq.WriteSequenceFile(newFile);
			//seq.WriteFileInDisplayOrder(newFile);

			ImBusy(false);
			SystemSounds.Exclamation.Play();

		}

		private void BuildFence()
		{
			/////////////////////////////////////////////////////////////
			//
			//   Batch 1 IS THE PERIMETER FENCE
			//   DONE AS MATRIX   ~~  x Sections by Y Keywdels-per-section
			//   Grouped by Section, and
			//   Grouped by Keywdel # (per section)

			pixelNum = 1;
			sections = Int16.Parse(txtSections.Text);
			pixelsPerSect = Int16.Parse(txtKeywdelsPerSect.Text);
			int totalKeywdels = sections * pixelsPerSect;
			int totalChans = totalKeywdels * 3;
			universeNum = (int)numUniverse1.Value;
			int sectNum = 1;
			string batchName = txtBatchName1.Text;
			reversed = optReverse1.Checked;

			//Array.Resize(ref chanMatrix[], sections, pixelsPerSect);
			chanMatrix = new RGBchannel[sections, pixelsPerSect];
			sectionGroups = new ChannelGroup[sections];
			pixelGroups = new ChannelGroup[pixelsPerSect];

			sectionName = batchName + "s [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum + 1).ToString() + ".";
			sectionName += (166 * 3).ToString() + "]";
			int tknum = int.Parse(txtTrack.Text);
			Track trak = seq.CreateTrack(sectionName);

			sectionName = batchName + "s by Section [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum + 1).ToString() + ".";
			sectionName += (166 * 3).ToString() + "]";
			ChannelGroup grpSects =  seq.CreateChannelGroup(sectionName);
			trak.AddItem(grpSects);

			sectionName = batchName + "s by Keywdel # [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum + 1).ToString() + ".";
			sectionName += (166 * 3).ToString() + "]";
			ChannelGroup grpKeywds = seq.CreateChannelGroup(sectionName);
			trak.AddItem(grpKeywds);

			


			sectionName = batchName;
			sectionNum = 1;
			pixelNum = 1;
			if (optReverse1.Checked)
			{
				universeNum++;
				int n1 = totalKeywdels - 170;
				int n2 = n1 * 3 - 2;
				chanNum = n2;
				batchStart = Int16.Parse(txtStartCh1.Text);
				batchEnd = Int16.Parse(txtStartCh1.Text);
				chIncr = -1;
			}
			else
			{
				chanNum = 1;
				batchStart = Int16.Parse(txtStartCh1.Text);
				batchEnd = Int16.Parse(txtSections.Text);
				chIncr = 1;
			}
				
			if (optRGB1.Checked) chOrder = 1;
			if (optGRB1.Checked) chOrder = 2;

			// Sections
			for (int sect = 0; sect < sections; sect++)
			{
				//TODO: Reverse Order
				// Use just forward order for now
				ChannelGroup theGroup = AddSection(sect);
				grpSects.AddItem(theGroup);
			}


			// Create the second major group
			// Another copy of the matrix, but pivoted
			// Grouped by Keywdel # instead of by sectioon #
			for (int pxl = 0; pxl < pixelsPerSect; pxl++)
			{
				string grName = sectionName + "s #" + (pxl+1).ToString("00") + "s";
				ChannelGroup theGroup = seq.CreateChannelGroup(grName);
				for (int s=0; s< sections; s++)
				{
					theGroup.AddItem(chanMatrix[s, pxl]);
				}
				grpKeywds.AddItem(theGroup);

			}

			
		} // end btnMake_Click()

		private void BuildShip()
		{
			/////////////////////////////////////////////////////////////
			//
			//   Batch 3 IS THE AIRSHIP PROJECTOR
			//   DONE AS MATRIX   ~~  x Columns by Y Rows
			//   Grouped by Column and by Row
			
			pixelNum = 0;
			airCols = Int16.Parse(txtAirCols.Text);
			airRows = Int16.Parse(txtAirRows.Text);
			int totalKeywdels = airRows * airCols;
			int totalChans = totalKeywdels * 3;
			universeNum = (int)numUnivAirship.Value;
			int airCol = 1;
			string batchName = txtAirName.Text;
			reversed = false;

			//Array.Resize(ref chanMatrix[], sections, pixelsPerSect);
			chanMatrix = new RGBchannel[airCols, airRows];
			colGroups = new ChannelGroup[airCols];
			rowGroups = new ChannelGroup[airRows];

			sectionName = batchName + " [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum).ToString() + ".";
			sectionName += (64 * 3).ToString() + "]";
			int tknum = int.Parse(txtTrack.Text);
			Track trak = seq.CreateTrack(sectionName);

			sectionName = batchName + " by Column [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum).ToString() + ".";
			sectionName += (64 * 3).ToString() + "]";
			ChannelGroup grpCols = seq.CreateChannelGroup(sectionName);
			trak.AddItem(grpCols);

			sectionName = batchName + " by Row [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum).ToString() + ".";
			sectionName += (64 * 3).ToString() + "]";
			ChannelGroup grpRows = seq.CreateChannelGroup(sectionName);
			trak.AddItem(grpRows);




			sectionName = batchName;
			sectionNum = 1;
			pixelNum = 1;
			chanNum = 1;
			batchStart = Int16.Parse(txtStartCh1.Text);
			batchEnd = Int16.Parse(txtSections.Text);
			chIncr = 1;

			if (optRGB3.Checked) chOrder = 1;
			if (optGRB3.Checked) chOrder = 2;

			// Sections
			for (int c = 0; c < airCols; c++)
			{
				//TODO: Reverse Order
				// Use just forward order for now
				ChannelGroup theGroup = AddAirColumn(c);
				grpCols.AddItem(theGroup);
			}


			// Create the second major group
			// Another copy of the matrix, but pivoted
			// Grouped by Row instead of by Column
			for (int r = 0; r < airRows; r++)
			{
				string grName = sectionName + " Row " + (r).ToString("0");
				ChannelGroup theGroup = seq.CreateChannelGroup(grName);
				for (int c = 0; c < airCols; c++)
				{
					theGroup.AddItem(chanMatrix[c, r]);
				}
				grpRows.AddItem(theGroup);

			}


		} // end btnMake_Click()

		private void BuildTree()
		{
			/////////////////////////////////////////////////////////////
			//
			//   Batch 2 IS THE BIG CENTER PIXEL TREE
			//   DONE AS MATRIX   ~~  Initially with 12 rows with 28 pixels each
			//   For a total of 340 pixels (2 full universes)
			//   Each row has 8 sections with initially 3 or 4 pixels on each row.
			//   Once the tree is built and tested, pixels will get moved to the row
			//   and section they actually end up in

			pixelNum = 1;
			rows = int.Parse(txtRows.Text);
			pixelsPerRow = int.Parse(txtCols.Text);
			int totalKeywdels = rows * pixelsPerRow;
			int totalChans = totalKeywdels * 3;
			universeNum = (int)numUniverse2.Value;
			int sectNum = 1;
			string batchName = txtBatchName2.Text;
			reversed = optReverse2.Checked;

			chanMatrix = new RGBchannel[rows, pixelsPerRow];
			sectionGroups = new ChannelGroup[rows];
			pixelGroups = new ChannelGroup[pixelsPerRow];

			sectionName = batchName + "s [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum + 1).ToString() + ".";
			sectionName += (170 * 3).ToString() + "]";
			int tknum = int.Parse(txtTrack.Text);
			Track trak = seq.CreateTrack(sectionName);

			sectionName = batchName + "s by Row [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum + 1).ToString() + ".";
			sectionName += (170 * 3).ToString() + "]";
			ChannelGroup grpRows = seq.CreateChannelGroup(sectionName);
			trak.AddItem(grpRows);

			sectionName = batchName + "s by Section [U" + universeNum.ToString();
			sectionName += ".001-U" + (universeNum + 1).ToString() + ".";
			sectionName += (170 * 3).ToString() + "]";
			ChannelGroup grpCols = seq.CreateChannelGroup(sectionName);
			trak.AddItem(grpCols);



			sectionName = batchName;
			sectionNum = 1;
			pixelNum = 1;
			if (optReverse2.Checked)
			{
				universeNum++;
				int n1 = totalKeywdels - 160;
				int n2 = n1 * 3 - 2;
				chanNum = n2;
				batchStart = Int16.Parse(txtStartCh1.Text);
				batchEnd = Int16.Parse(txtStartCh1.Text);
				chIncr = -1;
			}
			else
			{
				chanNum = 1;
				batchStart = Int16.Parse(txtStartCh1.Text);
				batchEnd = Int16.Parse(txtSections.Text);
				chIncr = 1;
			}

			if (optRGB2.Checked) chOrder = 1;
			if (optGRB2.Checked) chOrder = 2;

			for (int r = 0; r < rows; r++)
			{
				//TODO: Reverse Order
				// Use just forward order for now
				ChannelGroup theGroup = AddRow(r);
				grpRows.AddItem(theGroup);
			}

			for (int pxl = 0; pxl < pixelsPerRow; pxl++)
			{
				string grName = sectionName + "s Section " + pxl.ToString("00");
				ChannelGroup theGroup = seq.CreateChannelGroup(grName);
				for (int row = 0; row < rows; row++)
				{
					theGroup.AddItem(chanMatrix[row, pxl]);
				}
				grpCols.AddItem(theGroup);

			}


		} // end btnMake_Click()

		public ChannelGroup AddSection(int sect)
		{
			int pixID = batchStart;
			int groupMember = 1;
			int uch = 1;
			if (chIncr < 0) uch = batchCount * 3 - 2;
			int trkNum = Int16.Parse(txtTrack.Text)-1;
			string theName = "";
			string pxName = "";
			string chName = "";
			string grName = "";

			grName = sectionName + "s Section " + (sect+1).ToString("00");
			grName += " [U" + universeNum.ToString() + ".";
			if (optReverse1.Checked)
			{
				grName += (chanNum - pixelsPerSect * 3+3).ToString("000") + "-" + (chanNum + 2).ToString("000") + "]";
			}
			else
			{
				grName += chanNum.ToString("000") + "-" + (chanNum + pixelsPerSect * 3 + 2).ToString("000") + "]";
			}
			ChannelGroup thisGroup = seq.CreateChannelGroup(grName);

			for (int pxl = 0; pxl < pixelsPerSect; pxl++)
			{
				pxName = sectionName + " " + (sect+1).ToString("00");
				pxName += "-" + (pxl+1).ToString("00");

				RGBchannel theKeywdel = MakeKeywdel(pxName, sect, pxl);
				thisGroup.AddItem(theKeywdel);

			}

			return thisGroup;

		} // end void AddBatch();

		public ChannelGroup AddAirColumn(int c)
		{
			int pixID = batchStart;
			int groupMember = 1;
			int uch = 1;
			if (chIncr < 0) uch = batchCount * 3 - 2;
			int trkNum = Int16.Parse(txtTrack.Text) - 1;
			string theName = "";
			string pxName = "";
			string chName = "";
			string grName = "";

			grName = sectionName + " Column " + (c).ToString("0");
			grName += " [U" + universeNum.ToString() + ".";
			if (optReverse1.Checked)
			{
				grName += (chanNum - pixelsPerSect * 3 + 3).ToString("000") + "-" + (chanNum + 2).ToString("000") + "]";
			}
			else
			{
				grName += chanNum.ToString("000") + "-" + (chanNum + airRows * 3 + 2).ToString("000") + "]";
			}
			ChannelGroup thisGroup = seq.CreateChannelGroup(grName);

			for (int r = 0; r < airRows; r++)
			{
				pxName = sectionName + " " + (c).ToString("0");
				pxName += "," + (r).ToString("0");
				pxName += " #" + pixelNum.ToString("00");

				RGBchannel theKeywdel = ShipKeywdel(pxName, c, r);
				thisGroup.AddItem(theKeywdel);

			}

			return thisGroup;

		} // end void AddBatch();

		public ChannelGroup AddRow(int r)
		{
			int pixID = batchStart;
			int groupMember = 1;
			int uch = 1;
			if (chIncr < 0) uch = batchCount * 3 - 2;
			int trkNum = Int16.Parse(txtTrack.Text) - 1;
			string theName = "";
			string pxName = "";
			string chName = "";
			string grName = "";
			int sxNo = 1;
			string sxName = "1S";
			int subNo = 1;

			grName = sectionName + "s Row " + (r+1).ToString("00");
			grName += " [U" + universeNum.ToString() + ".";
			if (optReverse1.Checked)
			{
				grName += (chanNum + 2).ToString("000") + "-" + (chanNum - pixelsPerRow * 3).ToString("000") + "]";
			}
			else
			{
				grName += chanNum.ToString("000") + "-" + (chanNum + pixelsPerRow * 3 + 2).ToString("000") + "]";
			}
			ChannelGroup thisGroup = seq.CreateChannelGroup(grName);

			for (int pxl = 0; pxl < pixelsPerRow; pxl++)
			{
				switch(pxl)
				{
					case 0:
						sxNo = 1;
						sxName = " {S} {Left}";
						subNo = 1;
						break;
					case 3:
						sxNo = 2;
						sxName = " {SE}";
						subNo = 1;
						break;
					case 7:
						sxNo = 3;
						sxName = " {E} {Front}";
						subNo = 1;
						break;
					case 10:
						sxNo = 4;
						sxName = " {NE}";
						subNo = 1;
						break;
					case 14:
						sxNo = 5;
						sxName = " {N} {Right}";
						subNo = 1;
						break;
					case 17:
						sxNo = 6;
						sxName = " {NW}";
						subNo = 1;
						break;
					case20:
						sxNo = 7;
						sxName = " {W} {Back}";
						subNo = 1;
						break;
					case 24:
						sxNo = 8;
						sxName = " {SW}";
						subNo = 1;
						break;
				}
				string pxID = "R" + r.ToString("00");
				pxID += "S" + sxNo.ToString() + sxName;
				pxID += subNo.ToString();

				pxName = sectionName + " " + pixelNum.ToString("000");
				pxName += " " + pxID;
				//pxName += " U" + universeNum.ToString() + chanNum.ToString("000");
				//pxName += "-" + (chanNum + 2).ToString("000") + "]";

				RGBchannel theKeywdel = MakeKeywdel(pxName, r, pxl);
				thisGroup.AddItem(theKeywdel);

				if (optReverse1.Checked)
				{
					chanNum -= 6;
					if (chanNum < 0)
					{
						universeNum--;
						chanNum = 170 * 3 + 1;
					}
				}
				else
				{
					if (chanNum > 510)
					{
						universeNum++;
						chanNum = 1;
					}
				}

				subNo++;
			}

			return thisGroup;

		} // end void AddBatch();

		private RGBchannel MakeKeywdel(string theName, int sect, int pxl)
		{
			string pxName = theName;
			string chName = theName;
			pxName += " [U" + universeNum.ToString() + ".";
			//if (optReverse1.Checked)
			//{
			//	pxName += (chanNum + 2).ToString() + "-" + chanNum.ToString() + "]";
			//}
			//else
			//{
				pxName += chanNum.ToString("000") + "-" + (chanNum + 2).ToString("000") + "]";
			//}
			RGBchannel theKeywdel = seq.CreateRGBchannel(pxName);

			if (chOrder == 1) // RGB Order
			{
				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel redChannel = seq.CreateChannel(chName);
				redChannel.output.deviceType = DeviceType.DMX;
				redChannel.output.network = universeNum;
				redChannel.color = utils.LORCOLOR_RED;
				redChannel.Centiseconds = seq.Centiseconds;
				redChannel.output.circuit = chanNum;
				theKeywdel.redChannel = redChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (G)";
				Channel grnChannel = seq.CreateChannel(chName);
				grnChannel.output.deviceType = DeviceType.DMX;
				grnChannel.output.network = universeNum;
				grnChannel.color = utils.LORCOLOR_GRN;
				grnChannel.Centiseconds = seq.Centiseconds;
				grnChannel.output.circuit = chanNum;
				theKeywdel.grnChannel = grnChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel bluChannel = seq.CreateChannel(chName);
				bluChannel.output.deviceType = DeviceType.DMX;
				bluChannel.output.network = universeNum;
				bluChannel.color = utils.LORCOLOR_BLU;
				bluChannel.Centiseconds = seq.Centiseconds;
				bluChannel.output.circuit = chanNum;
				theKeywdel.bluChannel = bluChannel;
				chanNum++;
			}

			if (chOrder == 2) // GRB Order
			{
				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (G)";
				Channel grnChannel = seq.CreateChannel(chName);
				grnChannel.output.deviceType = DeviceType.DMX;
				grnChannel.output.network = universeNum;
				grnChannel.color = utils.LORCOLOR_GRN;
				grnChannel.Centiseconds = seq.Centiseconds;
				grnChannel.output.circuit = chanNum;
				theKeywdel.grnChannel = grnChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel redChannel = seq.CreateChannel(chName);
				redChannel.output.deviceType = DeviceType.DMX;
				redChannel.output.network = universeNum;
				redChannel.color = utils.LORCOLOR_RED;
				redChannel.Centiseconds = seq.Centiseconds;
				redChannel.output.circuit = chanNum;
				theKeywdel.redChannel = redChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel bluChannel = seq.CreateChannel(chName);
				bluChannel.output.deviceType = DeviceType.DMX;
				bluChannel.output.network = universeNum;
				bluChannel.color = utils.LORCOLOR_BLU;
				bluChannel.Centiseconds = seq.Centiseconds;
				bluChannel.output.circuit = chanNum;
				theKeywdel.bluChannel = bluChannel;
				chanNum++;
			}

			chanMatrix[sect, pxl] = theKeywdel;

			if (reversed)
			{
				chanNum -= 6;
				if (chanNum < 1)
				{
					chanNum = 170 * 3 - 2;
					universeNum--;
				}
			}
			else
			{
				if (chanNum > (160*3))
				{
					chanNum = 1;
					universeNum++;
				}
			}
			pixelNum++;


			return theKeywdel;
		}

		private RGBchannel ShipKeywdel(string theName, int col, int row)
		{
			string pxName = theName;
			string chName = theName;
			pxName += " [U" + universeNum.ToString() + ".";
			//if (optReverse1.Checked)
			//{
			//	pxName += (chanNum + 2).ToString() + "-" + chanNum.ToString() + "]";
			//}
			//else
			//{
			pxName += chanNum.ToString("000") + "-" + (chanNum + 2).ToString("000") + "]";
			//}
			RGBchannel theKeywdel = seq.CreateRGBchannel(pxName);

			if (chOrder == 1) // RGB Order
			{
				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel redChannel = seq.CreateChannel(chName);
				redChannel.output.deviceType = DeviceType.DMX;
				redChannel.output.network = universeNum;
				redChannel.color = utils.LORCOLOR_RED;
				redChannel.Centiseconds = seq.Centiseconds;
				redChannel.output.circuit = chanNum;
				theKeywdel.redChannel = redChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (G)";
				Channel grnChannel = seq.CreateChannel(chName);
				grnChannel.output.deviceType = DeviceType.DMX;
				grnChannel.output.network = universeNum;
				grnChannel.color = utils.LORCOLOR_GRN;
				grnChannel.Centiseconds = seq.Centiseconds;
				grnChannel.output.circuit = chanNum;
				theKeywdel.grnChannel = grnChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel bluChannel = seq.CreateChannel(chName);
				bluChannel.output.deviceType = DeviceType.DMX;
				bluChannel.output.network = universeNum;
				bluChannel.color = utils.LORCOLOR_BLU;
				bluChannel.Centiseconds = seq.Centiseconds;
				bluChannel.output.circuit = chanNum;
				theKeywdel.bluChannel = bluChannel;
				chanNum++;
			}

			if (chOrder == 2) // GRB Order
			{
				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (G)";
				Channel grnChannel = seq.CreateChannel(chName);
				grnChannel.output.deviceType = DeviceType.DMX;
				grnChannel.output.network = universeNum;
				grnChannel.color = utils.LORCOLOR_GRN;
				grnChannel.Centiseconds = seq.Centiseconds;
				grnChannel.output.circuit = chanNum;
				theKeywdel.grnChannel = grnChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel redChannel = seq.CreateChannel(chName);
				redChannel.output.deviceType = DeviceType.DMX;
				redChannel.output.network = universeNum;
				redChannel.color = utils.LORCOLOR_RED;
				redChannel.Centiseconds = seq.Centiseconds;
				redChannel.output.circuit = chanNum;
				theKeywdel.redChannel = redChannel;
				chanNum++;

				chName += " [U" + universeNum.ToString() + "." + chanNum.ToString("000") + "] (R)";
				Channel bluChannel = seq.CreateChannel(chName);
				bluChannel.output.deviceType = DeviceType.DMX;
				bluChannel.output.network = universeNum;
				bluChannel.color = utils.LORCOLOR_BLU;
				bluChannel.Centiseconds = seq.Centiseconds;
				bluChannel.output.circuit = chanNum;
				theKeywdel.bluChannel = bluChannel;
				chanNum++;
			}

			chanMatrix[col, row] = theKeywdel;

			pixelNum++;


			return theKeywdel;
		}


		public string JustName(string fileName)
		{
			// Returns just the name portion of a filename
			// without the path, without any /'s
			// and without the extension and it's associated .
			string nameOnly = "";
			int i = fileName.IndexOf("\\");
			if (i < 0)
			{
				nameOnly = fileName;
			}
			else
			{
				string[] parts = fileName.Split('\\');
				nameOnly = parts[parts.Length-1 ];
			}
			i = nameOnly.LastIndexOf(".");
			if (i > 0)
			{
				nameOnly = nameOnly.Substring(0, i );
			}


			return nameOnly;
		}

		private void optForward1_CheckedChanged(object sender, EventArgs e)
		{
			txtStartCh1.Text = "1";
		}

		private void optReverse1_CheckedChanged(object sender, EventArgs e)
		{
			int x = 160 * 3 - 2;
			txtStartCh1.Text = x.ToString();
		}

		private void label12_Click(object sender, EventArgs e)
		{

		}
	} // end public partial class lorForm : Form
} // end namespace StringORama